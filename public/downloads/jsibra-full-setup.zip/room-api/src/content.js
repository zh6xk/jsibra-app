// Semua data konten ada di sini. Nanti bisa diganti fetch() dari CMS / API.
export const NAMES = { projects: 'Project', about: 'Tentang & Portofolio', gallery: 'Galeri Karya', shop: 'Toko', cart: 'Keranjang', contact: 'Kontak', bed: 'Tidur · Mimpi', switch: 'Kontak Lampu' };

// [posisi kamera, titik yang dilihat] saat sebuah objek diklik
export const FOCUS = {
  projects: [[.4, 2.2, -.9], [.2, 1.55, -3.4]],
  about: [[-.7, 2.2, .7], [-3.7, 1.7, -1.5]],
  gallery: [[-.3, 3.1, -.6], [-.3, 3.2, -4]],
  shop: [[2.9, 2, -.5], [2.9, 1.4, -3.6]],
  cart: [[3.2, 2.2, 2.6], [2.2, .4, 1.1]],
  contact: [[-.7, 2.2, -1.2], [-1, 1.05, -2.8]],
  bed: [[3.3, .98, -1.25], [2.6, 4.8, -1.25]],
  switch: [[3.2, 1.3, 1.45], [3.9, 1.3, 1.45]],
  cat: [[-.25, .75, 1.55], [-1.05, .2, .7]],
  catfar: [[.9, 1.3, 2.7], [-1.05, .2, .7]],
  catface: [[-.73, .4, 1.28], [-1, .32, .79]],
};
export const ANCHOR = { projects: [.2, 2.5, -3.4], about: [-3.4, 2.2, -1.5], gallery: [-.3, 3.9, -3.9], shop: [2.9, 2.9, -3.3], cart: [2.2, .9, 1.1], contact: [-1, 1.3, -2.8], bed: [3, 1, -1.25], switch: [3.8, 1.3, 1.45] };

// kotak tabrakan mode jalan: [xMin, xMax, zMin, zMax]
export const OBSTACLES = [[-1.8, 1.8, -3.95, -2.4], [-4, -3.2, -2.8, -.2], [1.7, 4, -4, -3.3], [1.6, 4, -2.15, -.35], [1.6, 2.8, .4, 1.8], [-3.7, -2.7, 2.7, 3.9], [-.1, 1.1, -2.8, -1.6], [3.3, 4, -2.7, -2.1]];

// Data dinamis (buku portofolio & produk shop). Nilai awal = cadangan kalau server tidak terjangkau; aslinya datang dari /api/room/content.
export const store = {
  version: 0, currency: 'Rp',
  books: [
    { id: 'b1', title: 'Aplikasi Fintech', desc: 'UX · React · 2025', url: '', color: '#2f4858' },
    { id: 'b2', title: 'Website 3D Brand X', desc: 'Three.js · 2026', url: '', color: '#d9a441' },
    { id: 'b3', title: 'Dashboard Analytics', desc: 'Next.js · 2024', url: '', color: '#5b7f6b' },
  ],
  products: [
    { id: 'p1', name: 'UI Kit Dashboard', desc: '', price: 49000, color: '#ffb066' },
    { id: 'p2', name: 'Preset Lightroom Pack', desc: '', price: 25000, color: '#7aa2ff' },
    { id: 'p3', name: 'Template Portfolio', desc: '', price: 79000, color: '#7be0b0' },
  ],
};
export function setStore(d) { store.version = d.version; store.currency = d.currency || 'Rp'; store.books = d.books || []; store.products = d.products || []; }
export const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const fmt = n => { const c = store.currency; return c + (/^[A-Za-z]{2,}$/.test(c) ? ' ' : '') + new Intl.NumberFormat(c === 'Rp' ? 'id-ID' : 'en-US', { maximumFractionDigits: 2 }).format(n); };
export const cart = []; // berisi id produk

export const DREAMS = [
  ['Mimpi 1 · Masa Depan', 'Bayangkan studio kecil dengan tim impian, membuat produk yang dipakai jutaan orang.', 'linear-gradient(#150b33,#3b1b6b)'],
  ['Mimpi 2 · Project Impian', 'Sebuah dunia 3D interaktif tempat setiap karya bisa dijelajahi seperti berjalan di museum.', 'linear-gradient(#04202f,#0b6e6e)'],
  ['Mimpi 3 · Kolaborasi', 'Bekerja bareng kreator dari seluruh dunia, saling melengkapi dari desain sampai kode.', 'linear-gradient(#2d0820,#8a2a4a)'],
];

const link = u => u ? `<a class="btn" href="${esc(u)}" target="_blank" rel="noopener noreferrer">Lihat</a>` : '';
export const CONTENT = {
  projects: () => `<h2>Project</h2><p>Studi kasus pilihan.</p>` + [['Aplikasi Fintech', 'UX · React · 2025'], ['Website 3D Brand X', 'Three.js · 2026'], ['Dashboard Analytics', 'Next.js · 2024']].map(p => `<div class="card"><div><b>${p[0]}</b><small>${p[1]}</small></div><button>Lihat</button></div>`).join('') + `<button class="ghost" data-admin>🔒 Admin</button>`,
  about: () => `<h2>Tentang & Portofolio</h2><p>Halo! Saya developer & desainer yang suka membuat pengalaman web yang berkesan.</p><p>${['React', 'Three.js', 'UI/UX', 'Node'].map(s => `<span class="tag">${s}</span>`).join('')}</p><div class="card"><div><b>Senior Frontend · Studio Y</b><small>2022 – sekarang</small></div></div>`
    + (store.books.length ? `<h3>Karya di rak</h3>` + store.books.map(b => `<div class="card"><div><b>${esc(b.title)}</b><small>${esc(b.desc)}</small></div>${link(b.url)}</div>`).join('') : `<p>Belum ada karya di rak.</p>`) + `<button>Download CV</button>`,
  gallery: () => `<h2>Galeri Karya</h2><p>Poster, ilustrasi, dan visual unggulan tampil sebagai grid gambar di sini.</p>`,
  shop: () => `<h2>Toko</h2><p>Produk digital · bayar via Stripe Checkout.</p>` + (store.products.length ? store.products.map(p => `<div class="card"><div><b>${esc(p.name)}</b><small>${fmt(p.price)}${p.desc ? ' · ' + esc(p.desc) : ''}</small></div><button data-buy="${esc(p.id)}">+ Keranjang</button></div>`).join('') : `<p>Belum ada produk.</p>`),
  cart: () => {
    const items = cart.map(id => store.products.find(p => p.id === id)).filter(Boolean);
    return items.length ? `<h2>Keranjang</h2>` + items.map(p => `<div class="card"><b>${esc(p.name)}</b><small>${fmt(p.price)}</small></div>`).join('') + `<p>Total: <b>${fmt(items.reduce((s, p) => s + p.price, 0))}</b></p><button data-pay>Checkout dengan Stripe</button>` : `<h2>Keranjang</h2><p>Masih kosong. Tambahkan produk dari rak toko.</p>`;
  },
  contact: () => `<h2>Kontak</h2><p>Punya project atau pertanyaan?</p><div class="card"><div><b>halo@namakamu.com</b><small>Balasan 1–2 hari kerja</small></div><button>Kirim</button></div>`,
};
