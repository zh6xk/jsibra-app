// Kucing dari model GLB (src/assets/cat.glb, ±1,1 MB) + animasi prosedural lewat tulang (tanpa clip animasi).
// Sumbu pose = sumbu kucing: X samping, Y atas, Z depan (model menghadap +Z). Rotasi tiap tulang diberikan di sumbu itu
// lalu dikonversi ke ruang lokal tulang, jadi tidak tergantung orientasi tulang dari Blender.
// Perilaku: santai (napas, tengok-tengok, ekor) → jalan keliling karpet (siklus kaki diagonal) → santai lagi.
// Saat pemain <2,2 m: berhenti; menoleh berurutan (kepala → leher → tulang belakang memutar, pegas otot), lalu badan ikut berputar
// sambil kaki melangkah di tempat (condong ke arah putar, kepala tetap tegak), ekor terseret; kadang mengeong/mendengkur.
// Bila GLB gagal dimuat → jatuh ke kucing prosedural lama (fallback).
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import catUrl from './assets/cat.glb?url';
import { OBSTACLES } from './content.js';
import { blobTexture } from './textures.js';

const { clamp } = THREE.MathUtils;
const key = n => n.replace(/[.\s]/g, '');   // GLTFLoader membuang titik dari nama node: "Bone.001" → "Bone001"
const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

export function buildCatGLB(room, fallback) {
  const root = new THREE.Group(); root.position.set(-1.1, .03, .6); root.rotation.y = .5; root.scale.setScalar(1.5); room.add(root);
  let impl = null, forced = null;
  const api = { group: root, update: (t, cam) => impl && impl.update(t, cam), force(a) { forced = a; if (impl) impl.force(a); } };
  new GLTFLoader().load(catUrl, gltf => {
    impl = rig(gltf.scene, root); if (forced !== null) impl.force(forced);
  }, undefined, err => {
    console.warn('[cat] GLB gagal dimuat, pakai kucing prosedural', err);
    room.remove(root); impl = fallback(); api.group = impl.group; if (forced !== null) impl.force(forced);
  });
  return api;
}

function rig(model, root) {
  root.add(model);
  const B = {};
  model.traverse(o => {
    if (o.isBone) B[key(o.name)] = o;
    // shadow map scene statis → kucing yang bergerak tidak ikut shadow map; diganti bayangan blob di bawahnya
    if (o.isMesh) { o.castShadow = false; o.receiveShadow = true; o.frustumCulled = false; }
  });
  const blob = new THREE.Mesh(new THREE.PlaneGeometry(.32, .7), new THREE.MeshBasicMaterial({ map: blobTexture(), transparent: true, opacity: .55, depthWrite: false }));
  blob.rotation.x = -Math.PI / 2; blob.position.set(0, .004, .02); blob.renderOrder = 1; root.add(blob);
  root.updateMatrixWorld(true);
  // kontrol telapak (feet_*/paw3_*) adalah akar terpisah yang membawa bobot kulit telapak → tempel ke ujung kaki supaya ikut bergerak
  for (const [f, p] of [['feet_L', 'leg3_L'], ['feet_R', 'leg3_R'], ['paw3_L', 'paw2_L'], ['paw3_R', 'paw2_R']]) if (B[f] && B[p]) B[p].attach(B[f]);
  root.updateMatrixWorld(true);

  const inv = new THREE.Matrix4().copy(root.matrixWorld).invert(), tmpM = new THREE.Matrix4(), tp = new THREE.Vector3(), ts = new THREE.Vector3();
  const S = {};   // per tulang: rotasi diam (q0) + rotasi parent di sumbu kucing (P)
  const names = ['Bone001', 'Bone002', 'Bone004', 'tail1', 'tail2', 'tail3', 'tail4', 'tail5',
    'leg1_L', 'leg2_L', 'leg3_L', 'leg1_R', 'leg2_R', 'leg3_R', 'paw1_L', 'paw2_L', 'paw3_L', 'paw1_R', 'paw2_R', 'paw3_R'];
  for (const n of names) {
    const b = B[n]; if (!b) { console.warn('[cat] tulang tidak ada:', n); continue; }
    const P = new THREE.Quaternion(); tmpM.multiplyMatrices(inv, b.parent.matrixWorld).decompose(tp, P, ts);
    S[n] = { b, q0: b.quaternion.clone(), P, Pi: P.clone().invert() };
  }
  const R = new THREE.Quaternion(), Rx = new THREE.Quaternion(), Rz = new THREE.Quaternion();
  const AX = new THREE.Vector3(1, 0, 0), AY = new THREE.Vector3(0, 1, 0), AZ = new THREE.Vector3(0, 0, 1);
  // pose: rotasi (yaw=Y, pitch=X, roll=Z; urutan YXZ) di sumbu kucing
  const pose = (n, yaw, pitch, roll) => {
    const s = S[n]; if (!s) return;
    R.setFromAxisAngle(AY, yaw); Rx.setFromAxisAngle(AX, pitch); Rz.setFromAxisAngle(AZ, roll); R.multiply(Rx).multiply(Rz);
    s.b.quaternion.copy(s.Pi).multiply(R).multiply(s.P).multiply(s.q0);
  };

  // ---------- gerak
  const home = root.position.clone(), target = new THREE.Vector3();
  const GAIT_HZ = 1.5, SPEED = 0.55;    // langkah/dtk (per kaki) & kecepatan jalan dunia (m/dtk) — selaras dengan panjang langkah × skala kucing
  const NEAR = 2.2;
  const blocked = (x, z) => x < -3.5 || x > 3.5 || z < -3.5 || z > 3.5 || OBSTACLES.some(o => x > o[0] - .2 && x < o[1] + .2 && z > o[2] - .2 && z < o[3] + .2);
  const clear = (a, b) => { for (let i = 0; i <= 14; i++) if (blocked(a.x + (b.x - a.x) * i / 14, a.z + (b.z - a.z) * i / 14)) return false; return true; };
  function pickTarget() {
    for (let i = 0; i < 14; i++) {
      const a = Math.random() * 6.283, r = .5 + Math.random() * .7; target.set(home.x + Math.cos(a) * r, home.y, home.z + Math.sin(a) * r);
      if (target.distanceTo(root.position) > .45 && !blocked(target.x, target.z) && clear(root.position, target)) return true;
    } return false;
  }
  let last = 0, mode = 'idle', modeUntil = 1.5, walkAmt = 0, legAmt = 0, phase = 0, al = 0, forced = null, tw = 0;
  let actT = -1, st = 0, sn = 0, bodyTurning = false, turnRate = 0;
  // "otot": pegas teredam tiap segmen (kepala → leher → tulang belakang bergerak berurutan, ada overshoot kecil lalu mengendap)
  const spr = () => ({ x: 0, v: 0 });
  const headY = spr(), neckY = spr(), spineY = spr(), headP = spr(), neckP = spr(), lean = spr(), turnV = spr();
  const spring = (o, target, dt, w, z = .7) => { o.v += (w * w * (target - o.x) - 2 * z * w * o.v) * dt; o.x += o.v * dt; return o.x; };
  // suara
  let alertSince = -1, nextMeow = 12 + Math.random() * 20, meowAt = -1, purrUntil = 0, wasAlert = false;
  const v = new THREE.Vector3(), rt = new THREE.Vector3(), tc = new THREE.Vector3();
  const ease = (c, t, dt, k) => c + (t - c) * (1 - Math.exp(-dt * k)), env = p => Math.min(1, Math.sin(Math.PI * Math.min(Math.max(p, 0), 1)) * 2.2);
  const hipA = { hind: .45, fore: .42 };
  function say(type, base, cam, extra) {          // volume turun menurut jarak, pan mengikuti posisi kucing di layar
    if (!cam) return; const dx = root.position.x - cam.position.x, dz = root.position.z - cam.position.z, d = Math.hypot(dx, dz);
    rt.setFromMatrixColumn(cam.matrixWorld, 0); tc.set(dx, 0, dz).normalize();
    const vol = clamp(1.15 - d / 7, .12, 1) * base, pan = clamp(rt.dot(tc) * .9, -1, 1);
    window.dispatchEvent(new CustomEvent('cat-sound', { detail: { type, vol, pan, ...extra } }));
  }

  function leg(ids, ph, amt, hind, extra = 0) {
    const [h, m, l] = ids, A = (hind ? hipA.hind : hipA.fore) * amt;
    const hip = A * Math.sin(ph) + extra, lift = Math.max(0, -Math.cos(ph)) * amt;
    const mid = lift * .7;
    pose(h, 0, hip, 0); pose(m, 0, mid, 0);
    if (l) pose(l, 0, -(hip + mid) + lift * .25, 0);
    return { hip, mid };
  }

  function update(t, cam) {
    const s = t / 1000, dt = last ? Math.min((t - last) / 1000, .05) : .016; last = t;
    // ---- keadaan
    let near = false, camYaw = 0;
    if (cam) { v.copy(cam.position); near = Math.hypot(v.x - root.position.x, v.z - root.position.z) < NEAR; root.worldToLocal(v); camYaw = Math.atan2(v.x, v.z); }
    const alert = forced === null ? near : !!forced;
    al = ease(al, alert ? 1 : 0, dt, 2.2);
    const h0 = root.rotation.y; let heading = h0, wantWalk = 0, desiredRate = 0;
    if (alert) {
      if (mode !== 'idle') { mode = 'idle'; actT = -1; }
      modeUntil = s + 2.5;
      // urutan menoleh: kepala dulu → leher → tulang belakang memutar; kalau sudut masih besar, badan ikut berputar sambil kaki melangkah
      if (cam) {
        if (Math.abs(camYaw) > .6) bodyTurning = true; else if (Math.abs(camYaw) < .2) bodyTurning = false;
        if (bodyTurning) desiredRate = clamp(camYaw * 1.8, -1.1, 1.1);
      }
    } else {
      bodyTurning = false;
      if (mode === 'idle') {
        if (s > modeUntil) {
          const r = Math.random();
          if (r < .22) { mode = 'stretch'; actT = s; } else if (r < .42) { mode = 'sniff'; actT = s; }
          else if (pickTarget()) mode = 'walk'; else modeUntil = s + 1.5;
        }
      } else if (mode === 'stretch' || mode === 'sniff') {
        if (s - actT > (mode === 'stretch' ? 3.2 : 2.4)) { mode = 'idle'; modeUntil = s + 1.5 + Math.random() * 2; actT = -1; }
      } else {                                     // walk
        const dx = target.x - root.position.x, dz = target.z - root.position.z, d = Math.hypot(dx, dz);
        if (d < .06) { mode = 'idle'; modeUntil = s + 1.5 + Math.random() * 3; }
        else {
          const err = wrap(Math.atan2(dx, dz) - heading); heading += clamp(err, -1.6 * dt, 1.6 * dt);
          wantWalk = clamp(1 - Math.abs(err) / .9, 0, 1);       // belok dulu kalau arahnya masih jauh
          const sp = SPEED * walkAmt * dt; root.position.x += Math.sin(heading) * sp; root.position.z += Math.cos(heading) * sp;
        }
      }
    }
    spring(turnV, desiredRate, dt, 9, 1);                          // kecepatan putar badan dihaluskan (tidak mendadak)
    heading += turnV.x * dt; root.rotation.y = heading;
    turnRate = ease(turnRate, wrap(heading - h0) / Math.max(dt, 1e-3), dt, 10);
    st = ease(st, mode === 'stretch' && actT >= 0 ? env((s - actT) / 3.2) : 0, dt, 8);
    sn = ease(sn, mode === 'sniff' && actT >= 0 ? env((s - actT) / 2.4) : 0, dt, 8);
    walkAmt = ease(walkAmt, mode === 'walk' ? wantWalk : 0, dt, 5); if (walkAmt < .01) walkAmt = 0;
    // kaki melangkah di tempat saat badan berputar → kesan memutar, bukan meluncur
    const stepAmt = clamp(Math.abs(turnRate) / .9, 0, 1) * .6;
    legAmt = Math.max(walkAmt, ease(legAmt, stepAmt, dt, 6)); if (legAmt < .01) legAmt = 0;
    phase += dt * GAIT_HZ * 6.283 * legAmt * (walkAmt > .3 ? 1 : 1.25);
    // ---- target pandangan (total relatif badan, ±100°); dibagi kepala 45% / leher 30% / tulang belakang 25% dengan kelambanan berbeda
    let yawT, pitchT;
    if (cam && alert) { yawT = clamp(camYaw, -1.75, 1.75); pitchT = clamp(-Math.atan2(v.y - .3, Math.hypot(v.x, v.z - .19)), -.55, .35); }
    else if (legAmt > .2) { yawT = Math.sin(s * .8) * .12; pitchT = .05; }
    else { yawT = Math.sin(s * .55) * .5 + Math.sin(s * .17 + 1) * .35; pitchT = .1 + Math.sin(s * .5) * .05; }
    const sniffYaw = Math.sin(s * 2.6) * .18 * sn, sniffPitch = .55 * sn + Math.sin(s * 9) * .04 * sn;
    const yH = spring(headY, yawT * .45 + sniffYaw * .5, dt, 17, .62), yN = spring(neckY, yawT * .3 + sniffYaw * .5, dt, 11, .7), yS = spring(spineY, clamp(yawT * .25, -.45, .45), dt, 6.5, .8);
    const pH = spring(headP, pitchT * .55, dt, 15, .65), pN = spring(neckP, pitchT * .45, dt, 11, .7);
    // ---- kaki (diagonal: kiri-depan+kanan-belakang | kanan-depan+kiri-belakang) + efek meregang
    leg(['leg1_L', 'leg2_L', 'leg3_L'], phase + Math.PI, legAmt, true, .12 * st); leg(['leg1_R', 'leg2_R', 'leg3_R'], phase, legAmt, true, .12 * st);
    const fl = leg(['paw1_L', 'paw2_L'], phase, legAmt, false, -.55 * st), fr = leg(['paw1_R', 'paw2_R'], phase + Math.PI, legAmt, false, -.55 * st);
    pose('paw3_L', 0, -(fl.hip + fl.mid), 0); pose('paw3_R', 0, -(fr.hip + fr.mid), 0);
    // ---- badan: napas + goyang; condong ke arah putar (otot) dan kepala menegakkan diri (refleks righting kucing)
    const br = Math.sin(s * 2.1), bz = br * .5 + .5, sw = Math.sin(phase);
    const roll = spring(lean, clamp(-turnV.x * .1, -.14, .14), dt, 8, .7);
    pose('Bone001', yS + Math.sin(s * .21) * .015 * (1 - legAmt) + sw * .06 * legAmt, br * .008 + Math.cos(phase * 2) * .02 * legAmt + .3 * st + .08 * sn, roll + Math.sin(s * .17) * .018 * (1 - legAmt) + sw * .03 * legAmt);
    S.Bone001 && S.Bone001.b.scale.set(1 + bz * .014, 1, 1 + bz * .014);
    pose('Bone002', yN - sw * .05 * legAmt, pN - br * .004 + .22 * st + sniffPitch * .5, -roll * .4);
    pose('Bone004', yH - sw * .05 * legAmt, pH - .35 * st + sniffPitch * .5 + Math.max(0, Math.sin(s * .9)) * .01 + Math.abs(Math.cos(phase)) * .03 * legAmt, -roll * .5);
    root.position.y = home.y + Math.abs(Math.sin(phase)) * .004 * legAmt;
    // ---- ekor: ayunan lambat & kaku di pangkal; waspada → naik berujung melengkung; jalan → agak naik; ikut terseret (inersia) saat badan berputar
    tw += dt * (.9 + al * .3 + walkAmt * .4);
    for (let i = 1; i <= 5; i++) {
      const swing = (.055 + i * .025) * (1 + al * .25) * (Math.sin(tw - i * .26) + .3 * Math.sin(tw * 2.1 + 1 - i * .18)) - turnV.x * .06 * i;
      const lift = i === 1 ? .1 + al * .5 + walkAmt * .26 + st * .5 + sn * .1 : .02 + al * .06 + walkAmt * .04 + st * .1 + (i >= 3 ? al * .08 : 0);
      pose('tail' + i, swing, lift, 0);
    }
    // ---- suara
    if (alert && !wasAlert) { alertSince = s; if (s > nextMeow - 8 && Math.random() < .75) meowAt = s + .6 + Math.random() * .5; }
    if (!alert) alertSince = -1; wasAlert = alert;
    if (meowAt > 0 && s > meowAt) { meowAt = -1; say('meow', .75, cam, { kind: Math.random() < .35 ? 1 : 0 }); nextMeow = s + 25 + Math.random() * 30; }
    else if (!alert && s > nextMeow && mode === 'idle' && cam) { say('meow', .6, cam, { kind: Math.random() < .5 ? 1 : 0 }); nextMeow = s + 25 + Math.random() * 40; }
    if (alert && alertSince > 0 && s - alertSince > 3 && s > purrUntil && Math.hypot(root.position.x - cam.position.x, root.position.z - cam.position.z) < 1.5 && Math.random() < .01) {
      purrUntil = s + 12; say('purr', .6, cam, { dur: 3.5 });
    }
    root.updateMatrixWorld(true);   // scene statis (matrixWorldAutoUpdate=false) → update manual
  }
  console.info('[cat] rig aktif — tulang teranimasi:', Object.keys(S).length, '/', names.length);
  let helper = null, hud = null;
  if (typeof location !== 'undefined' && /catdebug/.test(location.search)) {      // ?catdebug → garis tulang + status
    helper = new THREE.SkeletonHelper(model); helper.material.depthTest = false; helper.material.linewidth = 2; helper.renderOrder = 9; root.parent.add(helper);
    hud = document.createElement('div'); hud.style.cssText = 'position:fixed;left:12px;top:56px;z-index:99;font:12px monospace;color:#fff;background:#000a;padding:6px 8px;border-radius:6px;pointer-events:none'; document.body.appendChild(hud);
  }
  const base = update;
  const upd = (t, cam) => { base(t, cam); if (helper) { helper.updateMatrixWorld(true); hud.textContent = `kucing: ${mode}  jalan=${walkAmt.toFixed(2)}  regang=${st.toFixed(2)}  endus=${sn.toFixed(2)}  waspada=${al.toFixed(2)}  badan-putar=${bodyTurning}  kepala-yaw=${headY.x.toFixed(2)}  putar=${turnRate.toFixed(2)}  pos=${root.position.x.toFixed(2)},${root.position.z.toFixed(2)}`; } };
  return { update: upd, group: root, force(a) { forced = a; } };
}
