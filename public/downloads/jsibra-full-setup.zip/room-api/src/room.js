// Seluruh geometri kamar. Tiap grup dengan userData.key = objek yang bisa diklik.
// Nanti bagian ini bisa diganti satu file GLB dari Blender (lihat README).
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { buildDetails } from './details.js';
import { ct, normalMap, rnd, wood, plaster, rugTexture, screenTexture, posterTexture, skyTexture, blobTexture, edgeTexture, beamTexture } from './textures.js';

const M = (c, o = {}) => new THREE.MeshPhysicalMaterial({ roughness: .7, metalness: 0, ...o, color: c });

// UV skala dunia → serat kayu/plester sama padat di semua objek (tidak melar)
function worldUV(g, k = 1) {
  const p = g.attributes.position, n = g.attributes.normal, uv = g.attributes.uv;
  for (let i = 0; i < p.count; i++) {
    const ax = Math.abs(n.getX(i)), ay = Math.abs(n.getY(i)), az = Math.abs(n.getZ(i));
    if (ax >= ay && ax >= az) uv.setXY(i, p.getZ(i) * k, p.getY(i) * k);
    else if (ay >= az) uv.setXY(i, p.getX(i) * k, p.getZ(i) * k);
    else uv.setXY(i, p.getX(i) * k, p.getY(i) * k);
  }
}
function bx(G, w, h, d, x, y, z, mat, r = .012) {
  r = Math.min(r, w / 2 - .001, h / 2 - .001, d / 2 - .001);
  const g = r > 0 ? new RoundedBoxGeometry(w, h, d, 3, r) : new THREE.BoxGeometry(w, h, d); // bevel halus asli → highlight tepi
  if (mat.map) worldUV(g, mat.userData.uvk || 1);
  const m = new THREE.Mesh(g, mat);
  m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; G.add(m); return m;
}
function cy(G, a, b, h, x, y, z, mat, s = 28) {
  const m = new THREE.Mesh(new THREE.CylinderGeometry(a, b, h, s), mat);
  m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; G.add(m); return m;
}

export function buildRoom(scene) {
  const room = new THREE.Group(); scene.add(room);
  const grp = k => { const g = new THREE.Group(); g.userData.key = k; room.add(g); return g; };

  // ---- materials
  const tF = wood([32, 45, 58], 1, 1, 64), tW = wood([24, 40, 32], 1, 1, 48), tP = plaster(1, 1);
  const mFloor = M(0xffffff, { map: tF, normalMap: normalMap(tF, 3), normalScale: new THREE.Vector2(.9, .9), roughness: .42, clearcoat: .35, clearcoatRoughness: .3 });
  mFloor.userData.uvk = .83;
  const mWood = M(0xffffff, { map: tW, normalMap: normalMap(tW, 3), roughness: .5 });
  const mWall = M(0xffffff, { map: tP, normalMap: normalMap(tP, 4), roughness: .95 });
  mWood.userData.uvk = 1.6; mWall.userData.uvk = .5;
  const mTrim = M('#f3ede4', { roughness: .5 }), mDark = M('#1b1b22', { roughness: .4, metalness: .3 }), mMetal = M('#8a8a92', { roughness: .3, metalness: .8 });
  const mFab = M('#3c4a63', { roughness: .95, sheen: 1, sheenRoughness: .6, sheenColor: new THREE.Color('#8fa0c0') }), mCur = M('#d8c3a5', { roughness: .95, sheen: 1, sheenRoughness: .7, sheenColor: new THREE.Color('#fff1da') }), mBox = M('#c49a62', { roughness: .9 });
  const mTerra = M('#b5623e', { roughness: .9 }), mLeaf = M('#3f8a4f', { roughness: .6 }), mCer = M('#f1ece4', { roughness: .25, clearcoat: .6, clearcoatRoughness: .15 }), mCeil = M('#efe6da', { roughness: .95 });
  const softT = ct(64, 64, g => { const r = g.createRadialGradient(32, 32, 0, 32, 32, 32); r.addColorStop(0, 'rgba(255,255,255,1)'); r.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = r; g.fillRect(0, 0, 64, 64); });
  const screenT = screenTexture();
  const mScreen = new THREE.MeshStandardMaterial({ map: screenT, emissive: 0xffffff, emissiveMap: screenT, roughness: .3 });
  const mShade = M('#f4e3c8', { emissive: '#ffb066', emissiveIntensity: .5, roughness: .8 });
  const mPhone = M('#111', { emissive: '#ffb066', emissiveIntensity: .6 });

  // ---- shell: lantai, dinding, plafon, jendela, pintu
  bx(room, 8, .2, 8, 0, -.1, 0, mFloor, 0); bx(room, 8.2, 5, .2, 0, 2.5, -4.1, mWall, 0);
  bx(room, .2, 5, 4.6, -4.1, 2.5, -1.9, mWall, 0); bx(room, .2, 5, 1.2, -4.1, 2.5, 3.4, mWall, 0); bx(room, .2, 1.6, 2.4, -4.1, .8, 1.6, mWall, 0); bx(room, .2, 1, 2.4, -4.1, 4.5, 1.6, mWall, 0);
  bx(room, 8, .15, .05, 0, .075, -3.975, mTrim); bx(room, .05, .15, 8, -3.975, .075, 0, mTrim);
  bx(room, .12, .1, 2.5, -3.95, 1.65, 1.6, mTrim); bx(room, .12, .1, 2.5, -3.95, 3.95, 1.6, mTrim); bx(room, .12, 2.4, .1, -3.95, 2.8, .4, mTrim); bx(room, .12, 2.4, .1, -3.95, 2.8, 2.8, mTrim);
  bx(room, .06, 2.4, .05, -3.97, 2.8, 1.6, mTrim); bx(room, .06, .05, 2.4, -3.97, 2.8, 1.6, mTrim); bx(room, .3, .06, 2.7, -3.88, 1.62, 1.6, mTrim);
  bx(room, .2, 5, 8.2, 4.1, 2.5, 0, mWall, 0); bx(room, 8.2, 5, .2, 0, 2.5, 4.1, mWall, 0); bx(room, 8.4, .2, 8.4, 0, 5.1, 0, mCeil, 0);
  bx(room, .05, .15, 8, 3.975, .075, 0, mTrim); bx(room, 8, .15, .05, 0, .075, 3.975, mTrim); bx(room, 8, .1, .08, 0, 4.95, -3.96, mTrim); bx(room, .08, .1, 8, -3.96, 4.95, 0, mTrim); bx(room, .08, .1, 8, 3.96, 4.95, 0, mTrim);
  bx(room, .08, 2.6, 1.3, 3.97, 1.3, 2.2, mTrim); bx(room, .06, 2.45, 1.1, 3.93, 1.25, 2.2, mWood, .01); cy(room, .03, .03, .1, 3.85, 1.1, 1.8, mMetal, 12).rotation.z = Math.PI / 2;
  cy(room, .4, .4, .05, 3.97, 3.2, -1.2, mCer, 32).rotation.z = Math.PI / 2; const hh = new THREE.Group(), mh = new THREE.Group(), sh = new THREE.Group();
  [hh, mh, sh].forEach(g => { g.position.set(3.93, 3.2, -1.2); room.add(g); });
  bx(hh, .015, .16, .025, 0, .08, 0, mDark, .004); bx(mh, .012, .26, .02, 0, .13, 0, mDark, .004); bx(sh, .008, .3, .008, -.005, .13, 0, M('#c0392b'), .002);
  for (let i = 0; i < 12; i++) { const a = i * Math.PI / 6; bx(room, .01, i % 3 ? .035 : .06, .012, 3.935, 3.2 + Math.cos(a) * .33, -1.2 + Math.sin(a) * .33, mDark, .003).rotation.x = a; }
  cy(room, .01, .01, .7, 0, 4.65, .5, mDark, 6); // lampu gantung: kap + bohlam punya material sendiri → menyala sesuai mode (mati saat pagi)
  const mPend = M('#f4e3c8', { emissive: '#ffb066', emissiveIntensity: .4, roughness: .8 });
  const mBulb = new THREE.MeshBasicMaterial({ color: new THREE.Color(4, 3.2, 2.2) }); mBulb.userData.base = mBulb.color.clone();
  cy(room, .12, .4, .3, 0, 4.2, .5, mPend);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(.07, 16, 12), mBulb); bulb.position.set(0, 4.08, .5); room.add(bulb); // HDR → bloom

  // kaca jendela (tidak boleh cast shadow, kalau tidak sinar matahari terhalang)
  bx(room, .02, 2.4, 2.4, -3.99, 2.8, 1.6, new THREE.MeshStandardMaterial({ color: 0xffffff, transparent: true, opacity: .1, roughness: .05, depthWrite: false }), 0).castShadow = false;
  const skyM = new THREE.MeshBasicMaterial({ map: skyTexture(false), fog: false, toneMapped: false });
  const skyP = new THREE.Mesh(new THREE.PlaneGeometry(16, 10), skyM); skyP.position.set(-8, 3, 1.6); skyP.rotation.y = Math.PI / 2; room.add(skyP);
  const beam = new THREE.Mesh(new THREE.PlaneGeometry(2.4, 5.5), new THREE.MeshBasicMaterial({ map: beamTexture(), transparent: true, opacity: .22, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, toneMapped: false }));
  beam.position.set(-1.7, 1.3, 1.2); beam.rotation.z = -2.16; room.add(beam);
  const curtain = (zc, w) => { // tirai berlipat (pleats) dengan kilau kain
    const g = new THREE.PlaneGeometry(w, 3.3, 56, 1), p = g.attributes.position;
    for (let i = 0; i < p.count; i++) p.setZ(i, Math.sin((p.getX(i) / w + .5) * Math.PI * 2 * 7) * .05 + (p.getY(i) < 0 ? .03 : 0));
    g.computeVertexNormals();
    const m = new THREE.Mesh(g, new THREE.MeshPhysicalMaterial({ color: '#d8c3a5', roughness: .95, sheen: 1, sheenRoughness: .7, sheenColor: new THREE.Color('#fff1da'), side: THREE.DoubleSide }));
    m.position.set(-3.84, 2.55, zc); m.rotation.y = Math.PI / 2; m.castShadow = m.receiveShadow = true; room.add(m);
  };
  curtain(.05, .9); curtain(3.15, .9);
  const shG = new THREE.PlaneGeometry(2.3, 3.2, 24, 16), shP = shG.attributes.position, shB = shP.array.slice(); // tirai tipis bergoyang
  const sheer = new THREE.Mesh(shG, new THREE.MeshStandardMaterial({ color: '#fff6ea', transparent: true, opacity: .22, roughness: 1, side: THREE.DoubleSide, depthWrite: false }));
  sheer.position.set(-3.8, 2.55, 1.6); sheer.rotation.y = Math.PI / 2; room.add(sheer);
  cy(room, .02, .02, 3.6, -3.8, 4.25, 1.6, mMetal, 8).rotation.x = Math.PI / 2;
  const rug = new THREE.Mesh(new THREE.BoxGeometry(3.8, .03, 2.6), M(0xffffff, { map: rugTexture(), roughness: 1 })); rug.position.set(0, .015, .8); rug.receiveShadow = true; room.add(rug);

  // ---- bayangan kontak palsu (AO murah)
  const blobT = blobTexture(), edgeT = edgeTexture();
  const blob = (x, z, w, d, o = 1) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshBasicMaterial({ map: blobT, transparent: true, opacity: o * .65, depthWrite: false, toneMapped: false })); m.rotation.x = -Math.PI / 2; m.position.set(x, .035, z); room.add(m); };
  [[.2, -3.3, 3.8, 1.9, .7], [.5, -2.1, 1.5, 1.5, .6], [2.2, 1.1, 1.6, 1.6, .7], [-3.2, 3.3, 1.3, 1.3, .6], [2.9, -3.5, 2.4, 1, .5], [-3.65, -1.5, 1, 2.5, .5], [2.85, -1.25, 2.5, 1.9, .6], [3.65, -2.4, .8, .8, .6]].forEach(b => blob(...b));
  [[0, -3.65, [-1.5708, 0, 0]], [-3.65, 0, [-1.5708, 0, 1.5708]], [3.65, 0, [-1.5708, 0, -1.5708]]].forEach(a => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(8, .7), new THREE.MeshBasicMaterial({ map: edgeT, transparent: true, depthWrite: false, toneMapped: false }));
    m.rotation.set(...a[2]); m.position.set(a[0], .03, a[1]); room.add(m);
  });

  // ---- meja kerja [projects]
  const D = grp('projects');
  bx(D, 3.2, .08, 1.3, 0, 1, -3.2, mWood, .02);
  [[-1.5, -2.7], [1.5, -2.7], [-1.5, -3.7], [1.5, -3.7]].forEach(p => bx(D, .08, .96, .08, p[0], .5, p[1], mWood, .01));
  bx(D, .8, .55, 1.1, 1.1, .68, -3.2, mWood, .02); bx(D, .3, .03, .03, 1.1, .78, -2.64, mMetal, .005); bx(D, .3, .03, .03, 1.1, .55, -2.64, mMetal, .005);
  bx(D, 1.5, .9, .06, .2, 1.78, -3.6, mDark, .02);
  const sc = new THREE.Mesh(new THREE.PlaneGeometry(1.38, .78), mScreen); sc.position.set(.2, 1.78, -3.567); D.add(sc);
  bx(D, .1, .45, .06, .2, 1.3, -3.63, mMetal, .01); bx(D, .5, .03, .3, .2, 1.07, -3.55, mMetal, .01); bx(D, .6, .03, .2, .2, 1.065, -3.05, mDark, .01); bx(D, .08, .03, .12, .75, 1.065, -3.05, mDark, .01);

  // lampu meja, mug, buku catatan, tanaman meja
  cy(room, .13, .15, .03, -1.35, 1.065, -3.7, mDark); cy(room, .012, .012, .5, -1.35, 1.32, -3.7, mMetal, 8); cy(room, .012, .012, .3, -1.22, 1.64, -3.7, mMetal, 8).rotation.z = -1.09;
  cy(room, .06, .17, .22, -1.08, 1.6, -3.7, mShade).castShadow = false;
  cy(room, .05, .045, .1, -.45, 1.09, -2.8, mCer);
  const hd = new THREE.Mesh(new THREE.TorusGeometry(.03, .008, 8, 16), mCer); hd.position.set(-.4, 1.09, -2.8); room.add(hd);
  bx(room, .3, .03, .4, -.95, 1.06, -3.3, M('#7a3b32', { roughness: .8 }), .008).rotation.y = .15;
  cy(room, .07, .055, .12, 1.35, 1.1, -3.75, mTerra, 16);
  for (let i = 0; i < 5; i++) { const l = new THREE.Mesh(new THREE.SphereGeometry(.07, 8, 6), mLeaf); l.position.set(1.35 + (rnd() - .5) * .12, 1.22 + i * .03, -3.75 + (rnd() - .5) * .12); l.castShadow = true; room.add(l); }

  const SN = 16, stG = new THREE.BufferGeometry(), stP = new Float32Array(SN * 3), stC = new Float32Array(SN * 3);
  stG.setAttribute('position', new THREE.BufferAttribute(stP, 3)); stG.setAttribute('color', new THREE.BufferAttribute(stC, 3));
  const steam = new THREE.Points(stG, new THREE.PointsMaterial({ map: softT, size: .07, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }));
  steam.frustumCulled = false; room.add(steam);

  // ---- telepon [contact]
  const P = grp('contact');
  bx(P, .2, .02, .4, -1, 1.06, -2.8, mDark, .008);
  const ps = new THREE.Mesh(new THREE.PlaneGeometry(.17, .36), mPhone); ps.rotation.x = -Math.PI / 2; ps.position.set(-1, 1.072, -2.8); P.add(ps);

  // ---- kursor kerja
  bx(room, .9, .12, .85, .5, .85, -2.2, mFab, .05); bx(room, .9, .9, .1, .5, 1.4, -1.8, mFab, .05);
  cy(room, .035, .035, .62, .5, .5, -2.2, mMetal, 12); cy(room, .07, .09, .08, .5, .22, -2.2, mDark, 16); cy(room, .06, .06, .1, .5, .77, -2.2, mDark, 16);
  const cl = new THREE.Group(); cl.position.set(.5, .14, -2.2); room.add(cl);
  for (let i = 0; i < 5; i++) {
    const l = new THREE.Group(); l.rotation.y = i * 1.2566; bx(l, .5, .035, .06, .25, 0, 0, mDark, .012);
    const w = new THREE.Mesh(new THREE.SphereGeometry(.045, 12, 10), mMetal); w.position.set(.48, -.095, 0); w.castShadow = true; l.add(w); cl.add(l);
  }

  // ---- rak buku [about]
  const B = grp('about');
  bx(B, .55, 3.2, .06, -3.72, 1.6, -2.6, mWood, .01); bx(B, .55, 3.2, .06, -3.72, 1.6, -.4, mWood, .01); bx(B, .04, 3.2, 2.2, -3.97, 1.6, -1.5, mWood, 0);
  const shelfY = [.1, .88, 1.66, 2.44, 3.2], bc = ['#9c3d2e', '#2f4858', '#d9a441', '#5b7f6b', '#e8dcc8', '#6b4c7a', '#c76b3a'];
  const bm = bc.map(c => M(c, { roughness: .8 })); // material dipakai ulang → lebih ringan
  shelfY.forEach(y => bx(B, .55, .05, 2.2, -3.72, y, -1.5, mWood, .008));
  // slot buku (posisi/ukuran/warna dekoratif sama persis seperti sebelumnya). Buku portofolio asli menggantikan slot dari atas.
  const bookRows = [[], [], [], []];
  for (let r = 0; r < 4; r++) {
    let z = -2.52;
    while (z < -.55) {
      const w = .05 + rnd() * .07, h = .3 + rnd() * .28;
      if (r === 1 && z + w > -.98 && z < -.52) { z = -.52; continue; } // celah untuk bola dunia
      bookRows[r].push({ r, z, w, h, mi: Math.floor(rnd() * 7) }); z += w + .004;
    }
  }
  const bookSlots = [2, 3, 1, 0].flatMap(r => bookRows[r]); // urutan isi: baris setinggi mata dulu
  const booksG = new THREE.Group(); B.add(booksG);
  const bookMats = new Map(), bookMat = c => { if (!bookMats.has(c)) bookMats.set(c, M(c, { roughness: .8 })); return bookMats.get(c); };
  cy(B, .12, .14, .04, -3.75, .925, -.75, mDark, 16);
  const gl = new THREE.Mesh(new THREE.SphereGeometry(.19, 24, 16), M('#4a7a9c', { roughness: .35, metalness: .2 })); gl.position.set(-3.75, 1.15, -.75); gl.castShadow = true; B.add(gl);

  // ---- poster [gallery]
  const G = grp('gallery');
  [[-1.5, 3.2, 1], [-.3, 3.4, 1.1], [.9, 3.1, .95]].forEach((p, i) => {
    const s = p[2];
    bx(G, .9 * s, 1.2 * s, .05, p[0], p[1], -3.97, M('#2a1d15', { roughness: .5 }), .01); bx(G, .76 * s, 1.06 * s, .02, p[0], p[1], -3.94, mTrim, 0);
    const a = new THREE.Mesh(new THREE.PlaneGeometry(.6 * s, .84 * s), M(0xffffff, { map: posterTexture(i), roughness: .6 })); a.position.set(p[0], p[1], -3.925); G.add(a);
  });

  // ---- rak toko [shop]
  const H = grp('shop');
  bx(H, .06, 2.7, .5, 1.93, 1.35, -3.8, mWood, .008); bx(H, .06, 2.7, .5, 3.87, 1.35, -3.8, mWood, .008); bx(H, 2, 2.7, .03, 2.9, 1.35, -3.97, mWood, 0);
  [.05, .7, 1.35, 2, 2.65].forEach(y => bx(H, 1.96, .05, .5, 2.9, y, -3.8, mWood, .008));
  const pc = ['#ffb066', '#7aa2ff', '#f1ece4', '#7be0b0', '#c76b9a'];
  const shopSlots = []; // 3 baris dekoratif (angka acak asli) + 1 baris atas yang awalnya kosong
  for (let r = 0; r < 3; r++) for (let i = 0; i < 3; i++) shopSlots.push({ r, i, w: .38 + rnd() * .1, h: .35 + rnd() * .15, x: 2.3 + i * .55, decor: true });
  for (let i = 0; i < 3; i++) shopSlots.push({ r: 3, i, w: .42, h: .42, x: 2.3 + i * .55, decor: false });
  const shopOrder = [3, 2, 1, 0].flatMap(r => shopSlots.filter(s => s.r === r));
  const shopG = new THREE.Group(); H.add(shopG);

  // ---- kardus [cart]
  const K = grp('cart');
  bx(K, .9, .6, .9, 2.2, .3, 1.1, mBox, .02); bx(K, .12, .62, .92, 2.2, .3, 1.1, M('#e8d8b8', { roughness: .5 }), .005); bx(K, .5, .35, .5, 2.1, .78, 1.15, mBox, .02).rotation.y = .4;

  // ---- kasur [bed] + nightstand
  const Bd = grp('bed'), mSh = M('#ece6dc', { roughness: .95 }), mPl = M('#f4f0ea', { roughness: .95 });
  bx(Bd, 2.1, .32, 1.5, 2.85, .26, -1.25, mWood, .02); bx(Bd, 2, .2, 1.4, 2.85, .52, -1.25, mSh, .06); bx(Bd, 1.25, .1, 1.46, 2.35, .62, -1.25, M('#5a6f8f', { roughness: 1 }), .04); bx(Bd, .2, .11, 1.47, 2.95, .625, -1.25, mCur, .04);
  bx(Bd, .5, .14, .62, 3.6, .69, -1.65, mPl, .06); bx(Bd, .5, .14, .62, 3.6, .69, -.85, mPl, .06); bx(Bd, .1, 1.1, 1.56, 3.93, .85, -1.25, mWood, .02);
  bx(room, .5, .5, .45, 3.65, .25, -2.4, mWood, .02); bx(room, .46, .03, .41, 3.65, .515, -2.4, mWood, .01); cy(room, .06, .07, .03, 3.65, .545, -2.4, mDark, 16); cy(room, .012, .012, .2, 3.65, .65, -2.4, mMetal, 8); cy(room, .07, .13, .16, 3.65, .82, -2.4, mShade).castShadow = false;
  const bedLight = new THREE.PointLight(0xffb066, 0, 4, 2); bedLight.position.set(3.5, .9, -2.4); room.add(bedLight);

  // ---- saklar lampu [switch] — gaya modern: bingkai krom tipis, plat datar, tombol rocker lebar, garis LED di atas
  const SW_DARK = false; // true → versi grafit matte
  const mSwBezel = M(SW_DARK ? '#9ea2aa' : '#d9dde2', { metalness: 1, roughness: .22 });
  const mSwPlate = M(SW_DARK ? '#2b2c30' : '#f5f5f3', { roughness: SW_DARK ? .6 : .3, clearcoat: SW_DARK ? 0 : .8, clearcoatRoughness: .15 });
  const mSwKey = M(SW_DARK ? '#35363b' : '#eceae6', { roughness: SW_DARK ? .55 : .25, clearcoat: SW_DARK ? 0 : .6 });
  const Sw = grp('switch'), SY = 1.3, SZ = 1.35;
  bx(Sw, .012, .15, .15, 3.994, SY, SZ, mSwBezel, .012);          // bingkai krom
  bx(Sw, .006, .136, .136, 3.987, SY, SZ, mSwPlate, .008);        // plat datar
  const swBtn = new THREE.Group(); swBtn.position.set(3.984, SY, SZ); Sw.add(swBtn); // poros rocker (horizontal, sejajar dinding)
  bx(swBtn, .014, .118, .118, -.008, 0, 0, mSwKey, .01);          // tombol rocker
  const ledMat = new THREE.MeshBasicMaterial({ color: 0x00ff88 }); ledMat.userData.base = ledMat.color.clone();
  const swLed = new THREE.Mesh(new THREE.BoxGeometry(.004, .006, .05), ledMat); swLed.position.set(-.0155, .047, 0); swBtn.add(swLed); // garis LED indikator

  // ---- tanaman lantai
  cy(room, .26, .19, .6, -3.2, .3, 3.3, mTerra, 24);
  for (let i = 0; i < 16; i++) {
    const p = new THREE.Group(); p.position.set(-3.2, .62, 3.3); p.rotation.y = i * .7;
    const l = new THREE.Mesh(new THREE.SphereGeometry(.2, 10, 8), mLeaf); l.scale.set(.5, 1.7, .22); l.position.set(.12 + rnd() * .12, .35 + rnd() * .5, 0); l.rotation.z = -.35 - rnd() * .5; l.castShadow = true; p.add(l); room.add(p);
  }

  // ---- debu di sinar matahari (hanya siang)
  const DN = 70, dg = new THREE.BufferGeometry(), dp = new Float32Array(DN * 3);
  for (let i = 0; i < DN; i++) { dp[i * 3] = -3.5 + rnd() * 4.5; dp[i * 3 + 1] = .6 + rnd() * 3; dp[i * 3 + 2] = .6 + rnd() * 2.2; }
  dg.setAttribute('position', new THREE.BufferAttribute(dp, 3));
  const dust = new THREE.Points(dg, new THREE.PointsMaterial({ color: 0xfff0d0, size: .06, map: softT, transparent: true, opacity: .7, blending: THREE.AdditiveBlending, depthWrite: false, toneMapped: false }));
  dust.frustumCulled = false; room.add(dust);

  // scene statis → matriks dunia dihitung sekali saja (hemat CPU)
  const det = buildDetails({ room, bx, cy, M, mats: { mWood, mTrim, mDark, mMetal, mCer, mTerra } }); // detail tambahan
  scene.updateMatrixWorld(true);
  scene.matrixWorldAutoUpdate = false;

  const refs = {
      mShade, mPend, mBulb, mScreen, skyM, beam, dust, bedLight, swBtn, swLed, lightsOut: false, glows: det.glows, cat: det.cat,
      update(t, cam) { // animasi ringan: jam, uap kopi, debu, animasi saklar, kucing
        det.update(t, cam);
        const targetRot = refs.lightsOut ? -.085 : .085; // rocker miring ke depan/belakang (sumbu horizontal)
        swBtn.rotation.z += (targetRot - swBtn.rotation.z) * .25;
        swBtn.updateMatrixWorld(true);
        const d = new Date(), s = d.getSeconds() + d.getMilliseconds() / 1000, mi = d.getMinutes() + s / 60, hr = d.getHours() % 12 + mi / 60, T = Math.PI * 2;
        sh.rotation.x = s / 60 * T; mh.rotation.x = mi / 60 * T; hh.rotation.x = hr / 12 * T;
        for (let i = 0; i < shP.count; i++) { const x = shB[i * 3], y = shB[i * 3 + 1]; shP.setZ(i, Math.sin(t / 1700 + x * 2.2 + y * .8) * .03 * (1.6 - y) / 3.2 + Math.sin(x * 9) * .012); }
        shP.needsUpdate = true;
        sh.updateMatrixWorld(true); mh.updateMatrixWorld(true); hh.updateMatrixWorld(true); // scene statis → update manual
        for (let i = 0; i < SN; i++) {
          const q = (t / 5000 + i / SN) % 1, a = Math.sin(q * Math.PI) * .22;
          stP[i * 3] = -.45 + Math.sin(q * 7 + i * 1.7) * .025 * q; stP[i * 3 + 1] = 1.16 + q * .4; stP[i * 3 + 2] = -2.8 + Math.cos(q * 5 + i) * .02 * q;
          stC[i * 3] = stC[i * 3 + 1] = stC[i * 3 + 2] = a;
        }
        stG.attributes.position.needsUpdate = stG.attributes.color.needsUpdate = true;
        if (!dust.visible) return;
        for (let i = 0; i < DN; i++) { dp[i * 3 + 1] += Math.sin(t / 1500 + i) * .0004; dp[i * 3] += Math.cos(t / 1800 + i * 2) * .0003; }
        dg.attributes.position.needsUpdate = true;
      },
  };

  // ---- isi rak dinamis (dipanggil saat data dari server berubah)
  const own = m => (m.userData.own = true, m);
  function clearGroup(g) {
    for (const o of [...g.children]) {
      g.remove(o);
      o.traverse(m => { if (!m.isMesh) return; m.geometry.dispose(); if (m.material.userData.own) { m.material.map?.dispose(); m.material.dispose(); } });
    }
  }
  function setBooks(items) {
    clearGroup(booksG);
    bookSlots.forEach((sl, i) => {
      const it = items[i], y0 = shelfY[sl.r] + .025, zc = sl.z + sl.w / 2;
      if (!it) { bx(booksG, .34, sl.h, sl.w, -3.78, y0 + sl.h / 2, zc, bm[sl.mi], .006); return; }
      const h = Math.max(sl.h, .46); // buku portofolio sedikit lebih tinggi, menonjol keluar rak, ada pita label di punggung
      bx(booksG, .34, h, sl.w, -3.755, y0 + h / 2, zc, bookMat(it.color), .006);
      bx(booksG, .006, .045, sl.w * .92, -3.755 + .171, y0 + h * .68, zc, mTrim, 0);
    });
    booksG.updateMatrixWorld(true); // scene statis → update manual
  }
  const priceTex = (name, price) => ct(320, 140, (g, w, h) => {
    g.fillStyle = '#f6efe3'; g.fillRect(0, 0, w, h); g.fillStyle = 'rgba(0,0,0,.08)'; g.fillRect(0, h - 6, w, 6);
    g.textBaseline = 'middle'; g.textAlign = 'center'; g.fillStyle = '#2a1d15'; g.font = '600 30px system-ui,sans-serif';
    let t = name; while (g.measureText(t).width > w - 24 && t.length > 1) t = t.slice(0, -1); if (t !== name) t += '…';
    g.fillText(t, w / 2, 42); g.fillStyle = '#b5481f'; g.font = '800 46px system-ui,sans-serif'; g.fillText(price, w / 2, 98);
  });
  function setProducts(items, fmt) {
    clearGroup(shopG);
    shopOrder.forEach((sl, i) => {
      const it = items[i], by = .075 + sl.r * .65, x = sl.x;
      if (!it) {
        if (!sl.decor) return;
        const col = pc[(sl.i + sl.r * 2) % 5];
        if ((sl.r + sl.i) % 2) cy(shopG, .14, .14, sl.h + .1, x, by + (sl.h + .1) / 2, -3.75, own(M(col, { roughness: .4 })), 20);
        else { bx(shopG, sl.w, sl.h, .3, x, by + sl.h / 2, -3.75, own(M(col, { roughness: .6 })), .01); bx(shopG, sl.w * .7, .08, .005, x, by + sl.h * .55, -3.6, mTrim, 0); }
        return;
      }
      const h = Math.max(.38, Math.min(.5, sl.h)), w = .44;
      bx(shopG, w, h, .3, x, by + h / 2, -3.75, own(M(it.color, { roughness: .6 })), .01);
      const lm = own(new THREE.MeshStandardMaterial({ map: priceTex(it.name, fmt(it.price)), roughness: .7 }));
      const lb = new THREE.Mesh(new THREE.PlaneGeometry(w * .9, w * .9 * 140 / 320), lm);
      lb.position.set(x, by + h * .5, -3.597); lb.receiveShadow = true; shopG.add(lb);
    });
    shopG.updateMatrixWorld(true);
  }

  return { room, hot: room.children.filter(o => o.userData.key), refs, shelves: { setBooks, setProducts } };
}
