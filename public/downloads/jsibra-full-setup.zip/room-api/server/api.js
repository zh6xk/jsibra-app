// API konten + login admin untuk room-portfolio.
// Tanpa dependency (hanya modul bawaan Node 18+). Bisa jalan mandiri (server.js) atau dipasang di app Express yang sudah ada.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const MAX = { books: 40, products: 12 };
const HEX = /^#[0-9a-f]{6}$/i;
const COOKIE = 'rp_admin';
const TTL = 7 * 24 * 3600; // masa login (detik)

const DEFAULTS = () => ({
  version: 1,
  currency: 'Rp',
  books: [
    { id: 'b1', title: 'Aplikasi Fintech', desc: 'UX · React · 2025', url: '', color: '#2f4858' },
    { id: 'b2', title: 'Website 3D Brand X', desc: 'Three.js · 2026', url: '', color: '#d9a441' },
    { id: 'b3', title: 'Dashboard Analytics', desc: 'Next.js · 2024', url: '', color: '#5b7f6b' },
  ],
  products: [
    { id: 'p1', name: 'UI Kit Dashboard', desc: '', price: 49000, color: '#ffb066' },
    { id: 'p2', name: 'Preset Lightroom Pack', desc: '', price: 25000, color: '#7aa2ff' },
    { id: 'p3', name: 'Template Portfolio', desc: '', price: 79000, color: '#7be0b0' },
  ],
});

const fail = (status, message) => Object.assign(new Error(message), { status });
const str = (v, n) => (typeof v === 'string' ? v.trim().slice(0, n) : '');
const color = (v, d) => (typeof v === 'string' && HEX.test(v) ? v.toLowerCase() : d);

const CLEAN = {
  books(b) {
    const title = str(b?.title, 60); if (!title) throw fail(400, 'Judul wajib diisi');
    const url = str(b.url, 300); if (url && !/^https?:\/\//i.test(url)) throw fail(400, 'Link harus diawali http:// atau https://');
    return { title, desc: str(b.desc, 160), url, color: color(b.color, '#9c3d2e') };
  },
  products(b) {
    const name = str(b?.name, 40); if (!name) throw fail(400, 'Nama produk wajib diisi');
    const price = Number(b.price);
    if (!Number.isFinite(price) || price < 0 || price > 1e9) throw fail(400, 'Harga tidak valid');
    return { name, desc: str(b.desc, 160), price: Math.round(price * 100) / 100, color: color(b.color, '#ffb066') };
  },
};

export function createApi({ dataDir, passwordHash = '', secret, trustProxy = true, basePath = '/api/room' }) {
  if (!secret) { secret = crypto.randomBytes(32).toString('hex'); console.warn('[room-api] SESSION_SECRET kosong: login akan hilang tiap server restart.'); }
  fs.mkdirSync(dataDir, { recursive: true });
  const file = path.join(dataDir, 'content.json');
  let content;
  const persist = () => { const tmp = file + '.tmp'; fs.writeFileSync(tmp, JSON.stringify(content, null, 2)); fs.renameSync(tmp, file); };
  try {
    content = JSON.parse(fs.readFileSync(file, 'utf8'));
    if (!Array.isArray(content.books) || !Array.isArray(content.products)) throw new Error('format');
  } catch { content = DEFAULTS(); persist(); }

  const view = () => ({ version: content.version, currency: content.currency || 'Rp', books: content.books, products: content.products });

  // ---- live (Server-Sent Events)
  const clients = new Set();
  const beat = setInterval(() => { for (const r of clients) r.write(': ping\n\n'); }, 25000); beat.unref?.();
  const commit = () => { content.version++; persist(); for (const r of clients) r.write(`event: update\ndata: ${content.version}\n\n`); };

  // ---- auth
  const sign = exp => crypto.createHmac('sha256', secret).update('admin.' + exp).digest('base64url');
  const token = () => { const exp = Math.floor(Date.now() / 1000) + TTL; return exp + '.' + sign(exp); };
  function isAdmin(req) {
    const m = new RegExp('(?:^|;\\s*)' + COOKIE + '=([^;]+)').exec(req.headers.cookie || ''); if (!m) return false;
    const [exp, sig] = m[1].split('.'); if (!exp || !sig || +exp < Date.now() / 1000) return false;
    const a = Buffer.from(sig), b = Buffer.from(sign(exp));
    return a.length === b.length && crypto.timingSafeEqual(a, b);
  }
  function checkPassword(pw) {
    const [alg, salt, hash] = String(passwordHash).split('$'); if (alg !== 'scrypt' || !salt || !hash) return false;
    const want = Buffer.from(hash, 'hex'), got = crypto.scryptSync(String(pw), Buffer.from(salt, 'hex'), want.length);
    return got.length === want.length && crypto.timingSafeEqual(got, want);
  }
  const ipOf = req => (trustProxy && String(req.headers['x-forwarded-for'] || '').split(',')[0].trim()) || req.socket.remoteAddress || '?';
  const fails = new Map(); // ip -> {n, until}
  const secure = req => req.socket.encrypted || (trustProxy && req.headers['x-forwarded-proto'] === 'https');
  const cookie = (req, v, age) => `${COOKIE}=${v}; Path=${basePath}; HttpOnly; SameSite=Strict; Max-Age=${age}${secure(req) ? '; Secure' : ''}`;

  // ---- util HTTP
  const send = (res, status, body, headers = {}) => {
    res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff', ...headers });
    res.end(JSON.stringify(body));
  };
  const readJson = req => new Promise((ok, no) => {
    let n = 0; const parts = [];
    req.on('data', c => { n += c.length; if (n > 32 * 1024) { no(fail(413, 'Data terlalu besar')); req.destroy(); } else parts.push(c); });
    req.on('end', () => { try { ok(parts.length ? JSON.parse(Buffer.concat(parts).toString('utf8')) : {}); } catch { no(fail(400, 'JSON tidak valid')); } });
    req.on('error', no);
  });
  function csrf(req) { // cookie SameSite=Strict + header khusus + cek Origin
    if (req.headers['x-requested-with'] !== 'room') throw fail(403, 'Permintaan ditolak');
    const o = req.headers.origin;
    if (o) { let h; try { h = new URL(o).host; } catch { h = ''; } if (h !== req.headers.host) throw fail(403, 'Origin tidak cocok'); }
  }
  const needAdmin = req => { if (!isAdmin(req)) throw fail(401, 'Belum login'); };
  const done = res => send(res, 200, { ok: true, content: view() });

  async function dispatch(req, res, route) {
    const M = req.method;
    if (M === 'GET' && route === '/content') return send(res, 200, view());
    if (M === 'GET' && route === '/me') return send(res, 200, { admin: isAdmin(req) });
    if (M === 'GET' && route === '/stream') {
      res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-store, no-transform', Connection: 'keep-alive', 'X-Accel-Buffering': 'no' });
      res.write('retry: 3000\n\n'); clients.add(res); req.on('close', () => clients.delete(res)); return;
    }
    if (M === 'GET') throw fail(404, 'Tidak ditemukan');
    csrf(req);

    if (M === 'POST' && route === '/login') {
      const ip = ipOf(req), f = fails.get(ip);
      if (f && f.n >= 5 && f.until > Date.now()) throw fail(429, 'Terlalu banyak percobaan. Coba lagi beberapa menit lagi.');
      if (!passwordHash) throw fail(503, 'Admin belum dikonfigurasi di server');
      const { password } = await readJson(req);
      if (!checkPassword(password ?? '')) {
        const n = (f && f.until > Date.now() ? f.n : 0) + 1; fails.set(ip, { n, until: Date.now() + 15 * 60 * 1000 });
        await new Promise(r => setTimeout(r, 500)); throw fail(401, 'Password salah');
      }
      fails.delete(ip);
      return send(res, 200, { ok: true }, { 'Set-Cookie': cookie(req, token(), TTL) });
    }
    if (M === 'POST' && route === '/logout') return send(res, 200, { ok: true }, { 'Set-Cookie': cookie(req, '', 0) });

    needAdmin(req);
    if (M === 'PUT' && route === '/settings') {
      const b = await readJson(req); const c = str(b.currency, 4); if (!c) throw fail(400, 'Mata uang tidak boleh kosong');
      content.currency = c; commit(); return done(res);
    }
    const m = /^\/(books|products)(?:\/([a-f0-9]{1,16}))?(\/move)?$/.exec(route);
    if (!m) throw fail(404, 'Tidak ditemukan');
    const [, coll, id, move] = m, list = content[coll];
    if (M === 'POST' && !id) {
      if (list.length >= MAX[coll]) throw fail(400, `Maksimal ${MAX[coll]} item`);
      list.push({ id: crypto.randomBytes(4).toString('hex'), ...CLEAN[coll](await readJson(req)) }); commit(); return done(res);
    }
    const i = list.findIndex(x => x.id === id);
    if (!id || i < 0) throw fail(404, 'Item tidak ditemukan');
    if (M === 'PUT' && !move) { list[i] = { id, ...CLEAN[coll](await readJson(req)) }; commit(); return done(res); }
    if (M === 'DELETE' && !move) { list.splice(i, 1); commit(); return done(res); }
    if (M === 'POST' && move) {
      const d = (await readJson(req)).dir === -1 ? -1 : 1, j = i + d;
      if (j >= 0 && j < list.length) { [list[i], list[j]] = [list[j], list[i]]; commit(); }
      return done(res);
    }
    throw fail(405, 'Metode tidak didukung');
  }

  // true = permintaan ditangani (milik API ini), false = bukan urusan API
  async function handle(req, res) {
    const p = new URL(req.url, 'http://x').pathname;
    if (p !== basePath && !p.startsWith(basePath + '/')) return false;
    try { await dispatch(req, res, p.slice(basePath.length) || '/'); }
    catch (e) { if (!e.status) console.error('[room-api]', e); if (!res.headersSent) send(res, e.status || 500, { error: e.status ? e.message : 'Kesalahan server' }); }
    return true;
  }
  return { handle };
}
