// Tekstur prosedural (canvas). Nanti bisa diganti file KTX2/WebP hasil bake dari Blender.
import * as THREE from 'three';

export const rnd = (s => () => (s = (s * 16807) % 2147483647) / 2147483647)(42);

export function ct(w, h, fn, rx = 1, ry = 1) {
  const c = document.createElement('canvas');
  c.width = w; c.height = h;
  fn(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(rx, ry);
  t.anisotropy = 4;
  return t;
}

export const wood = (b, rx, ry, pw) => ct(512, 512, (g, w, h) => {
  for (let x = 0; x < w; x += pw) {
    g.fillStyle = `hsl(${b[0]},${b[1]}%,${b[2] * (.85 + rnd() * .3)}%)`;
    g.fillRect(x, 0, pw, h);
    for (let i = 0; i < 40; i++) {
      g.strokeStyle = `rgba(0,0,0,${.03 + rnd() * .07})`;
      g.beginPath();
      const gx = x + rnd() * pw;
      g.moveTo(gx, 0);
      g.bezierCurveTo(gx + rnd() * 6 - 3, h / 3, gx + rnd() * 6 - 3, 2 * h / 3, gx + rnd() * 4 - 2, h);
      g.stroke();
    }
    g.fillStyle = 'rgba(0,0,0,.35)';
    g.fillRect(x, 0, 2, h);
  }
}, rx, ry);

export const plaster = (rx, ry) => ct(512, 512, (g, w, h) => {
  g.fillStyle = '#e6d3bf'; g.fillRect(0, 0, w, h);
  // bercak besar berskala rendah (mottling cat/plester) — digambar dengan wrap agar tile mulus; memecah kesan pola berulang
  for (let i = 0; i < 46; i++) {
    const x = rnd() * w, y = rnd() * h, r = 50 + rnd() * 130, dark = rnd() > .5, a = .035 + rnd() * .045;
    for (const [ox, oy] of [[0, 0], [w, 0], [-w, 0], [0, h], [0, -h]]) {
      const q = g.createRadialGradient(x + ox, y + oy, 0, x + ox, y + oy, r);
      q.addColorStop(0, dark ? `rgba(70,45,25,${a})` : `rgba(255,248,235,${a})`); q.addColorStop(1, 'rgba(0,0,0,0)');
      g.fillStyle = q; g.fillRect(x + ox - r, y + oy - r, r * 2, r * 2);
    }
  }
  for (let i = 0; i < 9000; i++) { g.fillStyle = rnd() > .5 ? 'rgba(255,255,255,.05)' : 'rgba(0,0,0,.04)'; g.fillRect(rnd() * w, rnd() * h, 2, 2); }
}, rx, ry);

export const rugTexture = () => ct(512, 360, (g, w, h) => {
  g.fillStyle = '#9c4a3a'; g.fillRect(0, 0, w, h);
  g.strokeStyle = '#e8d2b0'; g.lineWidth = 8; g.strokeRect(24, 24, w - 48, h - 48);
  g.lineWidth = 3; g.strokeRect(44, 44, w - 88, h - 88);
  g.fillStyle = '#e8d2b0';
  for (let i = 0; i < 5; i++) { const x = 110 + i * 70; g.beginPath(); g.moveTo(x, h / 2 - 40); g.lineTo(x + 30, h / 2); g.lineTo(x, h / 2 + 40); g.lineTo(x - 30, h / 2); g.fill(); }
  for (let i = 0; i < 5000; i++) { g.fillStyle = rnd() > .5 ? 'rgba(255,255,255,.06)' : 'rgba(0,0,0,.07)'; g.fillRect(rnd() * w, rnd() * h, 2, 2); }
});

export const screenTexture = () => ct(512, 320, (g, w, h) => {
  const r = g.createLinearGradient(0, 0, w, h); r.addColorStop(0, '#1d2a44'); r.addColorStop(1, '#3a2450');
  g.fillStyle = r; g.fillRect(0, 0, w, h);
  g.fillStyle = 'rgba(255,255,255,.08)'; g.fillRect(0, 0, w, 26);
  ['#ff6b6b', '#ffd166', '#06d6a0'].forEach((c, i) => { g.fillStyle = c; g.beginPath(); g.arc(16 + i * 18, 13, 5, 0, 7); g.fill(); });
  g.fillStyle = '#fff'; g.font = 'bold 36px sans-serif'; g.fillText('Ibra Farawowan', 30, 100);
  g.font = '18px sans-serif'; g.fillStyle = '#ffb066'; g.fillText('Developer · Designer · Creator', 30, 132);
  [0, 1, 2].forEach(i => { g.fillStyle = 'rgba(255,255,255,.12)'; g.fillRect(30 + i * 150, 170, 135, 110); g.fillStyle = ['#ffb066', '#7aa2ff', '#7be0b0'][i]; g.fillRect(30 + i * 150, 170, 135, 60); });
});

export const posterTexture = i => ct(256, 340, (g, w, h) => {
  const c = [['#ffb066', '#c2410c'], ['#7aa2ff', '#312e81'], ['#7be0b0', '#065f46']][i];
  const r = g.createLinearGradient(0, 0, w, h); r.addColorStop(0, c[0]); r.addColorStop(1, c[1]);
  g.fillStyle = r; g.fillRect(0, 0, w, h);
  g.fillStyle = 'rgba(255,255,255,.85)'; g.beginPath(); g.arc(w / 2, h * .38, 60 + i * 12, 0, 7); g.fill();
  g.fillStyle = 'rgba(0,0,0,.28)'; g.beginPath(); g.moveTo(0, h); g.lineTo(w * .4, h * .6); g.lineTo(w * .7, h * .85); g.lineTo(w, h * .55); g.lineTo(w, h); g.fill();
});

export const skyTexture = m => ct(256, 256, (g, w, h) => {
  const r = g.createLinearGradient(0, 0, 0, h), n = m === 2;
  if (n) { r.addColorStop(0, '#05081a'); r.addColorStop(1, '#1c2a52'); }
  else if (m === 1) { r.addColorStop(0, '#3b2a6b'); r.addColorStop(.55, '#d9627a'); r.addColorStop(1, '#ffb866'); }
  else { r.addColorStop(0, '#6fb1ff'); r.addColorStop(1, '#ffe3b0'); }
  g.fillStyle = r; g.fillRect(0, 0, w, h);
  if (n) {
    g.fillStyle = '#fff'; for (let i = 0; i < 60; i++) g.fillRect(rnd() * w, rnd() * h * .7, 1.5, 1.5);
    g.fillStyle = '#fff6d6'; g.beginPath(); g.arc(180, 60, 14, 0, 7); g.fill();
  } else {
    g.fillStyle = m === 1 ? 'rgba(255,170,140,.55)' : 'rgba(255,255,255,.7)';
    for (let i = 0; i < 5; i++) { g.beginPath(); g.ellipse(rnd() * w, 40 + rnd() * 100, 40, 12, 0, 0, 7); g.fill(); }
  }
});

export const blobTexture = () => ct(64, 64, g => {
  const r = g.createRadialGradient(32, 32, 0, 32, 32, 32); r.addColorStop(0, 'rgba(0,0,0,.6)'); r.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = r; g.fillRect(0, 0, 64, 64);
});

export const edgeTexture = () => ct(8, 64, g => {
  const r = g.createLinearGradient(0, 0, 0, 64); r.addColorStop(0, 'rgba(0,0,0,.55)'); r.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = r; g.fillRect(0, 0, 8, 64);
});

export const beamTexture = () => ct(64, 256, (g, w, h) => {
  const r = g.createLinearGradient(0, 0, 0, h); r.addColorStop(0, 'rgba(255,230,180,0)'); r.addColorStop(1, 'rgba(255,230,180,.9)');
  g.fillStyle = r; g.fillRect(0, 0, w, h);
  g.globalCompositeOperation = 'destination-in';
  const q = g.createLinearGradient(0, 0, w, 0); q.addColorStop(0, 'rgba(0,0,0,0)'); q.addColorStop(.3, '#000'); q.addColorStop(.7, '#000'); q.addColorStop(1, 'rgba(0,0,0,0)');
  g.fillStyle = q; g.fillRect(0, 0, w, h);
});

// Normal map prosedural dari tekstur canvas (alur kayu, plester) → relief nyata di bawah cahaya
export function normalMap(src, k = 2) {
  const w = src.image.width, h = src.image.height, d = src.image.getContext('2d').getImageData(0, 0, w, h).data, H = new Float32Array(w * h);
  for (let i = 0; i < w * h; i++) H[i] = (d[i * 4] * .3 + d[i * 4 + 1] * .59 + d[i * 4 + 2] * .11) / 255;
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'), o = g.createImageData(w, h), at = (x, y) => H[((y + h) % h) * w + ((x + w) % w)];
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const dx = (at(x + 1, y) - at(x - 1, y)) * k, dy = (at(x, y + 1) - at(x, y - 1)) * k, l = Math.hypot(dx, dy, 1), i = (y * w + x) * 4;
    o.data[i] = (-dx / l * .5 + .5) * 255; o.data[i + 1] = (dy / l * .5 + .5) * 255; o.data[i + 2] = (1 / l * .5 + .5) * 255; o.data[i + 3] = 255;
  }
  g.putImageData(o, 0, 0);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8; return t;
}

// Roughness map prosedural dari tekstur albedo: kanal G = faktor pengali roughness material (nilai < 1 = lebih halus/mengilap).
// invert=true → area gelap (celah papan, serat) lebih kasar; bercak aus berskala rendah memberi variasi pantulan di lantai/dinding.
export function roughnessMap(src, lo = .6, hi = 1, invert = false, wear = .25) {
  const w = src.image.width, h = src.image.height, d = src.image.getContext('2d').getImageData(0, 0, w, h).data;
  const N = 8, lat = Array.from({ length: N * N }, () => rnd()), smooth = t => t * t * (3 - 2 * t);
  const noise = (x, y) => { const fx = x / w * N, fy = y / h * N, x0 = Math.floor(fx), y0 = Math.floor(fy), tx = smooth(fx - x0), ty = smooth(fy - y0), L = (a, b) => lat[((b % N + N) % N) * N + ((a % N + N) % N)];
    return (L(x0, y0) * (1 - tx) + L(x0 + 1, y0) * tx) * (1 - ty) + (L(x0, y0 + 1) * (1 - tx) + L(x0 + 1, y0 + 1) * tx) * ty; };
  const c = document.createElement('canvas'); c.width = w; c.height = h;
  const g = c.getContext('2d'), o = g.createImageData(w, h);
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const i = (y * w + x) * 4, l = (d[i] * .3 + d[i + 1] * .59 + d[i + 2] * .11) / 255, t = Math.min(1, Math.max(0, invert ? 1 - l : l));
    const r = Math.min(1, lo + (hi - lo) * t + (noise(x, y) - .5) * wear * 2 * (hi - lo)), v = r * 255;
    o.data[i] = o.data[i + 1] = o.data[i + 2] = v; o.data[i + 3] = 255;
  }
  g.putImageData(o, 0, 0);
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.anisotropy = 8; return t;
}
