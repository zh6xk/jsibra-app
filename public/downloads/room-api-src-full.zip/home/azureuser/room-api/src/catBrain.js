// Otak kucing: mesin keadaan perhatian + pengendali pandangan "saccade" (murni logika, tanpa THREE → bisa diuji di Node).
//
// Kenapa terasa lebih hidup dibanding "kepala menempel ke pemain":
//  - Hewan TIDAK melacak terus-menerus. Kepala berpindah cepat (saccade, profil minimum-jerk), lalu DIAM menatap,
//    dan baru berpindah lagi kalau target keluar dari zona mati. Di sela itu hanya ada gerakan mikro.
//  - Ada latensi reaksi (membeku sebentar → baru menoleh), dan reaksi lebih cepat bila pemain datang mendadak.
//  - Perhatian punya "minat" yang menurun: kucing sesekali membuang pandang, lalu kembali, atau akhirnya bosan.
//  - Badan memutar per "pivot" (langkah putar terpisah), bukan berputar halus tanpa henti. Pandangan disimpan di
//    koordinat DUNIA, jadi saat badan berputar kepala tetap terkunci ke target (stabilisasi seperti kucing asli).
//  - Mendekat cepat ke jarak dekat → kaget (merunduk, membeku), kepercayaan turun. Tenang & diam lama → percaya,
//    kedip lambat, ekor naik, mendengkur.
//
// Pemakaian (per frame):  const o = brain.update(dt, s, { dist, bearing, elev, heading, lookYaw, speed, radial, facing, forced });
// Semua sudut dalam radian. bearing = arah pemain relatif badan (atan2(x,z) di ruang lokal kucing), heading = root.rotation.y.

const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const mj = x => { x = clamp(x, 0, 1); return x * x * x * (10 + x * (-15 + 6 * x)); };          // posisi minimum-jerk
const mjv = x => { x = clamp(x, 0, 1); return 30 * x * x * (1 - x) * (1 - x); };               // kecepatan (integral = 1)
const sstep = x => { x = clamp(x, 0, 1); return x * x * (3 - 2 * x); };

export function createCatBrain(opt = {}) {
  const rng = opt.rng || Math.random, R = (a, b) => a + (b - a) * rng();
  const ENTER = opt.enter ?? 2.2, EXIT = opt.exit ?? 3.0;       // histeresis: masuk 2,2 m, baru "lepas" di 3,0 m (tidak berkedip di batas)
  const DEAD_Y = opt.deadYaw ?? .2, DEAD_P = opt.deadPitch ?? .15;   // zona mati pandangan (±11° / ±9°)
  const STARTLE_V = opt.startleSpeed ?? 1.15;                    // kecepatan mendekat (m/dtk) pada jarak dekat yang mengagetkan
  let state = 'unaware', since = 0, cool = 0, trust = opt.trust ?? .3;
  let friendlyUntil = 0, interest = 1, stillFor = 0, awayN = 0, awayUntil = 0, startleCool = 0, lostAt = -1, noticeDelay = .3, pivotArm = 0;
  let nextBlink = R(2, 5), blinkAt = -1, blinkDur = .16, slowAt = -1, nextSlow = R(3, 5);
  let nextFlick = R(1.5, 4), flickUntil = -1, nextTilt = R(3, 7), tiltUntil = 0, tiltTo = 0, tiltV = 0;
  let nextDrift = 0, driftY = 0, driftP = 0, saccades = 0;

  const G = { yaw: 0, pitch: 0, fromY: 0, toY: 0, fromP: 0, toP: 0, t0: 0, T: .2, moving: false, hold: 0, init: false };   // pandangan, yaw di koordinat dunia
  const P = { on: false, t0: 0, T: 1, delta: 0 };                                                                               // pivot badan
  const out = {
    state, alert: false, gazeYaw: 0, gazePitch: 0, saccade: 0, pivotRate: 0, freeze: 0, crouch: 0, earsFwd: 0, earsBack: 0,
    tilt: 0, tailFlick: 0, blink: 0, purrOk: false, trust, interest, saccades: 0,
  };

  function beginGaze(yawW, pitch, s, latency, speedK = 1) {
    const dy = wrap(yawW - G.yaw), amp = Math.hypot(dy, (pitch - G.pitch) * .8);
    G.fromY = G.yaw; G.toY = G.yaw + dy; G.fromP = G.pitch; G.toP = pitch;
    G.T = clamp((.1 + .13 * amp) / speedK, .08, .5);          // sudut besar sedikit lebih lama, tapi tetap cepat (ballistik)
    G.t0 = s + latency; G.moving = true; saccades++;
  }
  function stepGaze(s) {
    if (!G.moving) return;
    const tau = (s - G.t0) / G.T;
    if (tau < 0) return;                                       // masih dalam latensi: kepala belum bergerak
    const k = mj(tau); G.yaw = G.fromY + (G.toY - G.fromY) * k; G.pitch = G.fromP + (G.toP - G.fromP) * k;
    if (tau >= 1) { G.moving = false; G.hold = s + R(.2, .55); }   // masa refrakter: tidak langsung saccade lagi
  }

  function update(dt, s, i) {
    const heading = i.heading || 0, dist = i.dist ?? 99, speed = i.speed || 0, radial = i.radial || 0;
    const active = speed > .25;
    stillFor = active ? 0 : stillFor + dt;
    let near = state === 'unaware' ? dist < ENTER : dist < EXIT;
    if (i.forced === false) near = false; else if (i.forced === true) near = true;
    const dW = heading + (i.bearing || 0), pitchT = i.elev || 0;
    if (!G.init) { G.yaw = heading + (i.lookYaw || 0); G.pitch = .1; G.init = true; }
    if (state === 'unaware') { G.yaw = heading + (i.lookYaw || 0); G.pitch = i.lookPitch ?? G.pitch; G.moving = false; }   // ikuti lirikan santai agar tak melompat saat mulai waspada

    // ---- kaget: mendekat cepat dari jarak dekat (kecuali dipaksa)
    if (state !== 'startle' && i.forced !== true && near && dist < 1.15 && radial < -(STARTLE_V + trust * .5) && s > startleCool) {
      state = 'startle'; since = s; startleCool = s + 7; trust = Math.max(0, trust - .2); P.on = false;
      beginGaze(dW, pitchT, s, 0, 1.8);
    }

    switch (state) {
      case 'unaware':
        if (near && (s >= cool || dist < 1)) {
          state = 'noticed'; since = s; interest = 1; awayN = 0; lostAt = -1;
          noticeDelay = radial < -1 ? R(.08, .16) : R(.18, .4);        // pemain datang mendadak → reaksi lebih cepat
        }
        break;
      case 'noticed':                                                  // membeku & "mendengar" sebelum menoleh
        if (!near) { state = 'unaware'; cool = s + 2; }
        else if (s - since > noticeDelay) { state = 'orient'; since = s; beginGaze(dW, pitchT, s, 0, 1.15); }
        break;
      case 'orient':
        if (!G.moving) { state = 'watch'; since = s; G.hold = s + R(.3, .6); }
        break;
      case 'watch': {
        interest -= dt * (active ? .02 : .065);
        if (active && i.facing > .6) interest = Math.min(1, interest + dt * .1);
        const ey = wrap(dW - G.toY), ep = pitchT - G.toP;
        if (!G.moving && s >= G.hold && (Math.abs(ey) > DEAD_Y || Math.abs(ep) > DEAD_P)) beginGaze(dW, pitchT, s, R(.04, .12));
        else if (G.moving && Math.abs(wrap(dW - G.toY)) > .5) beginGaze(dW, pitchT, s, 0);     // target lari jauh saat bergerak → ganti tujuan
        if (interest < .25) {                                          // bosan menatap → buang pandang sebentar
          state = 'away'; since = s; awayUntil = s + R(1, 2.4);
          beginGaze(dW + (rng() < .5 ? -1 : 1) * R(.5, .9), clamp(pitchT + R(-.1, .15), -.4, .35), s, 0, .8);
        } else if (trust > .45 && dist < 1.8 && stillFor > 5 && s - since > 6) { state = 'friendly'; since = s; nextSlow = s + 1.2; friendlyUntil = s + R(15, 30); }
        break;
      }
      case 'away':
        if (s > awayUntil && !G.moving) {
          if (active || i.facing > .85) { state = 'watch'; since = s; interest = .7; beginGaze(dW, pitchT, s, R(.05, .15)); }
          else if (awayN >= 2) { state = 'unaware'; cool = s + 10; }       // tidak ada yang terjadi → kembali santai (jalan/jilat/regang)
          else { awayN++; interest = .45; state = 'watch'; since = s; beginGaze(dW, pitchT, s, R(.1, .3)); }
        }
        break;
      case 'friendly': {
        const ey = wrap(dW - G.toY);
        if (!G.moving && s >= G.hold && Math.abs(ey) > DEAD_Y * 1.5) beginGaze(dW, pitchT, s, R(.1, .25), .7);   // lebih santai: gerak kepala lambat
        if (speed > 1.1 || dist > 2.4) { state = 'watch'; since = s; interest = .8; }
        else if (s > friendlyUntil) { state = 'unaware'; cool = s + 15; }              // puas → santai lagi (jalan / jilat bulu / tidur-tiduran)
        else trust = Math.min(1, trust + dt * .01);
        break;
      }
      case 'startle':
        if (s - since > 1.0 && !G.moving) { state = 'watch'; since = s; interest = 1; G.hold = s + .5; }
        break;
    }
    if (state !== 'unaware' && !near) {                                // pemain pergi: tatapan masih membekas ±0,8 dtk
      if (lostAt < 0) lostAt = s; else if (s - lostAt > .8) { state = 'unaware'; cool = s + 3; lostAt = -1; G.moving = false; }
    } else lostAt = -1;
    if ((state === 'watch' || state === 'friendly') && dist < 2 && !active) trust = Math.min(1, trust + dt * .006);

    // ---- gerak mikro saat menatap (sangat kecil; bukan ayunan sinus)
    if (s > nextDrift) { driftY = R(-.03, .03); driftP = R(-.02, .02); nextDrift = s + R(.5, 1.6); }
    stepGaze(s);

    // ---- pivot badan: bila kepala sudah terlalu menoleh (lama), atau pemain diam lama di samping → badan memutar satu langkah
    const rel = wrap(G.yaw - heading);
    if (!P.on && (state === 'watch' || state === 'friendly')) {
      if (Math.abs(rel) > 1.1) pivotArm += dt; else if (Math.abs(rel) < .6) pivotArm = 0;
      if (pivotArm > .25 || (Math.abs(rel) > .65 && stillFor > 2.5 && !G.moving)) {
        P.delta = rel - Math.sign(rel) * .2; P.T = clamp(.5 + .55 * Math.abs(P.delta), .6, 1.7); P.t0 = s; P.on = true; pivotArm = 0;
      }
    }
    let pivotRate = 0;
    if (P.on) { const tau = (s - P.t0) / P.T; if (tau >= 1 || state === 'unaware' || state === 'startle') P.on = false; else pivotRate = P.delta / P.T * mjv(tau); }

    // ---- kedip, kibasan ekor, miring kepala
    let blink = 0;
    if (blinkAt < 0 && s > nextBlink) { blinkAt = s; blinkDur = R(.13, .2); }
    if (blinkAt >= 0) { const p = (s - blinkAt) / blinkDur; if (p >= 1) { blinkAt = -1; nextBlink = s + R(2.5, 7); } else blink = Math.sin(Math.PI * p); }
    if (state === 'friendly') {                                       // kedip lambat = tanda percaya pada kucing
      if (slowAt < 0 && s > nextSlow) slowAt = s;
      if (slowAt >= 0) {
        // tutup ±35% durasi (p <= 0.35), tahan sebentar (0.35 .. 0.5), buka pelan (0.5 .. 1.0)
        const p = (s - slowAt) / 1.1;
        if (p >= 1) { slowAt = -1; nextSlow = s + R(3.5, 6); }
        else if (p < 0.35) blink = Math.max(blink, sstep(p / 0.35));
        else if (p < 0.5) blink = 1;
        else blink = Math.max(blink, 1 - sstep((p - 0.5) / 0.5));
      }
    } else slowAt = -1;
    if (state === 'startle') {
      blink = Math.max(blink, 0.15); // mata menyipit 15% saat kaget
    }
    if (s > nextFlick) { flickUntil = s + R(.35, .6); nextFlick = s + R(1.5, 4); }
    const flick = (state === 'watch' || state === 'orient' || state === 'friendly') && s < flickUntil ? 1 : 0;
    if ((state === 'watch' || state === 'friendly') && s > nextTilt) { tiltTo = (rng() < .5 ? -1 : 1) * R(.1, .22); tiltUntil = s + R(1.2, 2.2); nextTilt = s + R(5, 11); }
    if (s > tiltUntil) tiltTo = 0;
    tiltV += (tiltTo - tiltV) * (1 - Math.exp(-dt * 5));

    // ---- keluaran
    const inAlert = state !== 'unaware';
    out.state = state; out.alert = inAlert;
    out.gazeYaw = clamp(wrap(G.yaw - heading) + (G.moving ? 0 : driftY), -1.75, 1.75);
    out.gazePitch = clamp(G.pitch + (G.moving ? 0 : driftP), -.55, .4);
    out.saccade = G.moving && s >= G.t0 ? 1 : 0;
    out.pivotRate = pivotRate;
    out.freeze = state === 'noticed' ? 1 : state === 'startle' ? (s - since < .55 ? 1 : .4) : 0;
    out.crouch = state === 'startle' ? (s - since < .8 ? 1 : .5) : (state === 'watch' && radial < -.3 && dist < 1.6 ? .35 : 0);
    out.earsFwd = state === 'orient' || state === 'watch' || state === 'friendly' ? 1 : 0;
    out.earsBack = state === 'startle' ? 1 : state === 'away' ? .3 : 0;
    out.tilt = tiltV; out.tailFlick = flick; out.blink = blink;
    out.purrOk = state === 'friendly'; out.trust = trust; out.interest = interest; out.saccades = saccades;
    return out;
  }
  return { update, get state() { return state; }, get trust() { return trust; }, get saccades() { return saccades; } };
}
