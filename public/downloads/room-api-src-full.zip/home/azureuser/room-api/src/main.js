import './style.css';
import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { GTAOPass } from 'three/examples/jsm/postprocessing/GTAOPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { VolumetricPass } from './volumetrics.js';
import { ShaderPass } from 'three/examples/jsm/postprocessing/ShaderPass.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { buildRoom } from './room.js';
import { createLighting, PRESETS, MODES, LUM_REF } from './lighting.js';
import { LumaPass, stepExposure } from './autoExposure.js';
import { createControls } from './controls.js';
import { createUI } from './ui.js';
import { createSettings, loadCfg, saveCfg, QUALITY } from './settings.js';
import { createAudio } from './audio.js';
import { store, setStore, fmt } from './content.js';
import { api, subscribe } from './api.js';
import { createAdmin } from './admin.js';

const canvas = document.getElementById('c');
const DEBUG_CAM = /catdebug/.test(location.search);
const renderer = new THREE.WebGLRenderer({ canvas, antialias: false, powerPreference: 'high-performance' }); // AA lewat MSAA render target composer
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.shadowMap.autoUpdate = false; // scene statis → shadow map dihitung saat cahaya berubah saja
renderer.shadowMap.needsUpdate = true;

// ---- deteksi GPU → preset awal otomatis (bisa diubah di ⚙ Grafis; ?q=low / ?q=high memaksa)
const glc = renderer.getContext(), dbg = glc.getExtension('WEBGL_debug_renderer_info');
const gpu = dbg ? glc.getParameter(dbg.UNMASKED_RENDERER_WEBGL) : 'tidak diketahui';
console.info('[GPU]', gpu);
const soft = /swiftshader|llvmpipe|software|basic render/i.test(gpu);
const isMobile = matchMedia('(pointer:coarse)').matches;
const isUnknownOrEmpty = !gpu || gpu === 'tidak diketahui';
const weak = soft || isMobile || (isUnknownOrEmpty && isMobile);
const q = new URLSearchParams(location.search).get('q');
const auto = q === 'low' ? 'rendah' : q === 'high' ? 'tinggi' : weak ? 'rendah' : 'sedang';
const cfg = loadCfg(auto, !!q);
const basePresetScale = QUALITY[cfg.preset]?.scale ?? cfg.scale;
let pr = cfg.scale;
renderer.setPixelRatio(pr);
if (soft || new URLSearchParams(location.search).has('debug')) {
  const n = document.createElement('div');
  n.style.cssText = 'position:fixed;left:16px;bottom:100px;max-width:340px;padding:8px 12px;border-radius:10px;background:rgba(28,21,17,.9);border:1px solid #ffb066;color:#fff3e4;font:12px/1.4 system-ui;z-index:9';
  n.textContent = `GPU terpakai: ${gpu}. ${soft ? 'Ini rendering software (CPU)!' : ''} Atur kualitas di ⚙ Grafis.`;
  document.body.append(n); setTimeout(() => n.remove(), 12000);
}

const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(62, 1, .1, 60);
const state = { focus: null, sleeping: false, walk: false };

const world = buildRoom(scene);
const lighting = createLighting(scene, renderer, world.refs);
const ui = createUI(state);
const ctl = createControls(state, camera, canvas, world.hot, ui);

ui.onWalk(ctl.toggleWalk);
ui.bindPad(ctl.keys);
let lightsOut = false;
ui.onSwitch(() => {
  lightsOut = !lightsOut;
  lighting.setBlackout(lightsOut);
  const hint = document.getElementById('hint');
  hint.textContent = lightsOut ? '💡 Lampu ruangan dimatikan' : '💡 Lampu ruangan dinyalakan';
  setTimeout(() => { hint.textContent = state.walk ? 'Mouse = menoleh · WASD jalan · klik area kosong untuk kunci kursor (Esc: lepas) · F: keluar' : 'Klik tahan & geser untuk menoleh · F: mode jalan'; }, 3000);
});
const audio = createAudio();
addEventListener('cat-sound', e => { const d = e.detail; if (!audio.started) return; d.type === 'purr' ? audio.purr(d.vol, d.pan, d.dur) : audio.meow(d.vol, d.pan, d.kind); });   // suara kucing dari cat.js
const setTime = m => { ui.setTimeUI(lighting.setTime(m)); audio.setMode(m); };
ui.onTime(() => setTime((lighting.mode + 1) % 3)); // pagi → senja → malam
scene.updateMatrixWorld(true); // lampu ditambahkan setelah room → hitung matriks sekali lagi
setTime(0); // label awal harus sesuai mode (Pagi → tombol "Senja")

// ---- post-processing: AO, bloom, grading + vignette + grain, tone mapping
const rt = new THREE.WebGLRenderTarget(innerWidth * pr, innerHeight * pr, { type: THREE.HalfFloatType, samples: Math.min(cfg.msaa, renderer.capabilities.maxSamples) });
rt.depthTexture = new THREE.DepthTexture(innerWidth * pr, innerHeight * pr); // kedalaman scene → dipakai god rays
const composer = new EffectComposer(renderer, rt);
composer.addPass(new RenderPass(scene, camera));
const vol = new VolumetricPass(camera, { ...lighting.lights, bed: world.refs.bedLight }); // harus tepat setelah RenderPass (membaca depth-nya)
composer.addPass(vol);
const luma = new LumaPass(8); composer.addPass(luma); // ukur luminans layar → eksposur adaptif (lihat autoExposure.js)

const decals = []; scene.traverse(o => { if (o.isMesh && o.material.transparent) decals.push(o); }); // kaca, tirai tipis, sinar, bayangan palsu → tidak ikut AO
const gtao = new GTAOPass(scene, camera, innerWidth, innerHeight);
gtao.output = GTAOPass.OUTPUT.Default;
gtao.updateGtaoMaterial({ radius: .3, distanceExponent: 1.4, thickness: 1.5, scale: 1, samples: 12, distanceFallOff: 1 });
gtao.updatePdMaterial({ lumaPhi: 10, depthPhi: 2, normalPhi: 3, radius: 8, rings: 2, samples: 16 });
const gtaoRender = gtao.render.bind(gtao);
gtao.render = (...a) => { decals.forEach(o => o.visible = false); gtaoRender(...a); decals.forEach(o => o.visible = true); };
composer.addPass(gtao);

const bloom = new UnrealBloomPass(new THREE.Vector2(innerWidth, innerHeight), .25, .7, 1);
composer.addPass(bloom);

const grade = new ShaderPass({
  uniforms: { tDiffuse: { value: null }, time: { value: 0 }, vig: { value: .32 }, grain: { value: .035 }, ca: { value: .0012 } },
  vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.); }',
  fragmentShader: `uniform sampler2D tDiffuse; uniform float time, vig, grain, ca; varying vec2 vUv;
    float hash(vec2 p){ return fract(sin(dot(p, vec2(12.9898, 78.233)) + time) * 43758.5453); }
    void main(){
      vec2 d = vUv - .5; float r = dot(d, d);
      vec3 c = vec3(texture2D(tDiffuse, vUv + d * ca * r * 8.).r, texture2D(tDiffuse, vUv).g, texture2D(tDiffuse, vUv - d * ca * r * 8.).b);
      c *= 1. - vig * smoothstep(.1, .75, r * 1.6);
      float l = dot(c, vec3(.2126, .7152, .0722));
      c = mix(c, c * vec3(1.04, 1., .94), smoothstep(.3, 1., l));   // highlight hangat
      c *= mix(vec3(.96, .99, 1.04), vec3(1.), smoothstep(0., .3, l)); // bayangan sedikit dingin
      c += (hash(vUv * 1000.) - .5) * grain * .5;
      gl_FragColor = vec4(c, 1.);
    }`,
});
composer.addPass(grade);
composer.addPass(new OutputPass());

function resize() {
  renderer.setPixelRatio(pr); renderer.setSize(innerWidth, innerHeight); composer.setPixelRatio(pr); composer.setSize(innerWidth, innerHeight);
  camera.fov = innerWidth < innerHeight ? cfg.fov + 16 : cfg.fov;
  camera.aspect = innerWidth / innerHeight;
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize);

// terapkan semua pengaturan grafis (dipanggil saat start & tiap perubahan di panel)
const fpsEl = document.getElementById('fps'); let lastShadow = 0, lastMs = -1;
function applyCfg() {
  pr = cfg.scale; resize();
  const ms = Math.min(cfg.msaa, renderer.capabilities.maxSamples);
  if (ms !== lastMs) { lastMs = ms; for (const r of [composer.renderTarget1, composer.renderTarget2]) { r.samples = ms; r.dispose(); } }
  gtao.enabled = cfg.ao > 0; if (cfg.ao > 0) gtao.updateGtaoMaterial({ scale: cfg.ao });
  bloom.enabled = cfg.bloom > 0;
  vol.enabled = cfg.rays > 0; lighting.noBeam = cfg.rays > 0; world.refs.beam.visible = !lighting.noBeam && lighting.mode !== 2;
  grade.uniforms.vig.value = .32 * cfg.fx; grade.uniforms.grain.value = .035 * cfg.fx; grade.uniforms.ca.value = .0012 * cfg.fx;
  if (cfg.shadow !== lastShadow) { lastShadow = cfg.shadow; lighting.setShadow(cfg.shadow); }
  lighting.expo = cfg.expo;
  lighting.apply();
  luma.enabled = !!cfg.aexp; if (!cfg.aexp) { lighting.auto = 1; lighting.applyExposure(); }
  lighting.setGI(!!cfg.gi); // pantulan cahaya (probe) — hanya bila diaktifkan di preset
  fpsEl.style.display = cfg.fps ? 'block' : 'none';
  audio.setVolume(cfg.vol); audio.setMute(cfg.mute); sdBtn.textContent = cfg.mute ? '🔇' : '🔊';
}
// ---- audio ambient: browser baru mengizinkan suara setelah interaksi pertama (kecuali sebelumnya dimatikan)
const sdBtn = document.getElementById('sd');
const startAudio = e => { if (e.target.closest?.('#sd') || cfg.mute) return; audio.start(); applyCfg(); };
for (const ev of ['pointerdown', 'pointerup', 'keydown']) // pointerup: di layar sentuh, aktivasi baru dihitung saat jari diangkat
  addEventListener(ev, startAudio, { once: true, capture: true });
sdBtn.onclick = () => {
  cfg.mute = audio.started ? !cfg.mute : false; // klik pertama = nyalakan
  if (!cfg.mute) audio.start();
  saveCfg(cfg); applyCfg();
};
document.addEventListener('visibilitychange', () => document.hidden ? audio.pause() : audio.resume());

const gfx = createSettings(cfg, applyCfg);

// ---- isi rak dari server (live): data awal = cadangan, lalu ganti dengan data server dan ikuti perubahan
function applyContent(d, force) {
  if (!d || (!force && d.version === store.version)) return;
  setStore(d);
  world.shelves.setBooks(store.books); world.shelves.setProducts(store.products, fmt);
  renderer.shadowMap.needsUpdate = true; // bayangan dihitung ulang karena benda berubah
  ui.refreshPanel();
}
world.shelves.setBooks(store.books); world.shelves.setProducts(store.products, fmt);
const pull = () => api.content().then(applyContent).catch(() => { });
api.content().then(d => applyContent(d, true)).catch(() => { });
subscribe(pull);
ui.onAdmin(createAdmin({ panel: document.getElementById('panel'), api, onContent: d => applyContent(d, true) }).open);
lastMs = Math.min(cfg.msaa, renderer.capabilities.maxSamples);
lighting.ready = true;
applyCfg();

// loop + resolusi adaptif
let last = 0, fa = .016, fr = 0, highFpsFrames = 0;
renderer.setAnimationLoop(t => {
  const dt = Math.min((t - last) / 1000 || 0, .05); last = t; fr++; fa = fa * .95 + dt * .05;
  const currentFps = 1 / fa;
  if (cfg.adaptive) {
    if (fr % 60 === 0 && fa > .028 && cfg.scale > .7) {
      cfg.scale = Math.max(.7, Math.round((cfg.scale - .15) * 100) / 100);
      pr = cfg.scale; resize(); gfx.refresh(); fa = .02; highFpsFrames = 0;
    } else if (currentFps > 55) {
      highFpsFrames++;
      if (highFpsFrames >= 300 && cfg.scale < basePresetScale) {
        cfg.scale = Math.min(basePresetScale, Math.round((cfg.scale + .15) * 100) / 100);
        pr = cfg.scale; resize(); gfx.refresh(); highFpsFrames = 0;
      }
    } else {
      highFpsFrames = Math.max(0, highFpsFrames - 2);
    }
  }
  if (cfg.fps && fr % 20 === 0) fpsEl.textContent = Math.round(currentFps) + ' FPS';
  ctl.update(dt, t);
  if (cfg.aexp && luma.luma && !state.sleeping) { lighting.auto = stepExposure(lighting.auto, luma.luma, LUM_REF[lighting.mode], dt); lighting.applyExposure(); }
  if (DEBUG_CAM && window.__camOv) { camera.position.fromArray(window.__camOv[0]); camera.lookAt(...window.__camOv[1]); } // hanya dengan ?catdebug: pasang kamera manual untuk pengujian
  audio.setMuffled(state.sleeping); // saat tidur suara teredam
  world.refs.update(t, camera);
  ui.updateDots(camera);
  vol.amount = cfg.rays * PRESETS[MODES[lighting.mode]].rays; bloom.strength = PRESETS[MODES[lighting.mode]].bloom * cfg.bloom; grade.uniforms.time.value = t / 1000 % 100;
  composer.render(dt);
});
ui.hideLoading();

// ---- panel tuning cahaya (developer): tekan G (atau buka dengan ?debug)
let gui = null;
async function toggleGui() {
  if (gui) { gui.destroy(); gui = null; return; }
  const { default: GUI } = await import('lil-gui');
  gui = new GUI({ title: 'Tuning cahaya (G)' });
  gui.add(renderer, 'toneMapping', { ACES: THREE.ACESFilmicToneMapping, AgX: THREE.AgXToneMapping, Neutral: THREE.NeutralToneMapping }).name('Tone mapping');
  gui.add(lighting, 'giK', 0, 1.5, .05).name('GI: energi pantulan').onFinishChange(() => lighting.rebakeGI());
  MODES.forEach((k, i) => {
    const f = gui.addFolder(['Pagi', 'Senja', 'Malam'][i]), p = PRESETS[k];
    f.add(p, 'sun', 0, 15, .1); f.add(p, 'hemi', 0, 4, .05); f.add(p, 'fill', 0, 60, .5); f.add(p, 'lamp', 0, 60, .5); f.add(p, 'win', 0, 20, .1);
    f.add(p, 'bedLight', 0, 10, .1); f.add(p, 'env', 0, 2, .05); f.add(p, 'gi', 0, 2, .05).name('gi (pantulan)'); f.add(p, 'rays', 0, 3, .05); f.add(p, 'bloom', 0, 1.5, .01); f.add(p, 'exposure', .3, 2, .05);
    f.onChange(() => lighting.apply());
  });
}
addEventListener('keydown', e => { if (e.key.toLowerCase() === 'g' && !e.target.closest?.('input,textarea,select')) toggleGui(); });
if (new URLSearchParams(location.search).has('debug')) { toggleGui(); window.__room = { ui, lighting, state, vol, world, luma, renderer, stepExposure, LUM_REF }; }
