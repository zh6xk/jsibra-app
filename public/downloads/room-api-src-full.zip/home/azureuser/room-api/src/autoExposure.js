// Eksposur adaptif ("adaptasi mata"): mengukur luminans rata-rata (log) layar pada resolusi sangat kecil,
// lalu main.js menggeser exposure pelan-pelan. Dibaca asinkron (tidak menahan GPU) dan hanya tiap beberapa frame.
import * as THREE from 'three';
import { Pass, FullScreenQuad } from 'three/examples/jsm/postprocessing/Pass.js';

const W = 32, H = 18;
export class LumaPass extends Pass {
  constructor(every = 8) {
    super();
    this.needsSwap = false; this.every = every; this.n = 0; this.pending = false;
    this.luma = null;                                       // luminans geometris rata-rata (linear, sebelum tone mapping)
    this.rt = new THREE.WebGLRenderTarget(W, H, { type: THREE.UnsignedByteType, depthBuffer: false, minFilter: THREE.NearestFilter, magFilter: THREE.NearestFilter });
    this.buf = new Uint8Array(W * H * 4);
    this.quad = new FullScreenQuad(new THREE.ShaderMaterial({
      uniforms: { tDiffuse: { value: null } },
      vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0., 1.); }',
      fragmentShader: `uniform sampler2D tDiffuse; varying vec2 vUv;
        void main(){
          vec2 cell = vec2(1. / ${W}.0, 1. / ${H}.0); float s = 0.;
          for (int i = 0; i < 6; i++) for (int j = 0; j < 6; j++) {
            vec3 c = texture2D(tDiffuse, vUv + ((vec2(float(i), float(j)) + .5) / 6. - .5) * cell).rgb;
            s += log2(max(dot(c, vec3(.2126, .7152, .0722)), 1e-4));
          }
          s /= 36.;
          gl_FragColor = vec4(clamp((s + 8.) / 16., 0., 1.), 0., 0., 1.);   // log2 luminans dikodekan ke 8-bit (±0,06 EV)
        }`,
      depthTest: false, depthWrite: false,
    }));
  }
  render(renderer, writeBuffer, readBuffer) {
    if (this.pending || ++this.n % this.every) return;
    this.quad.material.uniforms.tDiffuse.value = readBuffer.texture;
    const prev = renderer.getRenderTarget();
    renderer.setRenderTarget(this.rt); this.quad.render(renderer); renderer.setRenderTarget(prev);
    this.pending = true;
    renderer.readRenderTargetPixelsAsync(this.rt, 0, 0, W, H, this.buf).then(() => {
      let s = 0; for (let i = 0; i < W * H; i++) s += this.buf[i * 4]; this.luma = Math.pow(2, s / (W * H) / 255 * 16 - 8); this.pending = false;
    }).catch(() => { this.pending = false; this.enabled = false; });
  }
  dispose() { this.rt.dispose(); this.quad.dispose(); }
}

// Eksposur target dari luminans: ref = luminans "normal" untuk mode itu; exponent <1 supaya adaptasi parsial
// (adegan gelap tetap terasa gelap, tapi tidak terlalu). Naik (gelap→terang scene) cepat, turun lambat — seperti pupil.
export function stepExposure(cur, luma, ref, dt, { k = .4, lo = .72, hi = 1.3 } = {}) {
  if (!luma || !ref) return cur;
  const target = Math.min(hi, Math.max(lo, Math.pow(ref / luma, k)));
  const tau = target < cur ? .55 : 1.6;                    // scene jadi terang → exposure turun cepat; jadi gelap → naik pelan
  return cur + (target - cur) * (1 - Math.exp(-dt / tau));
}
