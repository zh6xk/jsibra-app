// Pencahayaan + siang/senja/malam + environment map + lampu area jendela.
// Satuan cahaya fisik (three r170). Tekan "G" di browser untuk panel tuning, lalu salin angka bagus ke PRESETS.
import * as THREE from 'three';
import { RectAreaLightUniformsLib } from 'three/examples/jsm/lights/RectAreaLightUniformsLib.js';
import { ct, skyTexture } from './textures.js';
RectAreaLightUniformsLib.init();

export const MODES = ['day', 'dusk', 'night'];
// lumRef = luminans rata-rata layar (linear) pada pose awal; dipakai eksposur adaptif sebagai titik netral per mode
export const LUM_REF = [0.142, 0.219, 0.155];   // dikalibrasi di pose awal (render uji), lihat autoExposure.js
export const PRESETS = {
  day:   { rays: 1,   sun: 6,   sunColor: '#ffe0b0', sunPos: [-9, 6, 1.6],   hemi: .6,   gi: 1,   fill: 1.2, lamp: 0,   bedLight: 0,   screen: .8,  shade: .05, bulb: .04, win: 3,  winColor: '#cfe3ff', sky: 1.8, bloom: .2,  exposure: 1.1,  env: .6,  bg: '#2a211b' },
  dusk:  { rays: 1.5, sun: 4.5, sunColor: '#ff8a4a', sunPos: [-9, 2.2, 1.2], hemi: .4,   gi: 1,   fill: 9,   lamp: 6,   bedLight: 1.2, screen: 1,   shade: .9,  bulb: .7,  win: 4,  winColor: '#ffb27a', sky: 1.5, bloom: .35, exposure: 1.05, env: .55, bg: '#2a1522' },
  night: { rays: 1.4, sun: 1.6, sunColor: '#7f9dff', sunPos: [-9, 6, 1.6],   hemi: .12,  gi: .5,  fill: 14, lamp: 20,  bedLight: 2.5, screen: 1.3, shade: 1.4, bulb: 1,   win: .5, winColor: '#6f8cff', sky: 1.0, bloom: .6,  exposure: 1.0,  env: .35, bg: '#0a0b14' },
};
const ENV = [['#a8cfff', '#e9dcc8', '#6b5238', [6, 5.2, 4]], ['#5a3a7a', '#e08a70', '#4a3024', [5, 2.6, 1.4]], ['#0b1030', '#141a3a', '#0a0806', [.25, .3, .6]]];

export function createLighting(scene, renderer, refs) {
  const hemi = new THREE.HemisphereLight(0xfff0dd, 0x5a4636, 1);
  const sun = new THREE.DirectionalLight(0xffe0b0, 1);
  sun.position.set(-9, 6, 1.6); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
  sun.shadow.radius = 7; sun.shadow.blurSamples = 20;                     // radius/blur hanya berefek pada VSMShadowMap (PCFSoft mengabaikannya)
  Object.assign(sun.shadow.camera, { left: -6.5, right: 6.5, top: 6.5, bottom: -6.5, near: 2, far: 22 });
  sun.shadow.bias = -.0005; sun.shadow.normalBias = .025;

  const lamp = new THREE.SpotLight(0xffb066, 0, 9, .9, .7, 2); // lampu meja
  lamp.position.set(-1.08, 1.5, -3.65); lamp.target.position.set(-.2, 1, -2.8);
  lamp.castShadow = true; lamp.shadow.mapSize.set(1024, 1024); lamp.shadow.bias = -.001; lamp.shadow.radius = 5; lamp.shadow.blurSamples = 16;
  lamp.penumbra = .88; lamp.map = ct(128, 128, (g, w, h) => { const r = g.createRadialGradient(w / 2, h / 2, 0, w / 2, h / 2, w / 2); r.addColorStop(0, '#fff'); r.addColorStop(.55, '#f2f2f2'); r.addColorStop(1, '#000'); g.fillStyle = r; g.fillRect(0, 0, w, h); }); // cookie: kolam cahaya bertepi lembut

  const fill = new THREE.PointLight(0xffe6c8, 1, 14, 2); fill.position.set(0, 4, .5); // lampu gantung
  const win = new THREE.RectAreaLight(0xcfe3ff, 0, 2.4, 2.4); // cahaya langit lembut dari jendela
  win.position.set(-3.85, 2.8, 1.6); win.lookAt(0, 2.8, 1.6);
  scene.add(hemi, sun, lamp, lamp.target, fill, win);

  const pm = new THREE.PMREMGenerator(renderer); let gradRT = null;
  const probeRT = new THREE.WebGLCubeRenderTarget(256, { type: THREE.HalfFloatType, generateMipmaps: false }), probe = new THREE.CubeCamera(.1, 40, probeRT), giCache = new Map();
  probe.position.set(0, 1.4, .3); probe.updateMatrixWorld(true);
  function makeEnv(m) {
    const [a, b, c, wc] = ENV[m], es = new THREE.Scene();
    const t = ct(4, 256, (g, w, h) => {
      const r = g.createLinearGradient(0, 0, 0, h); r.addColorStop(0, a); r.addColorStop(.5, b); r.addColorStop(1, c);
      g.fillStyle = r; g.fillRect(0, 0, w, h);
    });
    es.add(new THREE.Mesh(new THREE.SphereGeometry(10, 24, 16), new THREE.MeshBasicMaterial({ map: t, side: THREE.BackSide })));
    const w = new THREE.Mesh(new THREE.PlaneGeometry(6, 5), new THREE.MeshBasicMaterial({ color: new THREE.Color(...wc) }));
    w.position.set(-8, 3, 1.6); w.rotation.y = Math.PI / 2; es.add(w);
    const old = gradRT; gradRT = pm.fromScene(es, .02); scene.environment = gradRT.texture; old && old.dispose();
  }

  const api = {
    mode: 0, expo: 1, auto: 1, noBeam: false, lights: { sun, lamp, fill, win }, // noBeam: bidang sinar palsu dimatikan saat god rays aktif
    setShadow(n) {
      const soft = n >= 2048, type = soft ? THREE.VSMShadowMap : THREE.PCFSoftShadowMap, sn = soft ? 2048 : n;   // VSM memakai 2 render target; 2048 sudah cukup halus
      sun.shadow.mapSize.set(sn, sn); lamp.shadow.mapSize.set(Math.max(512, sn / 2), Math.max(512, sn / 2));
      sun.shadow.map?.dispose(); sun.shadow.map = null; lamp.shadow.map?.dispose(); lamp.shadow.map = null;
      if (renderer.shadowMap.type !== type) { renderer.shadowMap.type = type; scene.traverse(o => { const m = o.material; if (m) for (const x of Array.isArray(m) ? m : [m]) x.needsUpdate = true; }); }
      renderer.shadowMap.needsUpdate = true; api.giDirty = true;
    },
    // ---- pantulan cahaya (GI palsu): ruangan dirender ke cubemap dari tengah ruangan 2 kali (pantulan ke-1 dan ke-2), jadi environment
    // Hasil di-cache per (mode × lampu gantung). Objek dinamis disembunyikan saat capture.
    giOn: false, giDirty: false, ready: false, giK: .85, giFinal: 1,
    setGI(on) { const ch = on !== api.giOn; api.giOn = on; if (ch || api.giDirty) api.bakeGI(); },
    bakeGI() {
      api.giDirty = false;
      if (!api.ready) return;
      if (!api.giOn) { if (gradRT) scene.environment = gradRT.texture; return; }
      const key = api.mode + '-' + (refs.lightsOut ? 1 : 0);
      if (!giCache.has(key)) {
        const hide = [refs.beam, refs.dust, refs.cat && refs.cat.group].filter(Boolean).map(o => [o, o.visible]); hide.forEach(([o]) => o.visible = false);
        const keepInt = scene.environmentIntensity, keepFog = scene.fog; scene.fog = null;
        const bulbC = refs.mBulb.color.clone(), pendE = refs.mPend.emissiveIntensity; refs.mBulb.color.setHex(0); refs.mPend.emissiveIntensity = 0;   // sumber ini sudah mewakili PointLight 'fill'
        scene.environment = gradRT.texture; scene.environmentIntensity = PRESETS[MODES[api.mode]].env * api.giK;
        probe.update(renderer, scene); const e1 = pm.fromCubemap(probeRT.texture);
        scene.environment = e1.texture; scene.environmentIntensity = api.giK;
        probe.update(renderer, scene); const e2 = pm.fromCubemap(probeRT.texture); e1.dispose();
        scene.environmentIntensity = keepInt; scene.fog = keepFog; hide.forEach(([o, v]) => o.visible = v); refs.mBulb.color.copy(bulbC); refs.mPend.emissiveIntensity = pendE;
        giCache.set(key, e2);
      }
      scene.environment = giCache.get(key).texture; scene.environmentIntensity = PRESETS[MODES[api.mode]].gi ?? api.giFinal;
    },
    rebakeGI() { giCache.forEach(r => r.dispose()); giCache.clear(); api.bakeGI(); },
    apply() {
      const p = PRESETS[MODES[api.mode]];
      sun.color.set(p.sunColor); sun.intensity = p.sun; sun.position.set(...p.sunPos); sun.updateMatrixWorld(true);
      hemi.intensity = p.hemi; fill.intensity = p.fill; lamp.intensity = p.lamp;
      win.color.set(p.winColor); win.intensity = p.win;
      refs.bedLight.intensity = p.bedLight; refs.mShade.emissiveIntensity = p.shade;
      refs.mPend.emissiveIntensity = p.bulb * .4; refs.mBulb.color.copy(refs.mBulb.userData.base).multiplyScalar(p.bulb);
      refs.mScreen.emissiveIntensity = p.screen; refs.mScreen.userData.base = p.screen;
      refs.skyM.color.setScalar(p.sky); refs.beam.material.color.set(p.sunColor);
      for (const g of refs.glows || []) { const k = g.k[api.mode]; if (k && k.isColor) g.m.color.copy(k); else g.m.color.copy(g.m.userData.base).multiplyScalar(k); } // lampu hias, neon, LED, jendela kota
      for (const e of refs.extraLights || []) e.l.intensity = e.k[api.mode] || 0; // lampu lantai dll (extras.js)
      api.applyExposure(); if (!api.giOn) scene.environmentIntensity = p.env;
      const bg = new THREE.Color(p.bg); scene.background = bg; scene.fog = new THREE.Fog(bg, 16, 34);
      if (refs.lightsOut) { // saklar mati: hanya lampu gantung plafon yang mati
        fill.intensity = 0; refs.mPend.emissiveIntensity = 0; refs.mBulb.color.setHex(0x000000);
      }
      renderer.shadowMap.needsUpdate = true; // bayangan statis → hitung ulang hanya saat cahaya berubah
    },
    applyExposure() { renderer.toneMappingExposure = PRESETS[MODES[api.mode]].exposure * api.expo * api.auto; },
    setTime(m) {
      api.mode = m;
      refs.beam.visible = m !== 2 && !api.noBeam; refs.dust.visible = m !== 2;
      refs.skyM.map = skyTexture(m); refs.skyM.needsUpdate = true;
      makeEnv(m); api.apply(); api.bakeGI();
      return m;
    },
    setBlackout(out) { // matikan lampu buatan saja; sinar matahari/langit lewat jendela tetap ada
      refs.lightsOut = out;
      if (refs.swLed) refs.swLed.material.color.setHex(out ? 0xff3333 : 0x00ff88);
      api.apply(); api.bakeGI();
    },
  };
  return api;
}
