// Kucing dari model GLB (src/assets/cat.glb, ±1,1 MB) + animasi prosedural lewat tulang (tanpa clip animasi).
// Sumbu pose = sumbu kucing: X samping, Y atas, Z depan (model menghadap +Z). Rotasi tiap tulang diberikan di sumbu itu
// lalu dikonversi ke ruang lokal tulang, jadi tidak tergantung orientasi tulang dari Blender.
// Perilaku: santai (napas, tengok-tengok, ekor) → jalan keliling karpet (siklus kaki diagonal) → santai lagi.
// Saat pemain <2,2 m: berhenti; menoleh berurutan (kepala → leher → tulang belakang memutar, pegas otot), lalu badan ikut berputar
// sambil kaki melangkah di tempat (condong ke arah putar, kepala tetap tegak), ekor terseret; kadang mengeong/mendengkur.
// Bila GLB gagal dimuat → jatuh ke kucing prosedural lama (fallback).
import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import catUrl from './assets/cat.glb?url';
import { OBSTACLES } from './content.js';
import { blobTexture } from './textures.js';
import { createCatBrain } from './catBrain.js';

const { clamp } = THREE.MathUtils;
const key = n => n.replace(/[.\s]/g, '');   // GLTFLoader membuang titik dari nama node: "Bone.001" → "Bone001"
const wrap = a => Math.atan2(Math.sin(a), Math.cos(a));

export function buildCatGLB(room, fallback) {
  const root = new THREE.Group(); root.position.set(-1.1, .03, .6); root.rotation.y = .5; root.scale.setScalar(1.5); room.add(root);
  let impl = null, forced = null;
  const api = { group: root, update: (t, cam) => impl && impl.update(t, cam), force(a) { forced = a; if (impl) impl.force(a); } };
  new GLTFLoader().load(catUrl, gltf => {
    impl = rig(gltf.scene, root); if (forced !== null) impl.force(forced);
  }, undefined, err => {
    console.warn('[cat] GLB gagal dimuat, pakai kucing prosedural', err);
    room.remove(root); impl = fallback(); api.group = impl.group; if (forced !== null) impl.force(forced);
  });
  return api;
}

// Warnai ulang tekstur iris (hitam di luar iris): luminans → gradasi amber tua → emas → kuning terang. Pupil (gelap) tetap gelap.
function tintIris(m) {
  try {
    const img = m.map && m.map.image; if (!img) return;
    const w = img.width, h = img.height, c = document.createElement('canvas'); c.width = w; c.height = h;
    const g = c.getContext('2d', { willReadFrequently: true }); g.drawImage(img, 0, 0);
    const d = g.getImageData(0, 0, w, h), a = d.data;
    const stops = [[0, 40, 18, 2], [.35, 150, 80, 8], [.7, 226, 156, 20], [1, 246, 205, 70]];
    for (let i = 0; i < a.length; i += 4) {
      const l = (a[i] * .3 + a[i + 1] * .59 + a[i + 2] * .11) / 255;
      if (l < .035) { a[i] = a[i + 1] = a[i + 2] = 0; continue; }
      const t = Math.min(1, l * 1.35); let k = 1; while (k < stops.length - 1 && t > stops[k][0]) k++;
      const s0 = stops[k - 1], s1 = stops[k], u = (t - s0[0]) / (s1[0] - s0[0]);
      a[i] = s0[1] + (s1[1] - s0[1]) * u; a[i + 1] = s0[2] + (s1[2] - s0[2]) * u; a[i + 2] = s0[3] + (s1[3] - s0[3]) * u;
    }
    g.putImageData(d, 0, 0);
    const tex = new THREE.CanvasTexture(c); tex.flipY = m.map.flipY; tex.channel = m.map.channel; tex.colorSpace = m.map.colorSpace;
    tex.wrapS = m.map.wrapS; tex.wrapT = m.map.wrapT; tex.anisotropy = 4;
    m.map = tex; m.color.setScalar(.8); m.roughness = .35;
    m.emissive = new THREE.Color(0xffa820); m.emissiveMap = tex; m.emissiveIntensity = .12;   // sedikit menyala di tempat teduh seperti mata kucing
    m.needsUpdate = true;
  } catch (e) { console.warn('[cat] warna mata dilewati', e); }
}

function rig(model, root) {
  root.add(model);
  const B = {};
  model.traverse(o => {
    if (o.isBone) B[key(o.name)] = o;
    // shadow map scene statis → kucing yang bergerak tidak ikut shadow map; diganti bayangan blob di bawahnya
    if (o.isMesh && o.material && o.material.name === 'Material.002') tintIris(o.material);      // iris: hijau pucat/overexposed → kuning-amber khas kucing
    else if (o.isMesh && o.material && o.material.name === 'Material.001') {                       // kornea: pantulan terlalu putih → redam
      const m = o.material; m.opacity = Math.min(m.opacity, .28); if (m.specularColor) m.specularColor.setScalar(.5); if ('specularIntensity' in m) m.specularIntensity = .5; m.roughness = .05; m.envMapIntensity = .5; m.depthWrite = false;
    }
    if (o.isMesh) { o.castShadow = false; o.receiveShadow = true; o.frustumCulled = false; }
    if (o.isMesh) {   // mata: iris (Material.002) diberi warna kuning-hijau khas kucing; kornea (Material.001) dibuat bening, bukan putih menyala
      const fix = m => {
        if (m.name === 'Material.002') {
          const iris = new THREE.MeshStandardMaterial({ map: m.map, color: new THREE.Color('#e6d640'), roughness: .22, metalness: 0, emissive: new THREE.Color('#d8b800'), emissiveMap: m.map, emissiveIntensity: .32 });
          iris.map && (iris.map.colorSpace = THREE.SRGBColorSpace); return iris;
        }
        if (m.name === 'Material.001') {
          return new THREE.MeshPhysicalMaterial({ color: 0xffffff, transparent: true, opacity: .1, roughness: .05, metalness: 0, clearcoat: 1, clearcoatRoughness: .05, specularIntensity: .5, depthWrite: false });
        }
        return m;
      };
      o.material = Array.isArray(o.material) ? o.material.map(fix) : fix(o.material);
    }
  });
  const blob = new THREE.Mesh(new THREE.PlaneGeometry(.32, .7), new THREE.MeshBasicMaterial({ map: blobTexture(), transparent: true, opacity: .55, depthWrite: false }));
  blob.rotation.x = -Math.PI / 2; blob.position.set(0, .004, .02); blob.renderOrder = 1; root.add(blob);
  root.updateMatrixWorld(true);
  // kontrol telapak (feet_*/paw3_*) adalah akar terpisah yang membawa bobot kulit telapak → tempel ke ujung kaki supaya ikut bergerak
  for (const [f, p] of [['feet_L', 'leg3_L'], ['feet_R', 'leg3_R'], ['paw3_L', 'paw2_L'], ['paw3_R', 'paw2_R']]) if (B[f] && B[p]) B[p].attach(B[f]);
  root.updateMatrixWorld(true);

  const inv = new THREE.Matrix4().copy(root.matrixWorld).invert(), tmpM = new THREE.Matrix4(), tp = new THREE.Vector3(), ts = new THREE.Vector3();
  const S = {};   // per tulang: rotasi diam (q0) + rotasi parent di sumbu kucing (P)
  const names = ['Bone001', 'Bone002', 'Bone004', 'tail1', 'tail2', 'tail3', 'tail4', 'tail5',
    'leg1_L', 'leg2_L', 'leg3_L', 'leg1_R', 'leg2_R', 'leg3_R', 'paw1_L', 'paw2_L', 'paw3_L', 'paw1_R', 'paw2_R', 'paw3_R'];
  for (const n of names) {
    const b = B[n]; if (!b) { console.warn('[cat] tulang tidak ada:', n); continue; }
    const P = new THREE.Quaternion(); tmpM.multiplyMatrices(inv, b.parent.matrixWorld).decompose(tp, P, ts);
    S[n] = { b, q0: b.quaternion.clone(), P, Pi: P.clone().invert() };
  }
  const R = new THREE.Quaternion(), Rx = new THREE.Quaternion(), Rz = new THREE.Quaternion();
  const AX = new THREE.Vector3(1, 0, 0), AY = new THREE.Vector3(0, 1, 0), AZ = new THREE.Vector3(0, 0, 1);
  // pose: rotasi (yaw=Y, pitch=X, roll=Z; urutan YXZ) di sumbu kucing
  const pose = (n, yaw, pitch, roll) => {
    const s = S[n]; if (!s) return;
    R.setFromAxisAngle(AY, yaw); Rx.setFromAxisAngle(AX, pitch); Rz.setFromAxisAngle(AZ, roll); R.multiply(Rx).multiply(Rz);
    s.b.quaternion.copy(s.Pi).multiply(R).multiply(s.P).multiply(s.q0);
  };

  // ---------- gerak
  const home = root.position.clone(), target = new THREE.Vector3();
  const GAIT_HZ = 1.5, SPEED = 0.55;    // langkah/dtk (per kaki) & kecepatan jalan dunia (m/dtk) — selaras dengan panjang langkah × skala kucing
  const blocked = (x, z) => x < -3.5 || x > 3.5 || z < -3.5 || z > 3.5 || OBSTACLES.some(o => x > o[0] - .2 && x < o[1] + .2 && z > o[2] - .2 && z < o[3] + .2);
  const clear = (a, b) => { for (let i = 0; i <= 14; i++) if (blocked(a.x + (b.x - a.x) * i / 14, a.z + (b.z - a.z) * i / 14)) return false; return true; };
  function pickTarget() {
    for (let i = 0; i < 14; i++) {
      const a = Math.random() * 6.283, r = .5 + Math.random() * .7; target.set(home.x + Math.cos(a) * r, home.y, home.z + Math.sin(a) * r);
      if (target.distanceTo(root.position) > .45 && !blocked(target.x, target.z) && clear(root.position, target)) return true;
    } return false;
  }
  let turnPulse = 1;
  const brain = createCatBrain();                                   // perhatian + saccade pandangan + pivot badan (lihat catBrain.js)
  const fwd = new THREE.Vector3(), toCat = new THREE.Vector3();
  let pPrev = null, pSpeed = 0, pRadial = 0, pDist = -1, bo = null;
  let freezeA = 0, crouchA = 0, tiltA = 0, blinkA = 0, tailFl = 0;
  // kedip: pakai morph target bernama blink/eye-close bila model punya; kalau tidak ada → dilewati (lihat log [cat])
  const blinkMorphs = [];
  model.traverse(o => { if (o.isMesh && o.morphTargetDictionary) for (const [n, idx] of Object.entries(o.morphTargetDictionary)) if (/blink|eyes?_?clos|eyelid/i.test(n)) blinkMorphs.push([o, idx]); });
  const earBones = Object.keys(B).filter(k => /ear/i.test(k));
  console.info('[cat] morph kedip:', blinkMorphs.length, '· tulang telinga:', earBones.join(',') || '(tidak ada)');
  let last = 0, mode = 'idle', modeUntil = 1.5, walkAmt = 0, legAmt = 0, phase = 0, al = 0, forced = null, tw = 0;
  let actT = -1, st = 0, sn = 0, gr = 0, grSide = 1, walkErr = 0, bodyTurning = false, turnRate = 0;
  let lookYaw = 0, lookPitch = .1, nextLook = 0;   // pandangan santai: berpindah per "lirikan" (bukan ayunan sinus terus-menerus)
  const DUR = { stretch: 3.2, sniff: 2.4, groom: 4.2 };
  // "otot": pegas teredam tiap segmen (kepala → leher → tulang belakang bergerak berurutan, ada overshoot kecil lalu mengendap)
  const spr = () => ({ x: 0, v: 0 });
  const headY = spr(), neckY = spr(), spineY = spr(), headP = spr(), neckP = spr(), lean = spr(), turnV = spr();
  const spring = (o, target, dt, w, z = .7) => { o.v += (w * w * (target - o.x) - 2 * z * w * o.v) * dt; o.x += o.v * dt; return o.x; };
  // suara
  let alertSince = -1, nextMeow = 12 + Math.random() * 20, meowAt = -1, purrUntil = 0, wasAlert = false;
  const v = new THREE.Vector3(), rt = new THREE.Vector3(), tc = new THREE.Vector3();
  const ease = (c, t, dt, k) => c + (t - c) * (1 - Math.exp(-dt * k)), env = p => Math.min(1, Math.sin(Math.PI * Math.min(Math.max(p, 0), 1)) * 2.2);
  const hipA = { hind: .45, fore: .42 };
  function say(type, base, cam, extra) {          // volume turun menurut jarak, pan mengikuti posisi kucing di layar
    if (!cam) return; const dx = root.position.x - cam.position.x, dz = root.position.z - cam.position.z, d = Math.hypot(dx, dz);
    rt.setFromMatrixColumn(cam.matrixWorld, 0); tc.set(dx, 0, dz).normalize();
    const vol = clamp(1.15 - d / 7, .12, 1) * base, pan = clamp(rt.dot(tc) * .9, -1, 1);
    window.dispatchEvent(new CustomEvent('cat-sound', { detail: { type, vol, pan, ...extra } }));
  }

  function leg(ids, ph, amt, hind, extra = 0) {
    const [h, m, l] = ids, A = (hind ? hipA.hind : hipA.fore) * amt;
    const hip = A * Math.sin(ph) + extra, lift = Math.max(0, -Math.cos(ph)) * amt;
    const mid = lift * .7;
    pose(h, 0, hip, 0); pose(m, 0, mid, 0);
    if (l) pose(l, 0, -(hip + mid) + lift * .25, 0);
    return { hip, mid };
  }

  function update(t, cam) {
    const s = t / 1000, dt = last ? Math.min((t - last) / 1000, .05) : .016; last = t;
    // ---- keadaan
    let camYaw = 0, dist = 99, elev = 0, facing = 0;
    if (cam) {
      v.copy(cam.position); dist = Math.hypot(v.x - root.position.x, v.z - root.position.z);
      // kecepatan pemain & laju mendekat (m/dtk), dihaluskan → dasar untuk kaget / tenang
      if (pPrev) { pSpeed = ease(pSpeed, Math.hypot(v.x - pPrev.x, v.z - pPrev.z) / dt, dt, 8); pRadial = ease(pRadial, (dist - pDist) / dt, dt, 8); }
      pPrev = pPrev || new THREE.Vector3(); pPrev.copy(v); pDist = dist;
      // apakah pemain sedang menatap kucing (arah kamera × arah ke kucing)
      cam.getWorldDirection(fwd); toCat.set(root.position.x - v.x, root.position.y + .3 - v.y, root.position.z - v.z).normalize(); facing = clamp((fwd.dot(toCat) - .8) / .2, 0, 1);
      root.worldToLocal(v); camYaw = Math.atan2(v.x, v.z);
      elev = clamp(-Math.atan2(v.y - .3, Math.hypot(v.x, v.z - .19)), -.55, .35);
    }
    bo = brain.update(dt, s, { dist, bearing: camYaw, elev, heading: root.rotation.y, lookYaw, lookPitch, speed: pSpeed, radial: pRadial, facing, forced });
    const alert = bo.alert;
    al = ease(al, alert ? 1 : 0, dt, 2.2);
    const h0 = root.rotation.y; let heading = h0, wantWalk = 0, desiredRate = 0;
    turnPulse = .3 + .7 * Math.max(0, Math.sin(phase + .6));   // pinggul berpindah per langkah (berdenyut), bukan berputar kaku terus-menerus
    if (alert) {
      if (mode !== 'idle') { mode = 'idle'; actT = -1; }
      modeUntil = s + 2.5;
      // urutan menoleh: kepala dulu → leher → tulang belakang memutar; kalau sudut masih besar, badan ikut berputar sambil kaki melangkah
      // badan memutar per "pivot" (diputuskan otak): kepala lebih dulu (saccade), badan menyusul satu langkah putar, lalu berhenti
      bodyTurning = bo.pivotRate !== 0; desiredRate = bo.pivotRate;
    } else {
      bodyTurning = false;
      if (mode === 'idle') {
        if (s > modeUntil) {
          const r = Math.random();
          if (r < .18) { mode = 'stretch'; actT = s; } else if (r < .34) { mode = 'sniff'; actT = s; }
          else if (r < .5) { mode = 'groom'; actT = s; grSide = Math.random() < .5 ? -1 : 1; }
          else if (pickTarget()) mode = 'walk'; else modeUntil = s + 1.5;
        }
      } else if (mode === 'stretch' || mode === 'sniff' || mode === 'groom') {
        if (s - actT > DUR[mode]) { mode = 'idle'; modeUntil = s + 1.5 + Math.random() * 2; actT = -1; }
      } else {                                     // walk
        const dx = target.x - root.position.x, dz = target.z - root.position.z, d = Math.hypot(dx, dz);
        if (d < .06) { mode = 'idle'; modeUntil = s + 1.5 + Math.random() * 3; }
        else {
          const err = wrap(Math.atan2(dx, dz) - heading); walkErr = err;
          // belok membentuk busur (jalan sambil melengkung); kalau arah masih jauh, berputar per langkah (kaki depan memimpin) dulu
          heading += clamp(err, -1.05 * dt, 1.05 * dt) * (Math.abs(err) > .9 ? turnPulse : 1);
          wantWalk = clamp(1 - Math.abs(err) / 1.4, 0, 1);
          const sp = SPEED * walkAmt * dt; root.position.x += Math.sin(heading) * sp; root.position.z += Math.cos(heading) * sp;
        }
      }
    }
    spring(turnV, desiredRate, dt, 13, 1);                          // kecepatan putar badan dihaluskan (tidak mendadak)
    heading += turnV.x * dt; root.rotation.y = heading;
    turnRate = ease(turnRate, wrap(heading - h0) / Math.max(dt, 1e-3), dt, 10);
    st = ease(st, mode === 'stretch' && actT >= 0 ? env((s - actT) / 3.2) : 0, dt, 8);
    sn = ease(sn, mode === 'sniff' && actT >= 0 ? env((s - actT) / 2.4) : 0, dt, 8);
    gr = ease(gr, mode === 'groom' && actT >= 0 ? env((s - actT) / DUR.groom) : 0, dt, 5);
    walkAmt = ease(walkAmt, mode === 'walk' ? wantWalk : 0, dt, 5); if (walkAmt < .01) walkAmt = 0;
    // kaki melangkah di tempat saat badan berputar → kesan memutar, bukan meluncur
    const stepAmt = clamp(Math.abs(turnRate) / .8, 0, 1) * .6;
    legAmt = Math.max(walkAmt, ease(legAmt, stepAmt, dt, 6)); if (legAmt < .01) legAmt = 0;
    phase += dt * GAIT_HZ * 6.283 * legAmt * (walkAmt > .3 ? 1 : 1.25);
    // ---- target pandangan (total relatif badan, ±100°); dibagi kepala 45% / leher 30% / tulang belakang 25% dengan kelambanan berbeda
    let yawT, pitchT;
    if (cam && alert) { yawT = bo.gazeYaw; pitchT = bo.gazePitch; }   // target BERTAHAP dari otak (saccade → tatap → saccade), bukan menempel ke kamera
    else if (mode === 'walk') { yawT = clamp(walkErr * .8, -.7, .7); pitchT = .03; }   // kepala melirik ke arah belokan lebih dulu
    else {
      if (s > nextLook) { lookYaw = (Math.random() - .5) * 1.5; lookPitch = .02 + Math.random() * .22; nextLook = s + 1.4 + Math.random() * 3.6; }
      yawT = lookYaw + Math.sin(s * .9) * .04; pitchT = lookPitch + Math.sin(s * .5) * .03;
    }
    yawT += grSide * .75 * gr;      // menjilat bulu: kepala menunduk ke sisi badan
    const sniffYaw = Math.sin(s * 2.6) * .18 * sn, sniffPitch = .55 * sn + Math.sin(s * 9) * .04 * sn + (.5 + Math.sin(s * 8) * .09) * gr;
    const sk = alert ? bo.saccade : 0, yH = spring(headY, yawT * .4 + sniffYaw * .5, dt, 17 + 12 * sk, .62), yN = spring(neckY, yawT * .3 + sniffYaw * .5, dt, 11 + 5 * sk, .7), yS = spring(spineY, clamp(yawT * .3, -.6, .6), dt, 6.5, .8);
    const pH = spring(headP, pitchT * .55, dt, 15 + 10 * sk, .65), pN = spring(neckP, pitchT * .45, dt, 11 + 4 * sk, .7);
    freezeA = ease(freezeA, alert ? bo.freeze : 0, dt, 14); crouchA = ease(crouchA, alert ? bo.crouch : 0, dt, bo.crouch > crouchA ? 18 : 3);
    tiltA = ease(tiltA, alert ? bo.tilt : 0, dt, 6); tailFl = ease(tailFl, alert ? bo.tailFlick : 0, dt, 25); blinkA = bo.blink;
    for (const [m, idx] of blinkMorphs) m.morphTargetInfluences[idx] = blinkA;
    // ---- kaki (diagonal: kiri-depan+kanan-belakang | kanan-depan+kiri-belakang) + efek meregang
    const hindA = legAmt * (walkAmt > .3 ? 1 : .55), foreA = Math.min(1, legAmt * (walkAmt > .3 ? 1 : 1.2));   // berputar di tempat: kaki depan melangkah, kaki belakang jadi poros
    leg(['leg1_L', 'leg2_L', 'leg3_L'], phase + Math.PI, hindA, true, .12 * st); leg(['leg1_R', 'leg2_R', 'leg3_R'], phase, hindA, true, .12 * st);
    const fl = leg(['paw1_L', 'paw2_L'], phase, foreA, false, -.55 * st), fr = leg(['paw1_R', 'paw2_R'], phase + Math.PI, foreA, false, -.55 * st);
    pose('paw3_L', 0, -(fl.hip + fl.mid), 0); pose('paw3_R', 0, -(fr.hip + fr.mid), 0);
    // ---- badan: napas + goyang; condong ke arah putar (otot) dan kepala menegakkan diri (refleks righting kucing)
    const br = Math.sin(s * 2.1) * (1 - .75 * freezeA), bz = br * .5 + .5, sw = Math.sin(phase);
    const roll = spring(lean, clamp(-turnV.x * .1, -.14, .14), dt, 8, .7);
    pose('Bone001', yS + Math.sin(s * .21) * .015 * (1 - legAmt) + sw * .06 * legAmt, br * .008 + Math.cos(phase * 2) * .02 * legAmt + .3 * st + .08 * sn + .22 * gr + .1 * crouchA, roll + Math.sin(s * .17) * .018 * (1 - legAmt) + sw * .03 * legAmt);
    S.Bone001 && S.Bone001.b.scale.set(1 + bz * .014, 1, 1 + bz * .014);
    pose('Bone002', yN - sw * .05 * legAmt, pN - br * .004 + .22 * st + sniffPitch * .5, -roll * .4);
    pose('Bone004', yH - sw * .05 * legAmt, pH - .35 * st + sniffPitch * .5 + Math.max(0, Math.sin(s * .9)) * .01 + Math.abs(Math.cos(phase)) * .03 * legAmt - .06 * crouchA, -roll * .5 + tiltA);
    root.position.y = home.y + Math.abs(Math.sin(phase)) * .004 * legAmt - .012 * crouchA;
    // ---- ekor: ayunan lambat & kaku di pangkal; waspada → naik berujung melengkung; jalan → agak naik; ikut terseret (inersia) saat badan berputar
    tw += dt * (.9 + al * .3 + walkAmt * .4);
    for (let i = 1; i <= 5; i++) {
      const swing = (.055 + i * .025) * (1 + al * .25) * (Math.sin(tw - i * .26) + .3 * Math.sin(tw * 2.1 + 1 - i * .18)) - turnV.x * .06 * i + grSide * gr * .1 * i + (i >= 3 ? tailFl * Math.sin(s * 26 + i) * .07 * (i - 2) : 0);
      const lift = i === 1 ? .1 + al * .5 + walkAmt * .26 + st * .5 + sn * .1 - gr * .05 : .02 + al * .06 + walkAmt * .04 + st * .1 + (i >= 3 ? al * .08 : 0);
      pose('tail' + i, swing, lift - crouchA * (i === 1 ? .3 : .05) + (bo.purrOk && i === 1 ? .12 : 0), 0);
    }
    // ---- suara
    if (alert && !wasAlert) { alertSince = s; if (s > nextMeow - 8 && Math.random() < .75) meowAt = s + .6 + Math.random() * .5; }
    if (!alert) alertSince = -1; wasAlert = alert;
    if (meowAt > 0 && s > meowAt) { meowAt = -1; say('meow', .75, cam, { kind: Math.random() < .35 ? 1 : 0 }); nextMeow = s + 25 + Math.random() * 30; }
    else if (!alert && s > nextMeow && mode === 'idle' && cam) { say('meow', .6, cam, { kind: Math.random() < .5 ? 1 : 0 }); nextMeow = s + 25 + Math.random() * 40; }
    if (alert && bo.purrOk && s > purrUntil && dist < 1.8 && Math.random() < .02) {
      purrUntil = s + 12; say('purr', .6, cam, { dur: 3.5 });
    }
    root.updateMatrixWorld(true);   // scene statis (matrixWorldAutoUpdate=false) → update manual
  }
  console.info('[cat] rig aktif — tulang teranimasi:', Object.keys(S).length, '/', names.length);
  let helper = null, hud = null;
  if (typeof location !== 'undefined' && /catdebug/.test(location.search)) {      // ?catdebug → garis tulang + status
    helper = new THREE.SkeletonHelper(model); helper.material.depthTest = false; helper.material.linewidth = 2; helper.renderOrder = 9; root.parent.add(helper);
    hud = document.createElement('div'); hud.style.cssText = 'position:fixed;left:12px;top:56px;z-index:99;font:12px monospace;color:#fff;background:#000a;padding:6px 8px;border-radius:6px;pointer-events:none'; document.body.appendChild(hud);
  }
  const base = update;
  const upd = (t, cam) => { base(t, cam); if (helper) { helper.updateMatrixWorld(true); hud.textContent = `kucing: ${mode}/${bo ? bo.state : '-'}  percaya=${bo ? bo.trust.toFixed(2) : '-'}  minat=${bo ? bo.interest.toFixed(2) : '-'}  jalan=${walkAmt.toFixed(2)}  regang=${st.toFixed(2)}  endus=${sn.toFixed(2)}  waspada=${al.toFixed(2)}  badan-putar=${bodyTurning}  kepala-yaw=${headY.x.toFixed(2)}  putar=${turnRate.toFixed(2)}  pos=${root.position.x.toFixed(2)},${root.position.z.toFixed(2)}`; } };
  return { update: upd, group: root, force(a) { forced = a; } };
}
