// Input + kamera.
//  - Mode watching : klik kiri tahan & geser untuk menoleh (sentuh: geser jari).
//  - Mode jalan    : mouse = arah pandang (pointer lock), WASD/panah = bergerak, ada head-bob.
import * as THREE from 'three';
import { FOCUS, NAMES, OBSTACLES } from './content.js';

export function createControls(state, camera, canvas, hot, ui) {
  const ray = new THREE.Raycaster(), mp = new THREE.Vector2(), Y = new THREE.Vector3(0, 1, 0);
  const home = new THREE.Vector3(.6, 2.7, 3.5), wp = new THREE.Vector3(.6, 1.7, 3.3), look = new THREE.Vector3(0, 1.5, -1);
  const tp = new THREE.Vector3(), tl = new THREE.Vector3(), vel = new THREE.Vector3();
  const keys = {}, kmap = { w: 'f', arrowup: 'f', s: 'b', arrowdown: 'b', a: 'l', arrowleft: 'l', d: 'r', arrowright: 'r' };
  const glowColor = new THREE.Color('#ffb066');
  let yaw = 0, pitch = 0, phase = 0, lk = .05, frame = 0;
  let down = null, moved = 0, hover = null, touch = false, px = -1, py = -1;

  const locked = () => document.pointerLockElement === canvas;
  const lock = () => { try { const r = canvas.requestPointerLock?.(); r?.catch?.(() => { }); } catch (_) { } };
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const blocked = (x, z) => x < -3.6 || x > 3.6 || z < -3.6 || z > 3.6 || OBSTACLES.some(o => x > o[0] && x < o[1] && z > o[2] && z < o[3]);

  function pick(x, y) {
    mp.set(x / innerWidth * 2 - 1, -(y / innerHeight) * 2 + 1);
    ray.setFromCamera(mp, camera);
    const h = ray.intersectObjects(hot, true)[0]; if (!h) return null;
    let o = h.object; while (o && !o.userData.key) o = o.parent; return o;
  }
  function glow(g, on) {
    g && g.traverse(m => {
      const a = m.material; if (!m.isMesh || !a) return;
      if (on) {
        if (!m.userData.origMat) m.userData.origMat = m.material;
        const mat = m.userData.origMat.clone();
        if (mat.emissive) {
          mat.emissive.copy(glowColor);
          mat.emissiveIntensity = mat.emissiveMap ? (mat.userData.base || 1) * 1.6 : .3;
        }
        m.material = mat;
      } else {
        if (m.userData.origMat) {
          m.material.dispose(); m.material = m.userData.origMat;
          delete m.userData.origMat;
        }
      }
    });
  }
  function updateHover() {
    const L = locked();
    if (L) { ui.tip.style.left = innerWidth / 2 + 'px'; ui.tip.style.top = innerHeight / 2 + 'px'; }
    const o = (state.focus || touch || (!L && px < 0)) ? null : (L ? pick(innerWidth / 2, innerHeight / 2) : pick(px, py));
    if (o !== hover) {
      glow(hover, false); hover = o; glow(o, true);
      ui.tip.style.opacity = o ? 1 : 0; if (o) ui.tip.textContent = NAMES[o.userData.key];
      canvas.style.cursor = o ? 'pointer' : (state.walk ? 'default' : 'grab');
    }
  }

  // ---- pointer
  canvas.addEventListener('pointerdown', e => {
    down = { x: e.clientX, y: e.clientY }; moved = 0;
    if (e.pointerType !== 'mouse') touch = true; else if (!state.walk) canvas.style.cursor = 'grabbing';
  });
  addEventListener('pointermove', e => {
    if (e.pointerType === 'mouse') {
      const L = locked();
      px = !L && e.target === canvas ? e.clientX : -1; py = e.clientY;
      if (!L) { ui.tip.style.left = e.clientX + 'px'; ui.tip.style.top = e.clientY + 'px'; }
      if (down) moved += Math.abs(e.movementX || 0) + Math.abs(e.movementY || 0);
      if (!state.focus && !state.sleeping) {
        const mX = clamp(e.movementX || 0, -120, 120), mY = clamp(e.movementY || 0, -120, 120);
        if (state.walk) { if (L || e.target === canvas) { yaw -= mX * .0022; pitch = clamp(pitch - mY * .0022, -.6, .6); } }
        else if (down && (e.buttons & 1)) { yaw = clamp(yaw + mX * .004, -1.1, 1.1); pitch = clamp(pitch + mY * .003, -.6, .6); }
      }
      return;
    }
    touch = true;
    if (down) {
      const dx = e.clientX - down.x, dy = e.clientY - down.y; moved += Math.abs(dx) + Math.abs(dy); down.x = e.clientX; down.y = e.clientY;
      if (!state.focus) { yaw = state.walk ? yaw + dx * .004 : clamp(yaw + dx * .004, -1.1, 1.1); pitch = clamp(pitch + dy * .003, -.4, .4); }
    }
  });
  canvas.addEventListener('pointerup', e => {
    if (moved < 6 && !state.sleeping) {
      const L = locked(), o = L ? pick(innerWidth / 2, innerHeight / 2) : pick(e.clientX, e.clientY);
      if (o) ui.openP(o.userData.key); else if (state.focus) ui.closeP(); else if (state.walk && !L && e.pointerType === 'mouse') lock();
    }
    down = null; canvas.style.cursor = state.walk ? 'default' : 'grab';
  });
  document.addEventListener('pointerlockchange', () => { document.getElementById('xh').style.display = locked() ? 'block' : 'none'; if (!locked()) px = -1; });

  // ---- keyboard
  function toggleWalk() {
    state.walk = !state.walk;
    if (state.walk) { wp.set(.6, 1.7, 3.3); yaw = 0; pitch = 0; vel.set(0, 0, 0); phase = 0; lock(); }
    else { yaw = clamp(yaw, -1, 1); document.pointerLockElement && document.exitPointerLock(); }
    ui.setWalkUI(state.walk); canvas.style.cursor = state.walk ? 'default' : 'grab';
  }
  addEventListener('keydown', e => {
    const k = e.key.toLowerCase();
    if (e.target.closest?.('input,textarea,select')) { if (k === 'escape') ui.closeP(); return; } // sedang mengetik di form admin
    if (k === 'escape') state.sleeping ? ui.wake() : ui.closeP();
    else if (k === 'f' && !e.repeat) toggleWalk();
    else if (kmap[k]) keys[kmap[k]] = 1;
  });
  addEventListener('keyup', e => { const k = kmap[e.key.toLowerCase()]; if (k) keys[k] = 0; });

  // ---- per frame
  function update(dt, t) {
    frame++;
    lk += ((state.focus ? .05 : .35) - lk) * .03; // saat fokus halus, saat bebas responsif
    let roll = 0;
    if (state.focus) {
      tp.set(...FOCUS[state.focus][0]); tl.set(...FOCUS[state.focus][1]); vel.set(0, 0, 0);
      if (state.focus === 'bed') tp.y += Math.sin(t / 900) * .012; // napas saat tidur
    } else {
      const sx = Math.sin(yaw), cx = Math.cos(yaw); let spd = 0;
      if (state.walk) {
        const f = (keys.f || 0) - .6 * (keys.b || 0), r = ((keys.r || 0) - (keys.l || 0)) * .7, h = Math.hypot(f, r), sk = h > 1 ? 1 / h : 1, al = 1 - Math.exp(-9 * dt);
        vel.x += ((-sx * f + cx * r) * 1.5 * sk - vel.x) * al; vel.z += ((-cx * f - sx * r) * 1.5 * sk - vel.z) * al; // ±1.5 m/s, akselerasi halus
        if (blocked(wp.x + vel.x * dt, wp.z)) vel.x = 0; else wp.x += vel.x * dt;
        if (blocked(wp.x, wp.z + vel.z * dt)) vel.z = 0; else wp.z += vel.z * dt;
        spd = Math.hypot(vel.x, vel.z); phase += spd * dt * Math.PI / .7;
      }
      const b = state.walk ? wp : home; tp.copy(b);
      if (state.walk) { const am = Math.min(1, spd / 1.5), sw = Math.sin(phase) * .02 * am; tp.y += Math.sin(phase * 2) * .03 * am; tp.x += cx * sw; tp.z -= sx * sw; roll = Math.sin(phase) * .006 * am; }
      else tp.x += Math.sin(t / 3000) * .04;
      tl.set(0, 0, -4.5).applyAxisAngle(Y, yaw).add(b); tl.y = (state.walk ? 1.7 : 1.5) + pitch * 6;
    }
    const wk = state.walk && !state.focus;
    camera.position.lerp(tp, wk ? .3 : .05); look.lerp(tl, lk); camera.lookAt(look); if (roll) camera.rotateZ(roll);
    if (frame % 3 === 0) updateHover(); // raycast dibatasi ±20x/detik
  }
  camera.position.copy(home);
  return { update, keys, toggleWalk };
}
