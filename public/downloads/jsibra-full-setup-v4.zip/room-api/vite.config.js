import { defineConfig } from 'vite';
export default defineConfig({
  base: './',
  build: { chunkSizeWarningLimit: 900 },
  server: { proxy: { '/api/room': 'http://127.0.0.1:3100' } }, // saat npm run dev: API diteruskan ke server lokal (npm start)
});
