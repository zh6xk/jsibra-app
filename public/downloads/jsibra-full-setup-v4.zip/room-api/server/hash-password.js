// Membuat hash password admin untuk .env:  npm run hash
import crypto from 'node:crypto';
import readline from 'node:readline';

function ask(q) {
  return new Promise(res => {
    const rl = readline.createInterface({ input: process.stdin, output: process.stdout, terminal: true });
    const w = rl._writeToOutput; let muted = false;
    rl._writeToOutput = s => { if (!muted) w.call(rl, s); else if (s.includes('\n')) w.call(rl, '\n'); };
    rl.question(q, a => { rl.close(); res(a); }); muted = true;
  });
}
const pw = process.argv[2] || await ask('Password admin (min. 10 karakter): ');
if (pw.length < 10) { console.error('Password terlalu pendek (minimal 10 karakter).'); process.exit(1); }
const salt = crypto.randomBytes(16), hash = crypto.scryptSync(pw, salt, 64);
console.log('\nTempel baris ini ke file .env di server:\n');
console.log(`ADMIN_PASSWORD_HASH=scrypt$${salt.toString('hex')}$${hash.toString('hex')}`);
console.log(`SESSION_SECRET=${crypto.randomBytes(32).toString('hex')}\n`);
