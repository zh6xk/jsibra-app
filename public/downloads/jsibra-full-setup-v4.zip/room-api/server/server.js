// Server mandiri: API konten (+ opsional file statis hasil build). Jalankan: node server/server.js
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createApi } from './api.js';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
try { // muat .env sederhana (tidak menimpa variabel yang sudah ada)
  for (const l of fs.readFileSync(path.join(ROOT, '.env'), 'utf8').split(/\r?\n/)) {
    const m = /^\s*([A-Z0-9_]+)\s*=\s*(.*?)\s*$/.exec(l); if (m && !l.trim().startsWith('#') && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^["']|["']$/g, '');
  }
} catch { }
const E = process.env;
const PORT = +E.PORT || 3100, HOST = E.HOST || '127.0.0.1';
const STATIC = E.STATIC_DIR ? path.resolve(ROOT, E.STATIC_DIR) : null;
const api = createApi({
  dataDir: path.resolve(ROOT, E.DATA_DIR || 'data'), passwordHash: E.ADMIN_PASSWORD_HASH, secret: E.SESSION_SECRET,
  trustProxy: E.TRUST_PROXY !== '0', basePath: E.API_BASE || '/api/room',
});
if (!E.ADMIN_PASSWORD_HASH) console.warn('[room] ADMIN_PASSWORD_HASH belum diisi → login admin dinonaktifkan. Jalankan: npm run hash');

const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.glb': 'model/gltf-binary', '.png': 'image/png', '.jpg': 'image/jpeg', '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.woff2': 'font/woff2' };
function serveStatic(req, res) {
  if (!STATIC || (req.method !== 'GET' && req.method !== 'HEAD')) { res.writeHead(404); return res.end('Not found'); }
  let p; try { p = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch { res.writeHead(400); return res.end(); }
  let f = path.join(STATIC, path.normalize(p));
  if (f !== STATIC && !f.startsWith(STATIC + path.sep)) { res.writeHead(403); return res.end(); }
  if (fs.existsSync(f) && fs.statSync(f).isDirectory()) f = path.join(f, 'index.html');
  if (!fs.existsSync(f)) { res.writeHead(404); return res.end('Not found'); }
  const hashed = f.includes(path.sep + 'assets' + path.sep);
  res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': hashed ? 'public, max-age=31536000, immutable' : 'no-cache', 'X-Content-Type-Options': 'nosniff' });
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(f).pipe(res);
}
const server = http.createServer(async (req, res) => { if (!(await api.handle(req, res))) serveStatic(req, res); });
server.listen(PORT, HOST, () => console.log(`[room] jalan di http://${HOST}:${PORT}  (API ${E.API_BASE || '/api/room'}${STATIC ? ', statis: ' + STATIC : ''})`));
for (const s of ['SIGINT', 'SIGTERM']) process.on(s, () => server.close(() => process.exit(0)));
