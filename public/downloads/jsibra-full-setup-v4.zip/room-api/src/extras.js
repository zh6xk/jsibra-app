// Detail tambahan (aditif): rak apung, penyangga headphone, tempat pensil, pouf + selimut, tanaman gantung,
// pot di ambang jendela, lampu lantai hangat. Semua statis. Dipanggil dari room.js di dalam try/catch,
// jadi kalau ada masalah, ruangan lama tetap tampil seperti biasa.
import * as THREE from 'three';
import { rnd, blobTexture } from './textures.js';

const PI = Math.PI;

export function buildExtras({ room, bx, cy, M, mats }) {
  const { mWood, mTrim, mDark, mMetal, mCer, mTerra } = mats;
  const glows = [], lights = [];
  const hdr = (r, g, b) => new THREE.Color(r, g, b);
  // material bercahaya: k = pengali per mode [pagi, senja, malam]
  const glow = (color, k, o = {}) => { const m = new THREE.MeshBasicMaterial({ color, ...o }); m.userData.base = m.color.clone(); glows.push({ m, k }); return m; };
  const blobT = blobTexture();
  const blob = (x, z, w, d, o = .6) => {
    const m = new THREE.Mesh(new THREE.PlaneGeometry(w, d), new THREE.MeshBasicMaterial({ map: blobT, transparent: true, opacity: o, depthWrite: false, toneMapped: false }));
    m.rotation.x = -PI / 2; m.position.set(x, .036, z); room.add(m);
  };
  const mat = (c, o = {}) => M(c, o);
  const sph = (g, r, x, y, z, m, sx = 1, sy = 1, sz = 1, shadow = true) => {
    const s = new THREE.Mesh(new THREE.SphereGeometry(r, 14, 10), m); s.position.set(x, y, z); s.scale.set(sx, sy, sz); s.castShadow = shadow; s.receiveShadow = true; g.add(s); return s;
  };

  // ============ RAK APUNG di dinding belakang (sudut kiri) ============
  {
    const X = -2.75, Y = 2.5, Z = -3.89, top = Y + .02;
    bx(room, 1.15, .04, .22, X, Y, Z, mWood, .008);
    [-.4, .4].forEach(dx => { bx(room, .025, .14, .02, X + dx, Y - .09, -3.985, mMetal, .004); bx(room, .025, .02, .16, X + dx, Y - .03, -3.92, mMetal, .004); });
    // buku kecil rebah + bersandar
    const cols = ['#9c3d2e', '#2f4858', '#d9a441', '#5b7f6b'];
    cols.forEach((c, i) => bx(room, .035 + (i % 2) * .01, .2 - i * .015, .15, X - .5 + i * .045, top + (.2 - i * .015) / 2, Z, mat(c, { roughness: .8 }), .004));
    bx(room, .2, .03, .15, X - .12, top + .015, Z, mat('#e8dcc8', { roughness: .8 }), .004);
    bx(room, .18, .025, .13, X - .12, top + .0425, Z, mat('#6b4c7a', { roughness: .8 }), .004);
    // vas keramik + rumput pampas kering
    const vase = new THREE.Mesh(new THREE.LatheGeometry([[.001, 0], [.05, 0], [.07, .06], [.045, .14], [.03, .19], [.04, .22]].map(p => new THREE.Vector2(p[0], p[1])), 20), mat('#e9ddc9', { roughness: .35, clearcoat: .5 }));
    vase.position.set(X + .2, top, Z); vase.castShadow = vase.receiveShadow = true; room.add(vase);
    const pm = mat('#d8c3a0', { roughness: .95 });
    for (let i = 0; i < 9; i++) {
      const h = .38 + rnd() * .22, a = (i / 9) * PI * 2, lean = .12 + rnd() * .18;
      const st = cy(room, .003, .004, h, X + .2 + Math.cos(a) * .02, top + .2 + h / 2, Z + Math.sin(a) * .02, pm, 5);
      st.rotation.set(Math.sin(a) * lean, 0, -Math.cos(a) * lean); st.castShadow = false;
      sph(room, .03, X + .2 + Math.cos(a) * (.02 + Math.sin(lean) * h), top + .2 + Math.cos(lean) * h, Z + Math.sin(a) * (.02 + Math.sin(lean) * h), pm, .55, 1.9, .55, false);
    }
    // lilin dalam toples (api kecil menyala sore/malam)
    cy(room, .05, .05, .07, X + .45, top + .035, Z, mat('#f5efe6', { roughness: .3, clearcoat: .6 }), 20);
    cy(room, .042, .042, .01, X + .45, top + .074, Z, mat('#fff7e0', { roughness: .6 }), 20);
    sph(room, .011, X + .45, top + .098, Z, glow(hdr(4, 2.2, .7), [0, 1.2, 2.2]), .7, 1.6, .7, false);
  }

  // ============ MEJA KERJA: penyangga headphone + tempat pensil ============
  {
    const sx = 1.12, sz = -3.42, y0 = 1.05;
    cy(room, .075, .085, .018, sx, y0 + .009, sz, mDark, 24);
    cy(room, .008, .008, .3, sx, y0 + .17, sz, mMetal, 8);
    bx(room, .12, .012, .03, sx, y0 + .32, sz, mMetal, .004);
    const mHp = mat('#24262c', { roughness: .45, metalness: .2 }), mPad = mat('#3a3d46', { roughness: .85 });
    const band = new THREE.Mesh(new THREE.TorusGeometry(.085, .011, 8, 28, PI), mHp); band.position.set(sx, y0 + .335, sz); band.rotation.set(0, PI / 2, 0); band.castShadow = true; room.add(band);
    [-.085, .085].forEach(dz => {
      const cup = cy(room, .048, .048, .035, sx, y0 + .335, sz + dz, mHp, 20); cup.rotation.x = PI / 2;
      const pad = cy(room, .05, .05, .014, sx, y0 + .335, sz + dz * 1.22, mPad, 20); pad.rotation.x = PI / 2;
    });
    // tempat pensil
    const px = -.72, pz = -3.72;
    cy(room, .042, .036, .1, px, y0 + .05, pz, mat('#2f4858', { roughness: .5 }), 18);
    ['#d9a441', '#9c3d2e', '#e8dcc8', '#5b7f6b'].forEach((c, i) => {
      const p = cy(room, .004, .004, .17, px + (i - 1.5) * .01, y0 + .17, pz + (i % 2 ? .008 : -.008), mat(c, { roughness: .6 }), 6);
      p.rotation.set((i - 1.5) * .12, 0, (1.5 - i) * .1); p.castShadow = false;
    });
    blob(sx, sz, .22, .22, .22);
  }

  // ============ POUF + selimut di sudut baca (depan jendela) ============
  {
    const px = -2.85, pz = 1.55, R = .42, H = .42;
    blob(px, pz, 1.25, 1.25, .6);
    const mPouf = mat('#c97b4a', { roughness: .95, sheen: 1, sheenRoughness: .6, sheenColor: new THREE.Color('#ffd0a8') });
    // badan pouf: profil membulat (lathe) → tidak kotak, ada bahu di atas & kaki kecil di bawah
    const prof = [[.001, .02], [R * .86, .02], [R * .97, .07], [R, .2], [R * .96, .33], [R * .8, H - .02], [R * .45, H + .015], [.001, H + .025]].map(q => new THREE.Vector2(q[0], q[1]));
    const body = new THREE.Mesh(new THREE.LatheGeometry(prof, 40), mPouf); body.position.set(px, 0, pz); body.castShadow = body.receiveShadow = true; room.add(body);
    const mSeam = mat('#a8613a', { roughness: 1 });
    for (let i = 0; i < 14; i++) { // jahitan vertikal mengikuti lengkung badan
      const a = i / 14 * PI * 2;
      for (const [y, rr, h] of [[.12, R * .985, .12], [.27, R * .985, .14]]) {
        const sm = bx(room, .008, h, .006, px + Math.cos(a) * rr, y, pz + Math.sin(a) * rr, mSeam, 0); sm.rotation.y = -a; sm.castShadow = false;
      }
    }
    const handle = new THREE.Mesh(new THREE.TorusGeometry(.05, .01, 8, 16), mSeam); handle.position.set(px + R * .97, .27, pz); handle.rotation.y = PI / 2; room.add(handle);
    // selimut rajut: kain menjuntai di atas pouf (heightfield: menutup puncak, jatuh di satu sisi)
    const W = .95, D = .62, cg = new THREE.PlaneGeometry(W, D, 36, 24); cg.rotateX(-PI / 2);
    const cp = cg.attributes.position, topY = H + .03, rot = .5, cr = Math.cos(rot), sr = Math.sin(rot);
    for (let i = 0; i < cp.count; i++) {
      const lx = cp.getX(i), lz = cp.getZ(i);
      const d = Math.hypot(lx, lz), over = Math.max(0, d - R * .72);            // jarak melewati tepi puncak
      let y = topY - Math.pow(over, 1.15) * (lx > 0 ? 3.1 : 1.9);               // sisi +x menjuntai lebih panjang
      y = Math.max(y, .04) + Math.sin(lx * 17 + lz * 5) * .006 * (1 + over * 6) + Math.sin(lz * 23) * .004;
      const sx = lx * (1 + over * .15), sz = lz * (1 + over * .25);              // kain menyebar agak keluar saat jatuh
      cp.setXYZ(i, px + sx * cr - sz * sr, y, pz + sx * sr + sz * cr);
    }
    cg.computeVertexNormals();
    const mThrow = mat('#8fa0c0', { roughness: 1, sheen: 1, sheenRoughness: .8, sheenColor: new THREE.Color('#dfe8ff'), side: THREE.DoubleSide });
    const cloth = new THREE.Mesh(cg, mThrow); cloth.castShadow = cloth.receiveShadow = true; room.add(cloth);
    // buku terbuka di atas selimut
    const bk = bx(room, .2, .02, .15, px - .06, topY + .02, pz - .03, mat('#f2ead8', { roughness: .8 }), .004); bk.rotation.y = -.4;
    const bk2 = bx(room, .205, .012, .155, px - .06, topY + .006, pz - .03, mat('#2f4858', { roughness: .8 }), .004); bk2.rotation.y = -.4;
  }

  // ============ TANAMAN GANTUNG (sudut depan-kiri, dekat jendela) ============
  {
    const hx = -3.35, hz = 3.0, topY = 5.0, potY = 3.55;
    const mRope = mat('#d8c3a5', { roughness: 1 });
    for (let i = 0; i < 3; i++) {
      const a = i / 3 * PI * 2, rx = Math.cos(a) * .1, rz = Math.sin(a) * .1;
      const len = Math.hypot(topY - potY - .1, .1), c = cy(room, .004, .004, len, hx + rx / 2, (topY + potY + .1) / 2, hz + rz / 2, mRope, 5);
      c.rotation.set(Math.sin(a) * Math.atan(.1 / (topY - potY - .1)), 0, -Math.cos(a) * Math.atan(.1 / (topY - potY - .1))); c.castShadow = false;
    }
    cy(room, .13, .09, .16, hx, potY, hz, mCer, 24);
    cy(room, .135, .135, .018, hx, potY + .08, hz, mRope, 24);
    const N = 90, geo = new THREE.SphereGeometry(.5, 8, 6);
    const lm = mat('#3f8a4f', { roughness: .55 }), leaves = new THREE.InstancedMesh(geo, lm, N), d = new THREE.Object3D(), c1 = new THREE.Color('#2f7a46'), c2 = new THREE.Color('#6bb06a');
    let n = 0;
    for (let v = 0; v < 6 && n < N; v++) {
      const a = v / 6 * PI * 2 + rnd() * .5, len = .5 + rnd() * 1.1, per = 15;
      for (let k = 0; k < per && n < N; k++) {
        const t = k / per, r = .1 + t * .08 + Math.sin(t * 5 + v) * .03;
        d.position.set(hx + Math.cos(a) * r, potY + .02 - t * len, hz + Math.sin(a) * r);
        d.rotation.set(rnd() * 1.4, rnd() * PI * 2, rnd() * 1.4); const s = .8 + rnd() * .5; d.scale.set(.07 * s, .012, .1 * s);
        d.updateMatrix(); leaves.setMatrixAt(n, d.matrix); leaves.setColorAt(n, c1.clone().lerp(c2, rnd())); n++;
      }
    }
    leaves.count = n; leaves.instanceMatrix.needsUpdate = true; leaves.instanceColor.needsUpdate = true; leaves.castShadow = true; leaves.receiveShadow = true; room.add(leaves);
    for (let v = 0; v < 6; v++) { // tangkai tipis
      const a = v / 6 * PI * 2, len = .5 + rnd() * 1.1;
      const s = cy(room, .003, .003, len, hx + Math.cos(a) * .14, potY - len / 2, hz + Math.sin(a) * .14, mat('#3a6a40', { roughness: .7 }), 4); s.castShadow = false;
    }
  }

  // ============ AMBANG JENDELA: pot kaktus, toples, buku ============
  {
    const sx = -3.86, top = 1.65;
    const mPot = mat('#e8dcc8', { roughness: .8 });
    [[.7, .055, '#3f8a4f'], [.95, .045, '#5b9a58']].forEach(([z, r, lc]) => {
      cy(room, r, r * .75, r * 1.5, sx, top + r * .75, z, mPot, 16);
      const cm = mat(lc, { roughness: .6 }); const h = .1 + rnd() * .05;
      cy(room, r * .42, r * .46, h, sx, top + r * 1.5 + h / 2, z, cm, 12);
      sph(room, r * .42, sx, top + r * 1.5 + h, z, cm, 1, .8, 1);
      const arm = cy(room, r * .22, r * .24, h * .5, sx, top + r * 1.5 + h * .5, z + r * .5, cm, 8); arm.rotation.x = -1.1;
    });
    cy(room, .055, .05, .12, sx, top + .06, 1.3, mat('#cfe3e8', { roughness: .1, transparent: true, opacity: .35 }), 18).castShadow = false;
    for (let i = 0; i < 3; i++) { const s = cy(room, .003, .003, .18 + i * .03, sx + (i - 1) * .015, top + .19 + i * .015, 1.3, mat('#4a8a4f', { roughness: .6 }), 4); s.rotation.z = (i - 1) * .22; s.castShadow = false; sph(room, .018, sx + (i - 1) * .06, top + .26 + i * .02, 1.3, mat('#5ba85a', { roughness: .6 }), 1.3, .5, 1, false); }
    bx(room, .15, .03, .11, sx, top + .015, 1.75, mat('#9c3d2e', { roughness: .8 }), .004).rotation.y = .25;
    bx(room, .13, .025, .1, sx, top + .0425, 1.75, mat('#d9a441', { roughness: .8 }), .004).rotation.y = -.15;
  }

  // ============ LAMPU LANTAI hangat (sisi kanan, antara kasur dan pintu) ============
  {
    const lx = 3.5, lz = .72;
    blob(lx, lz, .6, .6, .5);
    cy(room, .13, .15, .025, lx, .0125, lz, mDark, 28);
    cy(room, .011, .011, 1.5, lx, .78, lz, mMetal, 10);
    const shadeM = glow(hdr(1.6, 1.05, .6), [.55, 1, 1.5], { side: THREE.DoubleSide });
    const sh = new THREE.Mesh(new THREE.CylinderGeometry(.17, .23, .3, 28, 1, true), shadeM); sh.position.set(lx, 1.62, lz); room.add(sh);
    cy(room, .02, .02, .04, lx, 1.5, lz, mMetal, 8);
    const pl = new THREE.PointLight(0xffb066, 0, 6, 2); pl.position.set(lx - .1, 1.6, lz); room.add(pl);
    lights.push({ l: pl, k: [0, 4, 7] });
  }

  return { glows, lights };
}
