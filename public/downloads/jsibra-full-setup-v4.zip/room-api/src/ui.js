// Semua yang berhubungan dengan DOM: panel, tombol, titik hotspot, urutan mimpi.
import * as THREE from 'three';
import { NAMES, ANCHOR, CONTENT, DREAMS, cart } from './content.js';

export function createUI(state) {
  const $ = id => document.getElementById(id);
  const panel = $('panel'), nav = $('nav'), dr = $('dream'), hint = $('hint'), pad = $('pad'), wb = $('wb'), tm = $('tm');
  const HINT = ['Klik tahan & geser untuk menoleh · F: mode jalan', 'Mouse = menoleh · WASD jalan · klik area kosong untuk kunci kursor (Esc: lepas) · F: keluar'];
  let dreamI = 0;
  hint.textContent = HINT[0];

  // titik hotspot + chip navigasi
  const dots = Object.keys(NAMES).filter(k => k !== 'switch').map(k => {
    const b = document.createElement('button');
    b.className = 'dot'; b.title = NAMES[k]; b.setAttribute('aria-label', NAMES[k]); b.onclick = () => openP(k); document.body.append(b);
    const n = document.createElement('button'); n.textContent = NAMES[k]; n.onclick = () => openP(k); nav.append(n);
    return { b, p: new THREE.Vector3(...ANCHOR[k]) };
  });

  let switchCb = null, adminCb = null;
  function openP(k) {
    if (k === 'switch') { switchCb?.(); return; } // saklar: tetap di mode jalan, kursor tidak dilepas
    document.exitPointerLock?.();
    if (k === 'bed') { sleep(); return; }
    state.focus = k; panel.dataset.mode = k;
    panel.innerHTML = `<button class="x" aria-label="Tutup">✕</button>` + CONTENT[k]();
    panel.classList.add('show'); panel.scrollTop = 0;
  }
  function closeP() { state.focus = null; panel.classList.remove('show'); }
  panel.addEventListener('click', e => {
    const t = e.target;
    if (t.classList.contains('x')) closeP();
    else if (t.dataset.buy !== undefined) { if (!cart.includes(t.dataset.buy)) cart.push(t.dataset.buy); t.textContent = '✓ Ditambahkan'; }
    else if (t.dataset.admin !== undefined) adminCb?.();
    else if (t.dataset.pay !== undefined) t.textContent = 'Demo: redirect ke Stripe Checkout…'; // TODO: fetch('/api/checkout')
  });

  // ---- mimpi
  const stars = $('stars');
  for (let i = 0; i < 50; i++) { const e = document.createElement('i'); e.style.cssText = `left:${Math.random() * 100}%;top:${Math.random() * 100}%;animation-delay:${Math.random() * 3}s`; stars.append(e); }
  function showDream() { const d = DREAMS[dreamI % 3]; $('dN').textContent = `${dreamI % 3 + 1} / 3`; $('dT').textContent = d[0]; $('dX').textContent = d[1]; dr.style.background = d[2]; }
  function sleep() { if (state.sleeping) return; state.sleeping = true; state.focus = 'bed'; panel.classList.remove('show'); showDream(); setTimeout(() => state.sleeping && dr.classList.add('on'), 2200); }
  function wake() { state.sleeping = false; dr.classList.remove('on'); state.focus = null; }
  $('dnext').onclick = () => { dreamI++; dr.classList.remove('on'); setTimeout(() => { if (state.sleeping) { showDream(); dr.classList.add('on'); } }, 900); };
  $('dwake').onclick = () => { dreamI++; wake(); };

  const v = new THREE.Vector3();
  return {
    openP, closeP, sleep, wake,
    onAdmin(fn) { adminCb = fn; },
    refreshPanel() { // data berubah (live) → segarkan panel yang sedang terbuka, kecuali panel admin
      const k = state.focus;
      if (!['about', 'shop', 'cart'].includes(k) || !panel.classList.contains('show')) return;
      const st = panel.scrollTop; panel.innerHTML = `<button class="x" aria-label="Tutup">✕</button>` + CONTENT[k](); panel.scrollTop = st;
    },
    tip: $('tip'),
    updateDots(camera) {
      for (const d of dots) {
        v.copy(d.p).project(camera);
        const ok = !state.focus && v.z < 1 && Math.abs(v.x) < 1.1 && Math.abs(v.y) < 1.1;
        d.b.style.display = ok ? 'block' : 'none';
        if (ok) d.b.style.transform = `translate(${(v.x * .5 + .5) * innerWidth}px,${(-v.y * .5 + .5) * innerHeight}px)`;
      }
    },
    setWalkUI(on) { wb.textContent = on ? '🚶 Jalan: ON' : '🚶 Jalan'; pad.classList.toggle('on', on); hint.textContent = HINT[+on]; },
    onWalk(fn) { wb.onclick = fn; },
    onSwitch(fn) { switchCb = fn; },
    onTime(fn) { tm.onclick = fn; },
    setTimeUI(m) { tm.textContent = ['🌇 Senja', '🌙 Malam', '☀️ Pagi'][m]; }, // label = mode berikutnya
    bindPad(keys) { pad.querySelectorAll('button').forEach(b => { const k = b.dataset.k; b.onpointerdown = () => keys[k] = 1; b.onpointerup = b.onpointerleave = b.onpointercancel = () => keys[k] = 0; }); },
    hideLoading() { const l = $('loading'); l.style.opacity = 0; setTimeout(() => l.remove(), 700); },
  };
}
