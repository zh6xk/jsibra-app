// Panel admin di komputer meja: login pemilik, lalu tambah / edit / hapus / urutkan buku portofolio & produk shop.
// Keamanan sebenarnya ada di server (cookie sesi httpOnly); sisi ini hanya tampilan.
import { store, esc, fmt } from './content.js';

const SWATCH = ['#9c3d2e', '#2f4858', '#d9a441', '#5b7f6b', '#e8dcc8', '#6b4c7a', '#c76b3a', '#ffb066', '#7aa2ff', '#7be0b0', '#c76b9a'];
const LIMIT = { books: 40, products: 12 };
const TABS = [['books', 'Portofolio'], ['products', 'Shop'], ['settings', 'Pengaturan']];

export function createAdmin({ panel, api, onContent }) {
  let me = false, tab = 'books', edit = null, delId = null, msg = '', ok = false;
  const active = () => panel.dataset.mode === 'admin';
  const shell = body => `<button class="x" aria-label="Tutup">✕</button><h2>Kelola konten</h2>${body}`;
  const note = () => `<div class="${ok ? 'ok' : 'err'}" role="status">${esc(msg)}</div>`;

  function swatches(sel) {
    return `<div class="sws">${SWATCH.map(c => `<button type="button" class="sw${c === sel ? ' on' : ''}" data-color="${c}" style="background:${c}" aria-label="Warna ${c}"></button>`).join('')}<input type="color" data-pick value="${esc(sel)}" aria-label="Warna lain"></div>`;
  }
  function form(coll) {
    const e = edit || {}, c = e.color || SWATCH[Math.floor(Math.random() * SWATCH.length)], full = !e.id && store[coll].length >= LIMIT[coll];
    const fields = coll === 'books'
      ? `<label class="fm">Judul<input name="title" maxlength="60" required value="${esc(e.title)}"></label>
         <label class="fm">Keterangan singkat<input name="desc" maxlength="160" placeholder="mis. UX · React · 2025" value="${esc(e.desc)}"></label>
         <label class="fm">Link karya (opsional)<input name="url" type="url" maxlength="300" placeholder="https://" value="${esc(e.url)}"></label>`
      : `<label class="fm">Nama produk<input name="name" maxlength="40" required value="${esc(e.name)}"></label>
         <label class="fm">Harga (${esc(store.currency)})<input name="price" type="number" min="0" step="any" required inputmode="decimal" value="${e.price ?? ''}"></label>
         <label class="fm">Keterangan (opsional)<input name="desc" maxlength="160" value="${esc(e.desc)}"></label>`;
    return `<form data-f="item" data-coll="${coll}"><h3>${e.id ? 'Edit' : 'Tambah'} ${coll === 'books' ? 'buku' : 'produk'}</h3>${fields}
      <div class="fm">Warna ${coll === 'books' ? 'sampul' : 'box'}${swatches(c)}<input type="hidden" name="color" value="${esc(c)}"></div>
      ${note()}<div class="acts"><button type="submit" class="pri"${full ? ' disabled' : ''}>${e.id ? 'Simpan perubahan' : 'Tambah ke rak'}</button>${e.id ? '<button type="button" data-act="cancel">Batal</button>' : ''}</div>
      <small>${store[coll].length}/${LIMIT[coll]} slot terpakai${full ? ' · penuh' : ''}</small></form>`;
  }
  function list(coll) {
    const items = store[coll];
    if (!items.length) return `<p>Belum ada item.</p>`;
    return items.map((it, i) => {
      const sub = coll === 'books' ? (it.desc || it.url) : fmt(it.price) + (it.desc ? ' · ' + it.desc : '');
      const del = delId === it.id
        ? `<button class="ic danger" data-act="del-yes" data-id="${it.id}">Yakin hapus?</button><button class="ic" data-act="del-no">Batal</button>`
        : `<button class="ic" data-act="up" data-id="${it.id}" aria-label="Naik"${i ? '' : ' disabled'}>▲</button><button class="ic" data-act="down" data-id="${it.id}" aria-label="Turun"${i < items.length - 1 ? '' : ' disabled'}>▼</button><button class="ic" data-act="edit" data-id="${it.id}" aria-label="Edit">✎</button><button class="ic" data-act="del" data-id="${it.id}" aria-label="Hapus">🗑</button>`;
      return `<div class="card li"><span class="dotc" style="background:${esc(it.color)}"></span><div><b>${esc(it.title || it.name)}</b><small>${esc(sub)}</small></div><div class="acts">${del}</div></div>`;
    }).join('');
  }
  function body() {
    if (!me) return `<p>Masuk untuk mengubah rak portofolio dan rak shop.</p>
      <form data-f="login"><label class="fm">Password<input type="password" name="pw" autocomplete="current-password" required></label>${note()}<button type="submit" class="pri">Masuk</button></form>`;
    const tabs = `<div class="tabs" role="tablist">${TABS.map(t => `<button type="button" role="tab" data-tab="${t[0]}" class="${t[0] === tab ? 'on' : ''}">${t[1]}</button>`).join('')}</div>`;
    if (tab === 'settings') return tabs + `<form data-f="settings"><label class="fm">Simbol mata uang<input name="currency" maxlength="4" required value="${esc(store.currency)}"></label>${note()}
      <div class="acts"><button type="submit" class="pri">Simpan</button><button type="button" data-act="logout">Keluar</button></div></form>`;
    return tabs + list(tab) + form(tab);
  }
  function render() {
    if (!active()) return;
    const st = panel.scrollTop; panel.innerHTML = shell(body()); panel.scrollTop = st;
  }
  const say = (m, good) => { msg = m; ok = !!good; };
  const fail = e => { if (e.status === 401) { me = false; say('Sesi habis, silakan masuk lagi.'); } else say(e.message); render(); };
  const apply = r => { onContent(r.content); };

  async function open() {
    panel.dataset.mode = 'admin'; edit = null; delId = null; msg = '';
    panel.innerHTML = shell('<p>Memuat…</p>'); panel.scrollTop = 0;
    try { me = (await api.me()).admin; } catch { me = false; say('Server tidak terjangkau.'); }
    render();
  }

  panel.addEventListener('click', async e => {
    if (!active()) return;
    const sw = e.target.closest('.sw');
    if (sw) { // pilih warna: ubah input tersembunyi + sorotan tanpa render ulang (isi form tetap)
      const f = sw.closest('form'); f.elements.color.value = sw.dataset.color; f.querySelector('[data-pick]').value = sw.dataset.color;
      f.querySelectorAll('.sw').forEach(b => b.classList.toggle('on', b === sw)); return;
    }
    const t = e.target.closest('[data-tab],[data-act]'); if (!t) return;
    if (t.dataset.tab) { tab = t.dataset.tab; edit = null; delId = null; msg = ''; return render(); }
    const { act, id } = t.dataset, coll = tab, item = store[coll]?.find(x => x.id === id);
    try {
      if (act === 'edit') { edit = { ...item }; msg = ''; render(); panel.scrollTop = panel.scrollHeight; }
      else if (act === 'cancel') { edit = null; msg = ''; render(); }
      else if (act === 'del') { delId = id; render(); }
      else if (act === 'del-no') { delId = null; render(); }
      else if (act === 'del-yes') { delId = null; apply(await api.del(coll, id)); if (edit?.id === id) edit = null; say('Dihapus dari rak.', true); render(); }
      else if (act === 'up' || act === 'down') { apply(await api.move(coll, id, act === 'up' ? -1 : 1)); msg = ''; render(); }
      else if (act === 'logout') { await api.logout(); me = false; say('Anda sudah keluar.', true); render(); }
    } catch (err) { fail(err); }
  });
  panel.addEventListener('input', e => { // pemilih warna bebas → sinkron ke input tersembunyi
    if (!active() || !e.target.matches('[data-pick]')) return;
    const f = e.target.closest('form'); f.elements.color.value = e.target.value; f.querySelectorAll('.sw').forEach(b => b.classList.remove('on'));
  });
  panel.addEventListener('submit', async e => {
    if (!active()) return; e.preventDefault();
    const f = e.target, fd = Object.fromEntries(new FormData(f)), btn = f.querySelector('[type=submit]'); btn.disabled = true;
    try {
      if (f.dataset.f === 'login') { await api.login(fd.pw); me = true; say(''); }
      else if (f.dataset.f === 'settings') { apply(await api.settings({ currency: fd.currency })); say('Tersimpan ✓', true); }
      else {
        const coll = f.dataset.coll; delete fd.undefined;
        apply(edit?.id ? await api.edit(coll, edit.id, fd) : await api.add(coll, fd));
        say(edit?.id ? 'Perubahan tersimpan ✓' : 'Ditambahkan ke rak ✓', true); edit = null;
      }
    } catch (err) { return fail(err); }
    render();
  });

  return { open };
}
