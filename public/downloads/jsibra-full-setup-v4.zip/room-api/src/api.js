// Klien API: konten publik, login admin, dan pembaruan live (SSE).
const BASE = import.meta.env.VITE_API_BASE || '/api/room';
const HD = { 'Content-Type': 'application/json', 'X-Requested-With': 'room' };

async function req(method, path, body) {
  const r = await fetch(BASE + path, { method, headers: HD, credentials: 'same-origin', body: body === undefined ? undefined : JSON.stringify(body) });
  let d = null; try { d = await r.json(); } catch (_) { }
  if (!r.ok) throw Object.assign(new Error(d?.error || `Gagal (${r.status})`), { status: r.status });
  return d;
}
export const api = {
  content: () => req('GET', '/content'),
  me: () => req('GET', '/me'),
  login: password => req('POST', '/login', { password }),
  logout: () => req('POST', '/logout'),
  add: (coll, item) => req('POST', '/' + coll, item),
  edit: (coll, id, item) => req('PUT', `/${coll}/${id}`, item),
  del: (coll, id) => req('DELETE', `/${coll}/${id}`),
  move: (coll, id, dir) => req('POST', `/${coll}/${id}/move`, { dir }),
  settings: s => req('PUT', '/settings', s),
};

// pembaruan live: server mengirim sinyal "update" → panggil onChange (ambil data terbaru)
export function subscribe(onChange) {
  if (!window.EventSource) { setInterval(onChange, 30000); return; }
  const es = new EventSource(BASE + '/stream'); let opened = false;
  es.addEventListener('update', onChange);
  es.onopen = () => { if (opened) onChange(); opened = true; }; // setelah koneksi putus-nyambung, sinkron ulang
}
