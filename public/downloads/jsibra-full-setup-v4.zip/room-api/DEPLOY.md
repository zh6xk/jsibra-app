# Panduan: admin rak (portofolio & shop) + live

Hasilnya: klik **komputer di meja → 🔒 Admin → masuk** → tambah / edit / hapus / urutkan **buku di rak kiri** dan **box + harga di rak kanan**.
Perubahan tersimpan di server (`data/content.json`) dan **langsung muncul live** di semua pengunjung yang sedang membuka halaman.

## Cara kerja singkat
- Pengunjung hanya bisa **membaca** `/api/room/content`. Semua perubahan ditolak server kecuali sudah login.
- Login = password milikmu (disimpan sebagai hash `scrypt` di `.env`, bukan di kode) → server memberi cookie sesi `HttpOnly + SameSite=Strict`, berlaku 7 hari. Salah password 5x → diblok 15 menit.
- Update live memakai Server-Sent Events (`/api/room/stream`).
- Server API ini tanpa dependency tambahan (hanya Node 18+), jalan terpisah di port 3100, jadi **aplikasi lama di port 3000 tidak diubah**.

## Langkah di laptop (build)
```bash
npm install
npm run build          # hasil di folder dist/
```
Salin isi `dist/` ke tempat room kamu disajikan sekarang (`public/room/` di app port 3000), seperti biasa.

## Langkah di Azure VM (API)
1. Upload folder project ini (tanpa `node_modules` dan `dist` tidak perlu) ke VM, mis. `~/room-api`. Pastikan Node 18+ (`node -v`).
2. Buat password admin (min. 10 karakter) lalu buat `.env`:
   ```bash
   cd ~/room-api
   npm run hash                 # ketik password → muncul 2 baris
   cp .env.example .env
   nano .env                    # tempel ADMIN_PASSWORD_HASH=... dan SESSION_SECRET=...
   chmod 600 .env
   ```
3. Jalankan dengan PM2:
   ```bash
   pm2 start ecosystem.config.cjs
   pm2 save
   ```
4. Nginx: tambahkan isi `nginx-room-api.conf` ke blok `server { }` jsibra.me (di atas `location /` yang ke port 3000), lalu:
   ```bash
   sudo nginx -t && sudo systemctl reload nginx
   ```
5. Tes: buka `https://jsibra.me/api/room/content` → harus muncul JSON. Lalu buka room, klik komputer → 🔒 Admin → masuk.

## Catatan penting
- **Pakai HTTPS.** Password dikirim saat login; cookie otomatis ditandai `Secure` kalau lewat HTTPS (Nginx harus mengirim `X-Forwarded-Proto`, sudah ada di snippet).
- **Backup** folder `data/` (isinya `content.json`).
- Ganti password: jalankan `npm run hash` lagi, ganti `ADMIN_PASSWORD_HASH` (dan sebaiknya `SESSION_SECRET` supaya semua sesi lama keluar), lalu `pm2 restart room-api`.
- Batas: 40 buku, 12 produk. Buku/produk baru menggantikan slot dari atas rak; sisa slot tetap berisi buku/box dekoratif.
- Developer: `npm start` (API di :3100) dan `npm run dev` di terminal lain; Vite meneruskan `/api/room` ke API lokal.
- Checkout Stripe di keranjang masih demo (belum ada pembayaran sungguhan).
