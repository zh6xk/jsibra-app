module.exports = { apps: [{ name: 'room-api', script: 'server/server.js', cwd: __dirname, max_memory_restart: '200M' }] };
