# Room Portfolio (Three.js + Vite)

Versi project dari demo single-file: kamar 3D semi-realistic dengan hotspot (Project, Tentang, Galeri, Toko, Keranjang, Kontak, Kasur/Mimpi), mode jalan, dan siang/malam.

## Jalankan
```bash
npm install
npm run dev        # http://localhost:5173  (tambah ?debug untuk panel tuning cahaya)
npm run build      # hasil di dist/, siap deploy (Vercel / Netlify / Cloudflare Pages)
```

## Struktur
| File | Isi |
|---|---|
| `src/main.js` | renderer, loop, resolusi adaptif, panel tuning (tekan **G**) |
| `src/room.js` | semua geometri & material kamar (satu-satunya file yang diganti jika pakai model GLB) |
| `src/lighting.js` | lampu, siang/malam, environment map, `PRESETS` intensitas |
| `src/controls.js` | input: drag (watching), pointer lock + WASD (jalan), kamera, hover/klik |
| `src/ui.js` | panel konten, titik hotspot, urutan mimpi |
| `src/content.js` | **data konten** (project, produk, posisi kamera) → ganti dengan fetch dari CMS/API |
| `src/textures.js` | tekstur prosedural (canvas) |

## Yang berubah dari versi single-file
- three.js modern (r170) via npm + ES modules, bukan CDN r128.
- Color management baru: warna hex otomatis benar, tekstur memakai `colorSpace`.
- **Satuan cahaya fisik**: angka intensitas beda dari versi lama. Sudah saya konversi kira-kira, tapi belum dicek visual. Tekan **G** untuk geser slider cahaya langsung, lalu salin angka bagus ke `PRESETS` di `lighting.js`.
- Kode dipecah per tanggung jawab, jadi gampang dirawat.

## Langkah berikutnya (urut dari dampak terbesar)
1. **Model dari Blender → GLB** (draco/meshopt + tekstur KTX2). Muat dengan `GLTFLoader`, beri nama node sama dengan key hotspot (`projects`, `about`, …) lalu ganti isi `room.js`. Ini lompatan kualitas terbesar (bevel asli, detail, baked lighting/AO).
2. **Bake lighting** di Blender, lalu matikan shadow map real-time → lebih cantik dan lebih ringan.
3. **Post-processing** (`three/examples/jsm/postprocessing`): GTAO/SSAO, bloom tipis, color grading. Jadikan opsi "kualitas tinggi".
4. **Stripe**: tombol checkout memanggil backend (`POST /api/checkout` → Stripe Checkout Session; webhook memperbarui order). Bisa dengan Vercel/Netlify Functions, atau pindah ke Next.js.
5. **CMS** (Sanity/Payload) untuk project & produk, ganti isi `content.js` dengan fetch.
6. Opsional: pindah ke **React Three Fiber + Next.js** kalau UI toko/admin makin besar. Logika di `controls.js` dan `lighting.js` bisa dipakai ulang.

## Peningkatan visual (v0.2)
- **Post-processing**: GTAO (ambient occlusion → kedalaman & kontak objek), bloom (lampu, layar, jendela), grading + vignette + grain + chromatic aberration tipis, MSAA 4x, tone mapping di akhir pipeline. Tambah `?q=low` (atau otomatis di layar sentuh) untuk mematikan AO di perangkat lemah.
- **Bevel asli** (`RoundedBoxGeometry`) di semua furnitur → tepi menangkap cahaya; UV skala dunia → serat kayu tidak melar.
- **Material**: clearcoat pada lantai & keramik, sheen pada kain.
- **Cahaya**: lampu area dari jendela, bayangan matahari 4096px, mode **Siang → Senja → Malam**.
- **Hidup**: jam dinding real-time, uap kopi, debu lembut di sinar matahari.
- Panel **G** kini punya slider `win` dan `bloom`; semua angka perlu di-tuning sekali secara visual, lalu disalin ke `PRESETS`.

## Pakai GPU RTX (bukan CPU / Intel)
Kode hanya bisa *meminta* GPU kuat (`powerPreference`); yang memutuskan adalah Windows + Chrome.
1. `chrome://settings/system` → aktifkan **Gunakan akselerasi grafis jika tersedia**, restart Chrome.
2. Windows: **Settings → System → Display → Graphics** → tambahkan `chrome.exe` → Options → **High performance** (pilih NVIDIA GeForce RTX), restart Chrome. (Alternatif: NVIDIA Control Panel → Manage 3D settings → Program Settings → Chrome → High-performance NVIDIA processor.)
3. Cek di `chrome://gpu`: baris *WebGL* harus *Hardware accelerated* dan *GL_RENDERER* berisi NVIDIA. Nama GPU yang dipakai juga dicetak di console (`[GPU]`).
4. Laptop: colok charger, mode daya *Best performance*.
Jika bukan NVIDIA, mode hemat otomatis aktif (tanpa AO, resolusi 1x). Paksa kualitas penuh dengan `?q=high`.

## Pengaturan grafis (v0.3)
Tombol **⚙ Grafis** (kiri atas): preset *Rendah / Sedang / Tinggi / Ultra* + slider resolusi, MSAA, ambient occlusion, bloom, kualitas bayangan, efek lensa, eksposur, FOV, resolusi adaptif, dan penghitung FPS. Pilihan tersimpan di browser. Preset awal dipilih otomatis dari GPU yang terdeteksi (`?q=low` / `?q=high` memaksa).
Tambahan visual: normal map prosedural (alur kayu & plester), tirai berlipat + tirai tipis bergoyang, bohlam lampu gantung menyala (bloom).

## Perbaikan (v0.3.1)
- **Lampu gantung** sekarang mengikuti mode: **mati saat Pagi**, menyala hangat saat Senja, terang penuh saat Malam. Kap dan bohlam punya material sendiri (`bulb` di `PRESETS`), dan cahaya `fill` saat Pagi diturunkan supaya plafon tidak silau.
- **Tombol mode hari** selalu menampilkan mode *berikutnya* dan label awalnya kini benar: Pagi → `🌇 Senja`, Senja → `🌙 Malam`, Malam → `☀️ Pagi`.

## Perbaikan (v0.4.1)
- **Layar kosong/gelap**: `update()` di `room.js` memanggil `refs.lightsOut`, padahal `refs` belum dideklarasikan (`ReferenceError`). Karena error terjadi tiap frame sebelum `composer.render()`, ruangan tidak pernah tergambar. Sekarang `refs` dideklarasikan lebih dulu.
- **Saklar lampu** menempel rata di dinding (sebelumnya melayang ±10 cm), dan mengkliknya di mode jalan tidak lagi melepas kunci kursor.
- **Lampu mati** kini hanya mematikan lampu buatan (lampu gantung, lampu meja, lampu tidur). Cahaya matahari/langit dari jendela tetap ada, dan kondisi mati tetap bertahan saat ganti mode (Pagi/Senja/Malam) atau mengubah pengaturan grafis.
- Material klon saat hover dibuang (`dispose`) supaya tidak menumpuk di memori.
- Buka dengan `?debug` untuk panel tuning cahaya (sekaligus menyediakan `window.__room` untuk testing).

## God rays volumetrik (v0.5)
Sinar matahari/bulan dari jendela sekarang **volumetrik sungguhan** (`src/volumetrics.js`), bukan lagi bidang tipis:
- Raymarching per piksel dari kamera sampai permukaan terdekat (depth buffer), tiap langkah mengecek **shadow map** matahari/bulan, jadi berkas terpotong oleh kusen jendela, tirai, dan perabot.
- Kabut berdebu (noise 3D yang bergerak pelan), fase 2 lobus (berkas terlihat dari samping dan makin menyilaukan saat menghadap cahaya), kompresi highlight supaya tidak blowout.
- Kerucut lampu meja serta halo lampu gantung dan lampu tidur ikut menghamburkan cahaya.
- Dihitung di setengah resolusi, lalu digabung ke gambar. Slider **Sinar cahaya (god rays)** ada di ⚙ Grafis (Rendah = mati, Sedang .6, Tinggi 1, Ultra 1.3). Kekuatan per mode ada di `PRESETS.*.rays` (panel G); kepadatan kabut = `dens`, kecerahan = `sunK` di `VolumetricPass`.
- Bidang sinar palsu (`beam`) otomatis dimatikan saat god rays aktif, dan dipakai lagi hanya di preset Rendah.
- Debug: buka `?debug`, lalu di konsol `__room.vol.comp.uniforms.dbg.value = 1` untuk melihat lapisan sinarnya saja.

## Saklar gaya modern (v0.5.1)
Saklar lampu di `room.js` dimodelkan ulang: bingkai krom tipis, plat datar glossy, tombol **rocker** lebar yang miring ke depan/belakang saat ditekan (sumbu horizontal, bukan berputar), dan garis LED indikator di bagian atas (hijau = lampu nyala, merah = mati). Ubah `SW_DARK = true` untuk versi grafit matte.

## Detail ruangan (v0.6) — `src/details.js`
Semua detail statis digabung per material (draw call tetap sedikit); lampu/neon/jendela kota otomatis mengikuti mode Pagi/Senja/Malam (registri `glows`).
- **Meja kerja**: desk mat, keyboard + keycap (instanced), headphone + stand, tempat pensil, foto berbingkai, tumpukan buku, sticky note, kabel monitor, permukaan kopi di mug, sandaran tangan kursor.
- **Kasur & nightstand**: selimut berkerut + lipatan, bantal gembung, bantal dekor, kancing headboard, kaki ranjang, **jam alarm digital waktu nyata**, gelas air, buku.
- **Rak toko**: label harga ($15/$29/$39 sesuai produk), LED di bawah rak, **neon "SHOP"**, label pengiriman di kardus.
- **Suasana**: lampu hias di dinding belakang & kanan, tali polaroid, **AC** di atas pintu (display 24°C), smoke detector, doormat, panel pintu, gantungan + ransel + tote bag, LED rak buku, tanaman di rak buku & ambang jendela, buku + lilin di ambang jendela, karpet berumbai.
- **Jendela**: pemandangan kota 2 lapis (siluet berwarna sesuai mode, jendela gedung menyala saat malam).
- **Kucing tidur** di karpet yang bernapas pelan.

## Kucing baru + animasi (v0.6.1) — `buildCat()` di `src/details.js`
Model prosedural: badan + paha + dada putih, kepala dengan pipi/moncong/hidung, **rahang** (menguap), telinga, **mata dengan kelopak**, kumis, kaki putih, dan **ekor 8 ruas**. Bulu memakai tekstur belang tabby + normal map + sheen.
Animasi (mesin status tidur ↔ waspada):
- **Tidur**: meringkuk, napas pelan, telinga berkedut acak, ujung ekor menyentil acak.
- **Bangun** saat pemain mendekat (<±2,4 m) atau acak tiap ±20–45 detik: **menguap**, kepala terangkat, mata terbuka, **kepala mengikuti kamera**, berkedip, ekor mengibas. Setelah pemain menjauh, kucing tidur lagi.
- Debug: `__room.world.refs.cat.force(1)` (waspada), `force(0)` (tidur), `force(null)` (otomatis). `FOCUS.cat` dan `FOCUS.catfar` = posisi kamera untuk melihat kucing dari dekat/jauh.

## Kucing v2 (v0.6.2)
- **Mata baru**: bola mata almond bertekstur (iris hijau-emas dengan cincin gelap), pupil celah yang melebar saat waspada, dua kilau mata, kelopak atas yang menutup/membuka halus, dan garis bulu mata (∪) saat tidur. Mata menghadap keluar-depan mengikuti bentuk kepala dan sudut luarnya sedikit naik. (Cincin eyeliner dihapus: terlihat seperti bulan sabit hitam saat mata tertutup.)
- **Bulu belang tabby "mackerel"** (UV diproyeksikan sepanjang badan → belang melingkar dari punggung), perut dan dada krem, garis kening, garis pipi, normal map + sheen.
- **Kaki** depan dan belakang kini tersambung ke badan (dulu telapak terlihat melayang), jumbai dada & pipi, telinga lebih halus, kumis alis, titik kumis, philtrum dan garis mulut.
- **Ekor** bergelang belang dengan sendi halus.
- `FOCUS.catface` = kamera untuk melihat wajah kucing dari dekat.

## v0.6.3
- Pipi kucing dikecilkan dan dipipihkan supaya tidak terbaca sebagai "mata kedua".
- Titik bidik mode jalan (crosshair) kini berbentuk tanda **+** tipis, bukan titik putih bulat yang bisa terlihat seperti bola mata saat menimpa wajah kucing.
- Cek versi: kucing versi terbaru berbelang **melintang** (seperti harimau kecil) dan punya moncong putih + kumis. Kalau belangnya terlihat memancar dari satu titik seperti benang, itu masih versi lama (cache/deploy lama).

## Audio ambient (v0.7) — `src/audio.js`
Suara dibuat **prosedural** dengan Web Audio API (tanpa file audio, tidak menambah ukuran download) dan otomatis mengikuti mode Pagi / Senja / Malam (crossfade ±3 detik):
- **Pagi**: kicau burung ramai (trill, siulan, cuit pendek) + angin sepoi.
- **Senja**: burung jarang, jangkrik mulai bunyi satu per satu, angin hangat, pad tenang yang sangat halus.
- **Malam**: jangkrik penuh (4 "suara" berbeda), burung hantu jauh, dengung sunyi.
- **Jam dinding** berdetak tiap detik (sinkron waktu nyata), paling terdengar saat malam.
- Suara luar ruangan condong ke kiri (arah jendela) dan memakai gema pendek supaya terasa jauh.
- Saat **tidur/mimpi** suara teredam (low-pass).
- Tombol **🔊/🔇** di kanan atas untuk mute; slider **Volume suara ambient** ada di ⚙ Grafis & Suara. Pilihan tersimpan di browser.
- Browser memblokir suara sebelum ada interaksi, jadi suara mulai pada klik/ketukan/tombol pertama (kecuali sebelumnya dimute). Suara otomatis berhenti saat tab disembunyikan.
- Menyetel campuran: ubah angka di tabel `LAYERS` (level per mode) di `audio.js`; kerapatan burung/jangkrik ada di pemanggilan `loop(...)` di `build()`.
