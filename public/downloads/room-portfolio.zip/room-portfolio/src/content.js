// Semua data konten ada di sini. Nanti bisa diganti fetch() dari CMS / API.
export const NAMES = { projects: 'Project', about: 'Tentang & Portofolio', gallery: 'Galeri Karya', shop: 'Toko', cart: 'Keranjang', contact: 'Kontak', bed: 'Tidur · Mimpi', switch: 'Kontak Lampu' };

// [posisi kamera, titik yang dilihat] saat sebuah objek diklik
export const FOCUS = {
  projects: [[.4, 2.2, -.9], [.2, 1.55, -3.4]],
  about: [[-.7, 2.2, .7], [-3.7, 1.7, -1.5]],
  gallery: [[-.3, 3.1, -.6], [-.3, 3.2, -4]],
  shop: [[2.9, 2, -.5], [2.9, 1.4, -3.6]],
  cart: [[3.2, 2.2, 2.6], [2.2, .4, 1.1]],
  contact: [[-.7, 2.2, -1.2], [-1, 1.05, -2.8]],
  bed: [[3.3, .98, -1.25], [2.6, 4.8, -1.25]],
  switch: [[3.2, 1.3, 1.45], [3.9, 1.3, 1.45]],
  cat: [[-.25, .75, 1.55], [-1.1, .18, .6]],
  catfar: [[.9, 1.3, 2.7], [-1.1, .1, .6]],
  catface: [[-.5, .4, .12], [-.9, .27, .42]],
};
export const ANCHOR = { projects: [.2, 2.5, -3.4], about: [-3.4, 2.2, -1.5], gallery: [-.3, 3.9, -3.9], shop: [2.9, 2.9, -3.3], cart: [2.2, .9, 1.1], contact: [-1, 1.3, -2.8], bed: [3, 1, -1.25], switch: [3.8, 1.3, 1.45] };

// kotak tabrakan mode jalan: [xMin, xMax, zMin, zMax]
export const OBSTACLES = [[-1.8, 1.8, -3.95, -2.4], [-4, -3.2, -2.8, -.2], [1.7, 4, -4, -3.3], [1.6, 4, -2.15, -.35], [1.6, 2.8, .4, 1.8], [-3.7, -2.7, 2.7, 3.9], [-.1, 1.1, -2.8, -1.6], [3.3, 4, -2.7, -2.1]];

export const PRODUCTS = [['UI Kit Dashboard', 29], ['Preset Lightroom Pack', 15], ['Template Portfolio', 39]];
export const cart = [];

export const DREAMS = [
  ['Mimpi 1 · Masa Depan', 'Bayangkan studio kecil dengan tim impian, membuat produk yang dipakai jutaan orang.', 'linear-gradient(#150b33,#3b1b6b)'],
  ['Mimpi 2 · Project Impian', 'Sebuah dunia 3D interaktif tempat setiap karya bisa dijelajahi seperti berjalan di museum.', 'linear-gradient(#04202f,#0b6e6e)'],
  ['Mimpi 3 · Kolaborasi', 'Bekerja bareng kreator dari seluruh dunia, saling melengkapi dari desain sampai kode.', 'linear-gradient(#2d0820,#8a2a4a)'],
];

export const CONTENT = {
  projects: () => `<h2>Project</h2><p>Studi kasus pilihan.</p>` + [['Aplikasi Fintech', 'UX · React · 2025'], ['Website 3D Brand X', 'Three.js · 2026'], ['Dashboard Analytics', 'Next.js · 2024']].map(p => `<div class="card"><div><b>${p[0]}</b><small>${p[1]}</small></div><button>Lihat</button></div>`).join(''),
  about: () => `<h2>Tentang & Portofolio</h2><p>Halo! Saya developer & desainer yang suka membuat pengalaman web yang berkesan.</p><p>${['React', 'Three.js', 'UI/UX', 'Node'].map(s => `<span class="tag">${s}</span>`).join('')}</p><div class="card"><div><b>Senior Frontend · Studio Y</b><small>2022 – sekarang</small></div></div><button>Download CV</button>`,
  gallery: () => `<h2>Galeri Karya</h2><p>Poster, ilustrasi, dan visual unggulan tampil sebagai grid gambar di sini.</p>`,
  shop: () => `<h2>Toko</h2><p>Produk digital · bayar via Stripe Checkout.</p>` + PRODUCTS.map((p, i) => `<div class="card"><div><b>${p[0]}</b><small>$${p[1]}</small></div><button data-buy="${i}">+ Keranjang</button></div>`).join(''),
  cart: () => cart.length ? `<h2>Keranjang</h2>` + cart.map(i => `<div class="card"><b>${PRODUCTS[i][0]}</b><small>$${PRODUCTS[i][1]}</small></div>`).join('') + `<p>Total: <b>$${cart.reduce((s, i) => s + PRODUCTS[i][1], 0)}</b></p><button data-pay>Checkout dengan Stripe</button>` : `<h2>Keranjang</h2><p>Masih kosong. Tambahkan produk dari rak toko.</p>`,
  contact: () => `<h2>Kontak</h2><p>Punya project atau pertanyaan?</p><div class="card"><div><b>halo@namakamu.com</b><small>Balasan 1–2 hari kerja</small></div><button>Kirim</button></div>`,
};
