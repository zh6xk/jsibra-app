// Cahaya volumetrik (god rays) sinematik.
// Raymarching di tiap piksel dari kamera sampai permukaan terdekat (depth buffer), lalu setiap langkah menanyakan
// shadow map matahari/bulan: "apakah titik ini terkena cahaya lewat jendela?". Hasilnya berkas cahaya sungguhan
// yang terpotong oleh kusen, tirai, dan perabot — plus kabut berdebu (noise 3D bergerak), fase Henyey-Greenstein
// (berkas makin terang saat kamera menghadap sumber cahaya), dan kerucut/halo lampu praktis.
// Dihitung di setengah resolusi lalu digabung ke gambar utama.
import * as THREE from 'three';
import { Pass, FullScreenQuad } from 'three/examples/jsm/postprocessing/Pass.js';

const VERT = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0., 1.); }';

const MARCH = /* glsl */`
uniform sampler2D tDepth, tShadow;
uniform mat4 projInv, camWorld, shadowMat;
uniform vec3 camPos, sunDir, sunCol, lampPos, lampDir, lampCol, pPos0, pCol0, pPos1, pCol1;
uniform vec2 lampCone;
uniform float time, hasShadow, hasDepth, dens, g;
varying vec2 vUv;
#include <packing>
float h13(vec3 p){ p = fract(p * .1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float h12(vec2 p){ vec3 q = fract(vec3(p.xyx) * .1031); q += dot(q, q.yzx + 33.33); return fract((q.x + q.y) * q.z); }
float vn(vec3 p){
  vec3 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(mix(h13(i), h13(i + vec3(1,0,0)), f.x), mix(h13(i + vec3(0,1,0)), h13(i + vec3(1,1,0)), f.x), f.y),
             mix(mix(h13(i + vec3(0,0,1)), h13(i + vec3(1,0,1)), f.x), mix(h13(i + vec3(0,1,1)), h13(i + vec3(1,1,1)), f.x), f.y), f.z);
}
float hg(float c, float k){ float k2 = k * k; return (1. - k2) / (12.566 * pow(1. + k2 - 2. * k * c, 1.5)); }
void main(){
  float d = hasDepth > .5 ? texture2D(tDepth, vUv).x : 1.;
  vec4 n = vec4(vUv * 2. - 1., d * 2. - 1., 1.); vec4 v = projInv * n; v /= v.w;
  vec3 wp = (camWorld * v).xyz, ro = camPos, dir = wp - ro; float maxT = length(dir); dir /= maxT;
  // batasi ke volume ruangan (AABB)
  vec3 bmin = vec3(-3.95, 0., -3.95), bmax = vec3(3.95, 4.95, 3.95), inv = 1. / dir;
  vec3 ta = (bmin - ro) * inv, tb = (bmax - ro) * inv, tmn = min(ta, tb), tmx = max(ta, tb);
  float t0 = max(max(max(tmn.x, tmn.y), tmn.z), 0.), t1 = min(min(min(tmx.x, tmx.y), tmx.z), maxT);
  if (t1 <= t0) { gl_FragColor = vec4(0.); return; }
  const int N = 44; float sl = (t1 - t0) / float(N), jit = h12(gl_FragCoord.xy + fract(time * .37) * 91.);
  float cs = dot(dir, sunDir), phS = .25 * hg(cs, g) + .75 * hg(cs, .15), phI = .08; // 2 lobus: berkas tetap terlihat dari samping, menyilaukan saat menghadap cahaya
  vec3 acc = vec3(0.);
  for (int i = 0; i < N; i++){
    float t = t0 + (float(i) + jit) * sl; vec3 p = ro + dir * t;
    float dn = dens * (.45 + 1.1 * (vn(p * .9 + vec3(0., time * .05, time * .03)) * .65 + vn(p * 2.4 + 7. - time * .04) * .35));
    float lit = 1.;
    if (hasShadow > .5){
      vec4 sc = shadowMat * vec4(p, 1.); vec3 u = sc.xyz / sc.w;
      if (u.x > 0. && u.x < 1. && u.y > 0. && u.y < 1. && u.z < 1.) lit = step(u.z - .003, unpackRGBAToDepth(texture2D(tShadow, u.xy)));
    }
    acc += sunCol * lit * phS * dn * sl;
    vec3 ld = p - lampPos; float dl = length(ld);
    float cone = smoothstep(lampCone.x, lampCone.y, dot(ld / dl, lampDir));
    acc += lampCol * cone / (1. + dl * dl * 1.4) * dn * sl * (phI + .25);
    vec3 a = p - pPos0, b = p - pPos1;
    acc += (pCol0 / (1. + dot(a, a) * 3.) + pCol1 / (1. + dot(b, b) * 3.)) * dn * sl * (phI + .3);
  }
  acc = acc / (1. + acc * .7); // kompresi highlight → tidak blowout
  gl_FragColor = vec4(acc, 1.);
}`;

const COMP = /* glsl */`
uniform sampler2D tColor, tVol; uniform vec2 texel; uniform float amount, dbg; varying vec2 vUv;
void main(){
  vec3 c = texture2D(tColor, vUv).rgb;
  vec3 v = texture2D(tVol, vUv).rgb * .4
    + (texture2D(tVol, vUv + vec2(texel.x, 0.)).rgb + texture2D(tVol, vUv - vec2(texel.x, 0.)).rgb
     + texture2D(tVol, vUv + vec2(0., texel.y)).rgb + texture2D(tVol, vUv - vec2(0., texel.y)).rgb) * .15;
  gl_FragColor = dbg > .5 ? vec4(v * 3., 1.) : vec4(c + v * amount, 1.); // dbg: tampilkan lapisan sinar saja
}`;

export class VolumetricPass extends Pass {
  constructor(camera, { sun, lamp, bed, fill }) {
    super();
    Object.assign(this, { camera, sun, lamp, bed, fill, amount: 1, needsSwap: true, sunK: 5.5, dens: .06, phase: .75 });
    this.volRT = new THREE.WebGLRenderTarget(1, 1, { type: THREE.HalfFloatType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: false });
    const V = (x, y, z) => ({ value: new THREE.Vector3(x, y, z) });
    this.march = new THREE.ShaderMaterial({
      vertexShader: VERT, fragmentShader: MARCH, depthTest: false, depthWrite: false,
      uniforms: { tDepth: { value: null }, tShadow: { value: null }, projInv: { value: new THREE.Matrix4() }, camWorld: { value: new THREE.Matrix4() }, shadowMat: { value: new THREE.Matrix4() },
        camPos: V(0, 0, 0), sunDir: V(0, 1, 0), sunCol: V(0, 0, 0), lampPos: V(0, 0, 0), lampDir: V(0, -1, 0), lampCol: V(0, 0, 0), pPos0: V(0, 0, 0), pCol0: V(0, 0, 0), pPos1: V(0, 0, 0), pCol1: V(0, 0, 0),
        lampCone: { value: new THREE.Vector2() }, time: { value: 0 }, hasShadow: { value: 0 }, hasDepth: { value: 0 }, dens: { value: .05 }, g: { value: .62 } },
    });
    this.comp = new THREE.ShaderMaterial({ vertexShader: VERT, fragmentShader: COMP, depthTest: false, depthWrite: false,
      uniforms: { tColor: { value: null }, tVol: { value: null }, texel: { value: new THREE.Vector2(1, 1) }, amount: { value: 1 }, dbg: { value: 0 } } });
    this.quad = new FullScreenQuad(null); this._t = new THREE.Vector3(); this._c = new THREE.Color(); this._s = performance.now();
  }
  setSize(w, h) {
    this.volRT.setSize(Math.max(1, w >> 1), Math.max(1, h >> 1));
    this.comp.uniforms.texel.value.set(1 / this.volRT.width, 1 / this.volRT.height);
  }
  col(light, k, target) { this._c.copy(light.color).multiplyScalar(light.intensity * k); target.set(this._c.r, this._c.g, this._c.b); }
  render(renderer, writeBuffer, readBuffer) {
    const u = this.march.uniforms, { camera, sun, lamp, bed, fill } = this;
    camera.updateMatrixWorld();
    u.projInv.value.copy(camera.projectionMatrixInverse); u.camWorld.value.copy(camera.matrixWorld); u.camPos.value.setFromMatrixPosition(camera.matrixWorld);
    u.tDepth.value = readBuffer.depthTexture; u.hasDepth.value = readBuffer.depthTexture ? 1 : 0;
    const sm = sun.shadow.map; u.hasShadow.value = sm && sun.intensity > .01 ? 1 : 0; if (sm) u.tShadow.value = sm.texture;
    u.shadowMat.value.copy(sun.shadow.matrix); u.sunDir.value.copy(sun.position).sub(sun.target.position).normalize();
    this.col(sun, this.sunK, u.sunCol.value);
    u.lampPos.value.copy(lamp.position); u.lampDir.value.copy(lamp.target.position).sub(lamp.position).normalize();
    u.lampCone.value.set(Math.cos(lamp.angle), Math.cos(lamp.angle * (1 - lamp.penumbra * .6))); this.col(lamp, .02, u.lampCol.value);
    u.pPos0.value.copy(fill.position); this.col(fill, .006, u.pCol0.value); u.pPos1.value.copy(bed.position); this.col(bed, .05, u.pCol1.value);
    u.dens.value = this.dens; u.g.value = this.phase; u.time.value = (performance.now() - this._s) / 1000;
    this.quad.material = this.march; renderer.setRenderTarget(this.volRT); this.quad.render(renderer);
    const c = this.comp.uniforms; c.tColor.value = readBuffer.texture; c.tVol.value = this.volRT.texture; c.amount.value = this.amount;
    this.quad.material = this.comp; renderer.setRenderTarget(this.renderToScreen ? null : writeBuffer); this.quad.render(renderer);
  }
  dispose() { this.volRT.dispose(); this.march.dispose(); this.comp.dispose(); this.quad.dispose(); }
}
