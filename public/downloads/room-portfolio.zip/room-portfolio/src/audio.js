// Audio ambient prosedural (Web Audio API). Tanpa file audio, jadi tidak menambah ukuran download.
//  Pagi  : kicau burung ramai + angin sepoi
//  Senja : burung jarang, jangkrik mulai bunyi, angin hangat, dengung tenang
//  Malam : jangkrik penuh, burung hantu jauh, dengung sunyi
// Jam dinding berdetak tiap detik (sinkron dengan waktu nyata). Semua lapisan mengikuti mode Pagi/Senja/Malam.
// Browser memblokir suara sebelum ada interaksi, jadi start() dipanggil dari klik/tombol pertama.

// level tiap lapisan per mode [pagi, senja, malam]; ubah angka di sini untuk menyetel campuran suara
const LAYERS = {
  wind:  [.8, .9, .6],
  hum:   [.5, .6, 1],
  pad:   [0, .5, 1],
  birds: [1, .22, 0],
  crick: [0, .4, 1],
  owl:   [0, 0, 1],
  tick:  [.4, .5, 1],
};
const rnd = (a, b) => a + Math.random() * (b - a);

export function createAudio() {
  let ctx = null, master, muffle, birdBus, wind, windBp, hum, pad, brown, white, tock = false;
  let mode = 0, vol = .7, muted = false, muffled = false;
  const lv = {};
  for (const k in LAYERS) lv[k] = LAYERS[k][0];

  function lfo(freq, amp, param) {
    const o = ctx.createOscillator(), g = ctx.createGain();
    o.frequency.value = freq; g.gain.value = amp; o.connect(g); g.connect(param); o.start();
  }
  function noiseBuf(secs, kind) {
    const n = ctx.sampleRate * secs | 0, b = ctx.createBuffer(2, n, ctx.sampleRate);
    for (let c = 0; c < 2; c++) {
      const d = b.getChannelData(c); let last = 0;
      for (let i = 0; i < n; i++) {
        const w = Math.random() * 2 - 1;
        if (kind === 'brown') { last = (last + .02 * w) / 1.02; d[i] = last * 3.5; } else d[i] = w;
      }
    }
    return b;
  }
  const panner = p => { const n = ctx.createStereoPanner(); n.pan.value = p; return n; };
  const loopSrc = (buf, off) => { const s = ctx.createBufferSource(); s.buffer = buf; s.loop = true; s.start(ctx.currentTime, off); return s; };

  // satu nada dengan envelope + sapuan frekuensi
  function tone(t, f0, f1, dur, v, pan, dest) {
    const o = ctx.createOscillator(), g = ctx.createGain(), p = panner(pan);
    o.type = 'sine'; o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(f1, t + dur);
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + dur * .2); g.gain.exponentialRampToValueAtTime(.0001, t + dur);
    o.connect(g); g.connect(p); p.connect(dest); o.start(t); o.stop(t + dur + .05);
  }

  // jendela ada di dinding kiri → suara luar sedikit condong ke kiri
  function bird(l) {
    const pan = rnd(-.85, -.1), base = rnd(2300, 3600), v = .13 * l, t0 = ctx.currentTime + .05, k = Math.random();
    if (k < .4) { // trill naik/turun
      const n = 4 + (Math.random() * 6 | 0), dir = Math.random() < .5 ? 1 : -1;
      for (let i = 0; i < n; i++) { const f = base * (1 + dir * i * .03); tone(t0 + i * .085, f, f * 1.25, .07, v, pan, birdBus); }
    } else if (k < .75) { // siulan dua nada
      tone(t0, base * .8, base * 1.1, .2, v, pan, birdBus); tone(t0 + .26, base * 1.1, base * .85, .26, v, pan, birdBus);
    } else { // tiga cuit pendek
      for (let i = 0; i < 3; i++) tone(t0 + i * .14, base * 1.2, base * .9, .09, v, pan, birdBus);
    }
  }
  function cricket(pitch, pan, pulses, l) { // satu rangkaian "krik-krik-krik" = satu osilator dengan beberapa denyut
    const t0 = ctx.currentTime + .05, o = ctx.createOscillator(), g = ctx.createGain(), p = panner(pan), v = .06 * l;
    o.type = 'sine'; o.frequency.value = pitch * (1 + rnd(-.012, .012));
    g.gain.setValueAtTime(0, t0);
    for (let i = 0; i < pulses; i++) { const t = t0 + i * .036; g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(v, t + .008); g.gain.linearRampToValueAtTime(0, t + .026); }
    o.connect(g); g.connect(p); p.connect(master); o.start(t0); o.stop(t0 + pulses * .036 + .05);
  }
  function owl(l) {
    const t0 = ctx.currentTime + .1, pan = rnd(-.8, -.3), f = rnd(330, 400), v = .14 * l;
    const hoo = (t, ff) => tone(t, ff * 1.05, ff, .38, v, pan, birdBus);
    hoo(t0, f); hoo(t0 + .55, f * .93);
    if (Math.random() < .5) { hoo(t0 + 1.25, f * .95); hoo(t0 + 1.8, f * .88); }
  }
  function tick(l) { // detak jam dinding: letupan noise pendek lewat bandpass, selang-seling tick/tock
    const t = ctx.currentTime + .01, s = ctx.createBufferSource(), bp = ctx.createBiquadFilter(), g = ctx.createGain();
    tock = !tock; s.buffer = white; bp.type = 'bandpass'; bp.frequency.value = tock ? 1700 : 2300; bp.Q.value = 4;
    g.gain.setValueAtTime(0, t); g.gain.linearRampToValueAtTime(.35 * l, t + .002); g.gain.exponentialRampToValueAtTime(.0001, t + .035);
    const pn = panner(.25); s.connect(bp); bp.connect(g); g.connect(pn); pn.connect(master);
    s.start(t, rnd(0, .8)); s.stop(t + .06);
  }

  // penjadwal acak: fn dipanggil dengan level lapisan; jarak antar-kejadian makin rapat saat level naik
  function loop(name, fn, gap, th = .03, first = [500, 3000]) {
    const run = () => {
      if (ctx && ctx.state === 'running' && !muted && lv[name] > th) fn(lv[name]);
      setTimeout(run, gap(Math.max(lv[name], .15)) * 1000);
    };
    setTimeout(run, rnd(first[0], first[1]));
  }

  function build() {
    try { if (navigator.audioSession) navigator.audioSession.type = 'playback'; } catch (_) { } // iOS: abaikan saklar silent
    ctx = new (window.AudioContext || window.webkitAudioContext)();
    ctx.onstatechange = () => console.info('[audio] state:', ctx.state);
    const comp = ctx.createDynamicsCompressor(); comp.threshold.value = -18; comp.knee.value = 20; comp.ratio.value = 4;
    muffle = ctx.createBiquadFilter(); muffle.type = 'lowpass'; muffle.frequency.value = 20000; // meredam saat "tidur"
    master = ctx.createGain(); master.gain.value = 0;
    master.connect(muffle); muffle.connect(comp); comp.connect(ctx.destination);
    brown = noiseBuf(6, 'brown'); white = noiseBuf(1, 'white');

    // angin: noise cokelat → bandpass; kekuatan & frekuensi bergelombang pelan (hembusan)
    windBp = ctx.createBiquadFilter(); windBp.type = 'bandpass'; windBp.frequency.value = 420; windBp.Q.value = .5;
    wind = ctx.createGain(); wind.gain.value = 0;
    loopSrc(brown, 0).connect(windBp); windBp.connect(wind); wind.connect(master);
    lfo(.09, .08, wind.gain); lfo(.05, 160, windBp.frequency);

    // drone tetap yang jelas terdengar
    const drone = ctx.createOscillator();
    const droneGain = ctx.createGain();
    drone.type = 'triangle';
    drone.frequency.value = 196; // G3
    droneGain.gain.value = 0.08;
    drone.connect(droneGain);
    droneGain.connect(master);
    drone.start();
    hum = ctx.createGain(); hum.gain.value = 0;
    loopSrc(brown, 3).connect(hlp); hlp.connect(hum); hum.connect(master);
    pad = ctx.createGain(); pad.gain.value = 0; pad.connect(master);
    for (const f of [98, 147.3]) { const o = ctx.createOscillator(); o.frequency.value = f; lfo(.11, .4, o.frequency); o.connect(pad); o.start(); }

    // bus suara luar ruangan dengan gema pendek (kesan jarak)
    birdBus = ctx.createGain(); birdBus.connect(master);
    const dly = ctx.createDelay(1), fb = ctx.createGain(), wet = ctx.createGain(), lp = ctx.createBiquadFilter();
    dly.delayTime.value = .27; fb.gain.value = .3; wet.gain.value = .35; lp.type = 'lowpass'; lp.frequency.value = 3200;
    birdBus.connect(dly); dly.connect(lp); lp.connect(fb); fb.connect(dly); lp.connect(wet); wet.connect(master);

    loop('birds', bird, l => rnd(2.5, 7) / l);
    [[4200, -.7, 4, .5, 0], [4700, .6, 3, .62, .2], [3900, -.2, 5, .7, .4], [5100, .8, 3, .45, .6]].forEach(([f, pan, n, g, th]) =>
      loop('crick', l => cricket(f, pan, n, l), l => (g + rnd(0, .25)) / (.35 + l * .65), th));
    loop('owl', owl, l => rnd(28, 50) / Math.max(l, .3), .03, [9000, 16000]);
    (function schedTick() { // sejajarkan dengan detik nyata
      setTimeout(() => { if (ctx.state === 'running' && !muted && lv.tick > .03) tick(lv.tick); schedTick(); }, 1000 - Date.now() % 1000);
    })();
  }

  function applyLevels() {
    for (const k in LAYERS) lv[k] = LAYERS[k][mode];
    if (!ctx) return;
    const t = ctx.currentTime;
    wind.gain.setTargetAtTime(.35 * lv.wind, t, 2); windBp.frequency.setTargetAtTime([500, 380, 300][mode], t, 2);
    hum.gain.setTargetAtTime(.35 * lv.hum, t, 2); pad.gain.setTargetAtTime(.03 * lv.pad, t, 2);
  }
  function applyMaster() {
    const t = ctx.currentTime;
    const target = muted ? 0 : vol * 2.0 * (muffled ? .7 : 1);
    master.gain.setValueAtTime(target, t);
    muffle.frequency.setTargetAtTime(muffled ? 650 : 20000, t, .6);
  }

  return {
    get started() { return !!ctx; },
    start() { if (!ctx) build(); if (ctx.state === 'suspended') ctx.resume().catch(e => console.warn('[audio] resume gagal', e)); applyLevels(); applyMaster(); console.info('[audio] start, state:', ctx.state); },
    setMode(m) { mode = m; applyLevels(); },
    setVolume(v) { vol = v; if (ctx) applyMaster(); },
    setMute(b) { muted = b; if (ctx) applyMaster(); },
    setMuffled(b) { if (b === muffled) return; muffled = b; if (ctx) applyMaster(); },
    pause() { ctx && ctx.state === 'running' && ctx.suspend(); },
    resume() { ctx && !muted && ctx.state === 'suspended' && ctx.resume(); },
  };
}
