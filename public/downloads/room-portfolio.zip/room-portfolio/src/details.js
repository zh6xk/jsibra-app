// Detail tambahan ruangan (semua statis digabung per material → draw call tetap sedikit).
// Isi: meja kerja, kursor, kasur, nightstand, rak toko, lampu hias, neon, polaroid, AC, gantungan tas, kucing tidur,
// tanaman, pemandangan kota di balik jendela, karpet berumbai, dan lain-lain. Lampu/neon/jendela kota mengikuti mode hari.
import * as THREE from 'three';
import { mergeGeometries } from 'three/examples/jsm/utils/BufferGeometryUtils.js';
import { ct, rnd, posterTexture, normalMap, blobTexture } from './textures.js';

const PI = Math.PI;
function leafGeometry() {
  const s = new THREE.Shape(); s.moveTo(0, 0); s.bezierCurveTo(.32, .08, .38, .62, 0, 1); s.bezierCurveTo(-.38, .62, -.32, .08, 0, 0);
  const g = new THREE.ShapeGeometry(s, 8), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) p.setZ(i, p.getY(i) ** 2 * .22 + Math.abs(p.getX(i)) * .1);
  g.computeVertexNormals(); return g;
}
function wrinkled(w, h, d, amp) { // selimut berkerut
  const g = new THREE.BoxGeometry(w, h, d, 28, 3, 32), p = g.attributes.position;
  for (let i = 0; i < p.count; i++) {
    const x = p.getX(i), y = p.getY(i), z = p.getZ(i);
    if (y > 0) p.setY(i, y + amp * Math.min(1, (w / 2 - Math.abs(x)) * 6, (d / 2 - Math.abs(z)) * 6) * (Math.sin(x * 11 + z * 3) * .5 + Math.sin(z * 8 - x * 6) * .35 + Math.sin(x * 23 + z * 17) * .15));
  }
  g.computeVertexNormals(); return g;
}
const label = (text, bg, fg, w = 128, h = 64, size = 24) => ct(w, h, g => {
  g.fillStyle = bg; g.fillRect(0, 0, w, h); g.fillStyle = fg; g.font = `bold ${size}px system-ui,sans-serif`; g.textAlign = 'center'; g.textBaseline = 'middle';
  text.split('\n').forEach((t, i, a) => g.fillText(t, w / 2, h / 2 + (i - (a.length - 1) / 2) * (size + 2)));
});

export function buildDetails({ room, bx, cy, M, mats }) {
  const { mWood, mTrim, mDark, mMetal, mCer, mTerra } = mats;
  const S = new THREE.Group(); room.add(S);              // statis → digabung di akhir
  const cache = new Map(), glows = [];
  const C = (hex, o = {}) => { const k = hex + JSON.stringify(o); if (!cache.has(k)) cache.set(k, M(hex, o)); return cache.get(k); };
  // material bercahaya: k = pengali per mode [pagi, senja, malam] (angka) atau warna tetap (THREE.Color)
  const glow = (hex, k, o = {}) => { const m = new THREE.MeshBasicMaterial({ color: hex, ...o }); m.userData.base = m.color.clone(); glows.push({ m, k }); return m; };
  const add = (G, geo, mat, x, y, z) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.castShadow = m.receiveShadow = true; G.add(m); return m; };
  const sph = (G, r, x, y, z, mat, sx = 1, sy = 1, sz = 1, seg = 20) => { const m = add(G, new THREE.SphereGeometry(r, seg, Math.round(seg * .65)), mat, x, y, z); m.scale.set(sx, sy, sz); return m; };
  const plane = (G, w, h, mat, x, y, z, ry = 0, rx = 0, rz = 0) => { const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat); p.position.set(x, y, z); p.rotation.set(rx, ry, rz); p.receiveShadow = true; G.add(p); return p; };
  const tube = (G, pts, r, mat) => { const m = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3(pts.map(p => new THREE.Vector3(...p))), 60, r, 5), mat); m.castShadow = true; G.add(m); return m; };
  const dm = new THREE.Object3D();
  const live = [];

  // ================= MEJA KERJA
  bx(S, 1.05, .006, .46, .2, 1.043, -3.1, C('#2a2d36', { roughness: 1 }), .002);                       // desk mat
  const keys = new THREE.InstancedMesh(new THREE.BoxGeometry(.03, .012, .03), C('#d9d4cc', { roughness: .5 }), 70);
  for (let i = 0; i < 70; i++) { dm.position.set(.2 - .243 + (i % 14) * .0375, 1.088, -3.05 - .07 + Math.floor(i / 14) * .035); dm.updateMatrix(); keys.setMatrixAt(i, dm.matrix); }
  keys.receiveShadow = true; S.add(keys);                                                                // keycap
  cy(S, .05, .06, .02, 1.0, 1.05, -3.55, mDark, 20); cy(S, .008, .008, .17, 1.0, 1.13, -3.55, mDark, 6);   // headphone + stand
  add(S, new THREE.TorusGeometry(.085, .01, 8, 24, PI), mDark, 1.0, 1.225, -3.55);
  for (const s of [-1, 1]) { const c = cy(S, .035, .035, .03, 1.0 + s * .085, 1.2, -3.55, mDark, 16); c.rotation.z = PI / 2; }
  cy(S, .035, .03, .1, -.55, 1.09, -3.7, mDark, 16);                                                       // pen cup + pens
  ['#d44', '#48c', '#4a4', '#fb2'].forEach((c, i) => { const p = cy(S, .004, .004, .15, -.55 + (i - 1.5) * .012, 1.17, -3.7, C(c), 6); p.rotation.z = (i - 1.5) * .12; });
  bx(S, .17, .21, .012, -.28, 1.15, -3.78, mWood, .004).rotation.x = -.15;                                // foto berbingkai
  const ph = plane(S, .14, .18, new THREE.MeshStandardMaterial({ map: posterTexture(1), roughness: .5 }), -.28, 1.152, -3.771); ph.rotation.x = -.15;
  [['#2f4858', .34, .05], ['#d9a441', .3, .04], ['#9c3d2e', .27, .035]].forEach((b, i) => bx(S, b[1], b[2], b[1] * .7, -1.25, 1.065 + i * .045, -3.35, C(b[0], { roughness: .8 }), .006).rotation.y = i * .15);
  cy(S, .042, .042, .003, -.45, 1.1415, -2.8, C('#2b1d14', { roughness: .15 }), 20);                      // permukaan kopi
  plane(S, .045, .045, C('#ffe066', { roughness: 1 }), -.51, 2.0, -3.563, 0, 0, .12); plane(S, .045, .045, C('#ff9eb5', { roughness: 1 }), -.52, 1.94, -3.563, 0, 0, -.1); // sticky note
  tube(S, [[.2, 1.08, -3.55], [.2, 1.05, -3.8], [.05, 1.0, -3.86], [.05, .5, -3.9], [.35, .03, -3.9]], .007, mDark); // kabel monitor
  // kursor: sandaran tangan
  for (const s of [-1, 1]) { bx(S, .05, .03, .5, .5 + s * .47, 1.1, -2.2, mDark, .01); bx(S, .03, .22, .03, .5 + s * .47, 1.0, -2.05, mDark, .005); }

  // ================= KASUR + NIGHTSTAND
  const duv = C('#5a6f8f', { roughness: 1, sheen: 1, sheenColor: new THREE.Color('#a9bddd') }), pil = C('#f4f0ea', { roughness: .95, sheen: 1, sheenColor: new THREE.Color('#fff') });
  add(S, wrinkled(1.22, .05, 1.42, .022), duv, 2.35, .7, -1.25);                                          // selimut berkerut
  cy(S, .065, .065, 1.4, 3.05, .7, -1.25, C('#c9d3e6', { roughness: 1 }), 14).rotation.x = PI / 2;      // lipatan selimut
  sph(S, .3, 3.6, .78, -1.65, pil, 1, .27, 1.12, 28).rotation.y = .05; sph(S, .3, 3.6, .78, -.85, pil, 1, .27, 1.12, 28).rotation.y = -.06;
  sph(S, .2, 3.32, .8, -1.25, C('#c9784a', { roughness: .95, sheen: 1, sheenColor: new THREE.Color('#ffd0a8') }), 1, .45, 1, 24).rotation.set(.3, .5, .2);
  for (const [x, z] of [[1.9, -.6], [1.9, -1.9], [3.8, -.6], [3.8, -1.9]]) cy(S, .035, .03, .1, x, .05, z, mWood, 12);
  for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) sph(S, .02, 3.877, .55 + j * .5, -1.65 + i * .4, mats.mBrass || mMetal);   // kancing headboard
  const aClock = ct(128, 64, () => { }), acx = aClock.image.getContext('2d');                              // jam alarm digital (waktu nyata)
  const mAlarm = glow(0xffffff, [.7, 1.1, 2], { map: aClock });
  bx(S, .05, .07, .11, 3.5, .565, -2.28, mDark, .008); plane(S, .1, .05, mAlarm, 3.474, .575, -2.28, -PI / 2);
  let lastSec = -1;
  live.push(() => { const d = new Date(), s = d.getSeconds(); if (s === lastSec) return; lastSec = s;
    acx.fillStyle = '#080404'; acx.fillRect(0, 0, 128, 64); acx.fillStyle = '#ff5a3c'; acx.font = 'bold 44px monospace'; acx.textAlign = 'center'; acx.textBaseline = 'middle';
    acx.fillText(String(d.getHours()).padStart(2, '0') + (s % 2 ? ':' : ' ') + String(d.getMinutes()).padStart(2, '0'), 64, 34); aClock.needsUpdate = true; });
  const glass = new THREE.Mesh(new THREE.CylinderGeometry(.03, .025, .09, 16), new THREE.MeshPhysicalMaterial({ color: '#dff3ff', transparent: true, opacity: .3, roughness: .05 })); glass.position.set(3.82, .58, -2.52); S.add(glass);
  cy(S, .026, .022, .06, 3.82, .565, -2.52, C('#bfe4ff', { roughness: .1 }), 16);                          // air di gelas
  bx(S, .2, .03, .14, 3.55, .545, -2.52, C('#9c3d2e', { roughness: .8 }), .004).rotation.y = .3;           // buku di nightstand

  // ================= RAK TOKO: label harga, LED, neon "SHOP"
  const tags = [label('$15', '#fbf7ef', '#222'), label('$29', '#fbf7ef', '#222'), label('$39', '#fbf7ef', '#222')].map(t => new THREE.MeshStandardMaterial({ map: t, roughness: .8 }));
  [.05, .7, 1.35].forEach((y, r) => [0, 1, 2].forEach(i => plane(S, .13, .06, tags[(i + r) % 3], 2.3 + i * .55, y, -3.548)));
  const warmLed = glow(0xffb066, [.4, 1.1, 2.4]);
  [.665, 1.315, 1.965].forEach(y => bx(S, 1.9, .012, .012, 2.9, y, -3.56, warmLed, .003));
  const neonT = ct(512, 128, (g, w, h) => { g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = 'bold 84px "Trebuchet MS",system-ui,sans-serif'; g.shadowColor = '#ff6fb0'; g.shadowBlur = 28; g.fillStyle = '#ff6fb0'; g.fillText('SHOP', w / 2, h / 2 + 4); g.fillText('SHOP', w / 2, h / 2 + 4); g.shadowBlur = 6; g.fillStyle = '#fff'; g.fillText('SHOP', w / 2, h / 2 + 4); });
  const neon = plane(S, 1.7, .43, glow(0xffffff, [.6, 1.6, 3], { map: neonT, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false }), 2.9, 3.45, -3.96); neon.userData.noMerge = true;
  // kardus [cart]: label pengiriman
  plane(S, .28, .18, new THREE.MeshStandardMaterial({ map: label('ORDER\n#1024', '#fff', '#222'), roughness: .7 }), 2.4, .38, 1.553);

  // ================= LAMPU HIAS (punggung dinding belakang + dinding kanan)
  const bulbs = [], swag = (a, b, fix) => { for (let i = 0; i <= 30; i++) { const t = i / 30; bulbs.push(fix(a + (b - a) * t, 4.64 - Math.sin(t * PI * 4 % PI) * .22)); } };
  swag(-3.8, 3.8, (u, y) => new THREE.Vector3(u, y, -3.9)); swag(-3.8, 3.8, (u, y) => new THREE.Vector3(3.9, y, -u));
  const fairy = glow(0xffd9a0, [.3, 1.2, 3.5]);
  const bi = new THREE.InstancedMesh(new THREE.SphereGeometry(.03, 10, 8), fairy, bulbs.length); bulbs.forEach((p, i) => { dm.position.copy(p); dm.updateMatrix(); bi.setMatrixAt(i, dm.matrix); }); S.add(bi);
  tube(S, bulbs.slice(0, 31).map(p => p.toArray()), .004, mDark); tube(S, bulbs.slice(31).map(p => p.toArray()), .004, mDark);

  // ================= POLAROID di dinding belakang (kiri poster)
  const cord = Array.from({ length: 9 }, (_, i) => { const t = i / 8; return [-3.7 + t * 1.6, 3.35 - Math.sin(t * PI) * .22, -3.985]; });
  tube(S, cord, .003, mDark);
  const pf = C('#f6f1e6', { roughness: .9 }), pm = [0, 1, 2].map(i => new THREE.MeshStandardMaterial({ map: posterTexture(i), roughness: .6 }));
  for (let i = 0; i < 6; i++) { const t = (i + .5) / 6, y = 3.35 - Math.sin(t * PI) * .22 - .1, x = -3.7 + t * 1.6, rz = (rnd() - .5) * .35;
    plane(S, .12, .145, pf, x, y, -3.985, 0, 0, rz); plane(S, .1, .1, pm[i % 3], x, y + .012, -3.983, 0, 0, rz); bx(S, .012, .03, .008, x, y + .085, -3.98, mWood, .002); }

  // ================= AC (dinding kanan di atas pintu) + smoke detector + stop kontak + doormat
  const white = C('#f2f4f6', { roughness: .35, clearcoat: .5 });
  bx(S, .2, .3, 1.0, 3.9, 4.05, 2.2, white, .04); bx(S, .03, .045, .9, 3.8, 3.915, 2.2, C('#d5d9de', { roughness: .4 }), .01).rotation.z = .3;
  const acT = ct(128, 48, g => { g.fillStyle = '#05140a'; g.fillRect(0, 0, 128, 48); g.fillStyle = '#4dff88'; g.font = 'bold 34px monospace'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText('24°C', 64, 26); });
  plane(S, .13, .05, glow(0xffffff, [1, 1.4, 1.6], { map: acT }), 3.795, 4.0, 2.58, -PI / 2);
  cy(S, .07, .07, .03, 1.6, 4.985, -1, C('#f5f5f2')); cy(S, .008, .008, .005, 1.6, 4.966, -1, glow(0xff3030, [1, 1, 2]), 8);
  bx(S, .45, .02, .7, 3.45, .01, 2.2, C('#5a4a3a', { roughness: 1 }), .008); bx(S, .3, .022, .5, 3.45, .012, 2.2, C('#7a6650', { roughness: 1 }), .006); // doormat
  for (const y of [1.85, .75]) for (const dz of [-.24, .24]) bx(S, .02, .8, .4, 3.895, y, 2.2 + dz, mWood, .006); // panel pintu
  // gantungan: backpack + tote
  bx(S, .03, .08, .5, 3.985, 1.75, 3.4, mWood, .006); for (const z of [3.25, 3.4, 3.55]) { cy(S, .01, .01, .08, 3.94, 1.75, z, mMetal, 8).rotation.z = PI / 2; sph(S, .015, 3.9, 1.75, z, mMetal); }
  bx(S, .13, .32, .24, 3.9, 1.55, 3.4, C('#2f4858', { roughness: .85 }), .04); bx(S, .04, .14, .18, 3.82, 1.48, 3.4, C('#233744', { roughness: .85 }), .02);
  bx(S, .03, .35, .28, 3.95, 1.55, 3.62, C('#efe3cf', { roughness: .95 }), .01); add(S, new THREE.TorusGeometry(.07, .008, 6, 16, PI), C('#efe3cf', { roughness: .95 }), 3.93, 1.75, 3.62).rotation.y = PI / 2;

  // ================= RAK BUKU: LED + tanaman di atasnya
  const shelfLed = glow(0xffb066, [.3, 1, 2.2]);
  [.855, 1.635, 2.415].forEach(y => bx(S, .012, .012, 2.15, -3.452, y, -1.5, shelfLed, .003));
  // ================= TANAMAN (instanced daun + batang)
  const LEAF = leafGeometry(), STEM = new THREE.CylinderGeometry(.5, .5, 1, 5), leafM = C('#ffffff', { roughness: .45, side: THREE.DoubleSide, sheen: .5, sheenColor: new THREE.Color('#bfe8a0') }), stemM = C('#4f7a3a', { roughness: .7 });
  const plant = (x, y, z, { n = 8, h = .4, spread = .2, pot = .06 } = {}) => {
    cy(S, pot * .9, pot * .75, pot * 2, x, y + pot, z, mTerra, 20);
    const L = new THREE.InstancedMesh(LEAF, leafM, n), T = new THREE.InstancedMesh(STEM, stemM, n), c = new THREE.Color(), up = new THREE.Vector3(0, 1, 0);
    for (let i = 0; i < n; i++) {
      const a = i * 2.399 + rnd() * .4, base = new THREE.Vector3(x, y + pot * 2, z), tip = new THREE.Vector3(x + Math.cos(a) * (.15 + rnd() * spread), y + pot * 2 + (.5 + rnd() * .9) * h, z + Math.sin(a) * (.15 + rnd() * spread));
      dm.position.copy(base).add(tip).multiplyScalar(.5); dm.scale.set(.008 + h * .01, base.distanceTo(tip), .008 + h * .01); dm.quaternion.setFromUnitVectors(up, tip.clone().sub(base).normalize()); dm.updateMatrix(); T.setMatrixAt(i, dm.matrix);
      const ls = (.2 + rnd() * .12) * (.6 + h); dm.position.copy(tip); dm.quaternion.identity(); dm.rotation.set(-1 - rnd() * .4, -a + PI / 2 + (rnd() - .5) * .6, (rnd() - .5) * .5); dm.scale.set(ls, ls, ls); dm.updateMatrix(); L.setMatrixAt(i, dm.matrix);
      L.setColorAt(i, c.setHSL(.3 + rnd() * .06, .5, .3 + rnd() * .12));
    }
    L.castShadow = T.castShadow = true; S.add(L, T);
  };
  plant(-3.7, 3.2, -1.1, { n: 9, h: .4, spread: .2, pot: .07 });   // di atas rak buku
  plant(-3.8, 1.65, 2.4, { n: 7, h: .4, spread: .2, pot: .06 });   // di ambang jendela
  bx(S, .24, .035, .17, -3.8, 1.68, .95, C('#d9a441', { roughness: .8 }), .004).rotation.y = .2; bx(S, .2, .03, .14, -3.8, 1.71, .95, C('#2f4858', { roughness: .8 }), .004).rotation.y = -.15;
  const candle = cy(S, .04, .04, .08, -3.82, 1.69, .65, new THREE.MeshPhysicalMaterial({ color: '#ffcf8a', transparent: true, opacity: .55, roughness: .1 }), 16);
  sph(S, .012, -3.82, 1.745, .65, glow(0xffb060, [0, 3, 6]), 1, 1.8, 1, 10);                                // lilin

  // ================= KARPET berumbai
  const fr = new THREE.InstancedMesh(new THREE.BoxGeometry(.07, .008, .012), C('#e8d8b8', { roughness: 1 }), 80);
  for (let i = 0; i < 40; i++) for (const s of [-1, 1]) { dm.position.set(s * 1.93, .012, -.5 + i * .065); dm.updateMatrix(); fr.setMatrixAt(i * 2 + (s > 0 ? 1 : 0), dm.matrix); }
  S.add(fr);

  // ================= PEMANDANGAN KOTA di balik jendela (2 lapis parallax + jendela menyala saat malam)
  const buildings = layer => { const b = []; let x = 0; while (x < 1024) { const w = 30 + rnd() * 70, h = 256 * (.2 + rnd() * (layer ? .5 : .35)); b.push([x, w, h]); x += w + rnd() * 6; } return b; };
  [[-7.15, 14, 2.6, 1, [new THREE.Color('#9fb1cf'), new THREE.Color('#5a3a52'), new THREE.Color('#0a0e22')]], [-7.55, 18, 3.4, 0, [new THREE.Color('#c9d6ea'), new THREE.Color('#8a5a6c'), new THREE.Color('#141a38')]]].forEach(([x, w, h, l, tint]) => {
    const B = buildings(l), sil = ct(1024, 256, g => { g.fillStyle = '#fff'; B.forEach(([bx0, bw, bh]) => g.fillRect(bx0, 256 - bh, bw, bh)); });
    const win = ct(1024, 256, g => { B.forEach(([bx0, bw, bh]) => { for (let wy = 256 - bh + 8; wy < 250; wy += 12) for (let wx = bx0 + 6; wx < bx0 + bw - 8; wx += 12) if (rnd() > .55) { g.fillStyle = rnd() > .5 ? '#ffd88a' : '#9fd0ff'; g.fillRect(wx, wy, 5, 6); } }); });
    const sm = new THREE.MeshBasicMaterial({ map: sil, transparent: true, fog: false }); sm.userData.base = sm.color.clone(); glows.push({ m: sm, k: tint });
    const p = new THREE.Mesh(new THREE.PlaneGeometry(w, h), sm); p.position.set(x, h / 2 - .6, 1.6); p.rotation.y = PI / 2; p.userData.noMerge = true; S.add(p);
    const wm = glow(0xffffff, [0, .25, 2.4], { map: win, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false });
    const q = new THREE.Mesh(new THREE.PlaneGeometry(w, h), wm); q.position.set(x + .01, h / 2 - .6, 1.6); q.rotation.y = PI / 2; q.userData.noMerge = true; S.add(q);
  });

  // ================= KUCING (model + animasi: lihat buildCat)
  const cat = buildCat(room, M); live.push((t, cam) => cat.update(t, cam));

  // ---------- gabungkan mesh statis per material
  S.updateMatrixWorld(true);
  const groups = new Map(), dead = [];
  S.traverse(o => {
    if (!o.isMesh || o.isInstancedMesh || o.userData.noMerge || o.material.transparent || Array.isArray(o.material)) return;
    const key = o.material.uuid + '|' + +o.castShadow + +o.receiveShadow, g = o.geometry.index ? o.geometry.toNonIndexed() : o.geometry.clone();
    for (const k of Object.keys(g.attributes)) if (!['position', 'normal', 'uv'].includes(k)) g.deleteAttribute(k);
    g.applyMatrix4(o.matrixWorld); if (!groups.has(key)) groups.set(key, { mat: o.material, c: o.castShadow, r: o.receiveShadow, geos: [] });
    groups.get(key).geos.push(g); dead.push(o);
  });
  dead.forEach(o => { o.parent.remove(o); o.geometry.dispose(); });
  for (const g of groups.values()) { const geo = mergeGeometries(g.geos); if (!geo) continue; const m = new THREE.Mesh(geo, g.mat); m.castShadow = g.c; m.receiveShadow = g.r; S.add(m); }

  return { glows, cat, update: (t, cam) => live.forEach(f => f(t, cam)) };
}

// ============================================================================
// KUCING: rig prosedural (badan, kepala + rahang, telinga, mata + kelopak, kumis, ekor 8 ruas) + mesin status.
//  - tidur  : meringkuk, napas pelan, telinga berkedut acak, ujung ekor menyentil acak
//  - bangun : ketika pemain mendekat (<±2,4 m) atau acak tiap ±20-45 dtk → menguap, kepala terangkat, membuka mata,
//             kepala mengikuti kamera, berkedip, ekor mengibas; lalu tidur lagi setelah pemain menjauh
// ============================================================================
function buildCat(room, M) {
  console.info('cat v4');
  const cat = new THREE.Group(); cat.position.set(-1.1, .03, .6); cat.rotation.y = .7; cat.scale.setScalar(1.4); room.add(cat);

  // ---- tekstur bulu: belang tabby "mackerel" (melingkar dari punggung ke samping), perut krem, kening bergaris "M"
  const stripe = (g, x, y0, dir, len, wd, a, bend) => { // satu belang melengkung dengan ujung memudar
    const y1 = y0 + dir * len, gr = g.createLinearGradient(0, y0, 0, y1); gr.addColorStop(0, `rgba(88,42,12,${a})`); gr.addColorStop(.6, `rgba(104,52,16,${a * .8})`); gr.addColorStop(1, 'rgba(110,56,18,0)');
    g.strokeStyle = gr; g.lineWidth = wd; g.lineCap = 'round'; g.beginPath(); g.moveTo(x, y0); g.quadraticCurveTo(x + bend, (y0 + y1) / 2, x + bend * .4, y1); g.stroke();
  };
  const bodyT = ct(512, 256, (g, w, h) => {                       // u = sepanjang badan, v = keliling badan (tengah = punggung)
    const base = g.createLinearGradient(0, 0, 0, h); base.addColorStop(0, '#e2b274'); base.addColorStop(.28, '#d9a05a'); base.addColorStop(.5, '#c98a45'); base.addColorStop(.72, '#d9a05a'); base.addColorStop(1, '#e2b274');
    g.fillStyle = base; g.fillRect(0, 0, w, h);
    const sp = g.createLinearGradient(0, 0, 0, h); sp.addColorStop(0, 'rgba(250,236,210,1)'); sp.addColorStop(.16, 'rgba(250,236,210,.55)'); sp.addColorStop(.3, 'rgba(250,236,210,0)'); sp.addColorStop(.7, 'rgba(250,236,210,0)'); sp.addColorStop(.84, 'rgba(250,236,210,.55)'); sp.addColorStop(1, 'rgba(250,236,210,1)'); g.fillStyle = sp; g.fillRect(0, 0, w, h); // perut krem
    g.shadowColor = 'rgba(100,50,14,.5)'; g.shadowBlur = 9;
    for (let x = 10; x < w; x += 34 + rnd() * 24) { const wd = 12 + rnd() * 12, bend = (rnd() - .5) * 22; for (const d of [-1, 1]) stripe(g, x, h / 2, d, h * (.22 + rnd() * .22), wd, .38 + rnd() * .22, bend); }
    g.shadowBlur = 3; g.strokeStyle = 'rgba(90,44,12,.6)'; g.lineWidth = 9; g.beginPath(); g.moveTo(0, h / 2); for (let x = 0; x <= w; x += 16) g.lineTo(x, h / 2 + Math.sin(x * .05) * 2); g.stroke(); // garis punggung
    g.shadowBlur = 0;
    for (let i = 0; i < 5200; i++) { g.fillStyle = rnd() > .5 ? 'rgba(255,230,180,.1)' : 'rgba(60,30,10,.1)'; g.fillRect(rnd() * w, rnd() * h, 2 + rnd() * 5, 1); } // helai bulu
  });
  const headT = ct(512, 256, (g, w, h) => {                       // u: 0 belakang → 1 depan
    const base = g.createLinearGradient(0, 0, 0, h); base.addColorStop(0, '#e2b274'); base.addColorStop(.5, '#cf9552'); base.addColorStop(1, '#e2b274'); g.fillStyle = base; g.fillRect(0, 0, w, h);
    g.shadowColor = 'rgba(100,50,14,.7)'; g.shadowBlur = 4; g.strokeStyle = 'rgba(92,44,12,.85)'; g.lineCap = 'round';
    g.lineWidth = 7; for (const dv of [-.09, 0, .09]) { g.beginPath(); g.moveTo(w * .36, h * (.5 + dv * 1.4)); g.quadraticCurveTo(w * .62, h * (.5 + dv * 1.1), w * .9, h * (.5 + dv * .6)); g.stroke(); } // garis "M" kening
    g.lineWidth = 6; for (const v of [.22, .78]) for (const du of [0, .08]) { const d = v < .5 ? 1 : -1; g.beginPath(); g.moveTo(w * (.5 + du), h * v); g.quadraticCurveTo(w * (.62 + du), h * (v + d * .05), w * (.74 + du), h * (v + d * .12)); g.stroke(); } // garis pipi
    g.shadowBlur = 0;
    const ch = g.createLinearGradient(0, 0, 0, h); ch.addColorStop(0, 'rgba(250,236,210,.95)'); ch.addColorStop(.14, 'rgba(250,236,210,0)'); ch.addColorStop(.86, 'rgba(250,236,210,0)'); ch.addColorStop(1, 'rgba(250,236,210,.95)'); g.fillStyle = ch; g.fillRect(0, 0, w, h);
    const mz = g.createRadialGradient(w * .96, h / 2, 2, w * .96, h / 2, w * .2); mz.addColorStop(0, 'rgba(252,242,224,.9)'); mz.addColorStop(1, 'rgba(252,242,224,0)'); g.fillStyle = mz; g.fillRect(0, 0, w, h); // moncong terang
    for (let i = 0; i < 3500; i++) { g.fillStyle = rnd() > .5 ? 'rgba(255,230,180,.1)' : 'rgba(60,30,10,.1)'; g.fillRect(rnd() * w, rnd() * h, 2 + rnd() * 4, 1); }
  });
  const fm = map => new THREE.MeshPhysicalMaterial({ map, normalMap: normalMap(map, 1.6), normalScale: new THREE.Vector2(.4, .4), roughness: .92, sheen: 1, sheenRoughness: .5, sheenColor: new THREE.Color('#ffd9a8') });
  const fur = fm(bodyT), furH = fm(headT), lidM = furH.clone(); lidM.side = THREE.DoubleSide;
  const wht = M('#f4efe6', { roughness: .95, sheen: 1, sheenColor: new THREE.Color('#fff') }), cream = M('#f1dfc2', { roughness: .95, sheen: 1, sheenColor: new THREE.Color('#fff') }), pink = M('#e89aa0', { roughness: .7 }), dark = M('#1a1210', { roughness: .5 });
  const tailT = ct(64, 128, (g, w, h) => {                        // v sepanjang ruas: terang → cincin gelap lembut di ujung
    const gr = g.createLinearGradient(0, 0, 0, h); gr.addColorStop(0, '#d9a05a'); gr.addColorStop(.45, '#d29a55'); gr.addColorStop(.62, '#7a4418'); gr.addColorStop(.85, '#7a4418'); gr.addColorStop(1, '#d9a05a'); g.fillStyle = gr; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 500; i++) { g.fillStyle = rnd() > .5 ? 'rgba(255,230,180,.12)' : 'rgba(40,20,6,.12)'; g.fillRect(rnd() * w, rnd() * h, 1 + rnd() * 3, 2); }
  });
  const tailA = new THREE.MeshPhysicalMaterial({ map: tailT, roughness: .95, sheen: 1, sheenRoughness: .5, sheenColor: new THREE.Color('#ffd9a8') }), tailB = M('#6e3d16', { roughness: .95, sheen: 1, sheenColor: new THREE.Color('#c98b4a') });

  const P = (parent, geo, mat, x = 0, y = 0, z = 0, sx = 1, sy = 1, sz = 1) => { const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z); m.scale.set(sx, sy, sz); m.receiveShadow = true; parent.add(m); return m; };
  const S = (r, seg = 18, uvMap = false) => { const g = new THREE.SphereGeometry(r, seg, Math.round(seg * .7)); if (uvMap) { const p = g.attributes.position, uv = g.attributes.uv; for (let i = 0; i < p.count; i++) uv.setXY(i, p.getX(i) / r * .5 + .5, Math.atan2(p.getZ(i), p.getY(i)) / (2 * PI) + .5); } return g; }; // uvMap: proyeksi sepanjang sumbu x → belang melingkar
  const limb = (par, a, b, r0, r1, mat) => { const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b), m = new THREE.Mesh(new THREE.CylinderGeometry(r1, r0, va.distanceTo(vb), 10), mat); m.position.copy(va).add(vb).multiplyScalar(.5); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), vb.clone().sub(va).normalize()); m.receiveShadow = true; par.add(m); return m; };

  // bayangan kontak lembut (shadow map statis tidak ikut bergerak)
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(.75, .5), new THREE.MeshBasicMaterial({ map: blobTexture(), transparent: true, opacity: .5, depthWrite: false })); sh.rotation.x = -PI / 2; sh.position.set(.02, .004, 0); cat.add(sh);

  // ---- badan, paha, dada, kaki (tersambung ke badan)
  const torso = new THREE.Group(); torso.position.set(0, .105, 0); cat.add(torso);
  const body = P(torso, S(.15, 28, true), fur, 0, 0, 0, 1.55, .68, .9);
  for (const s of [-1, 1]) P(torso, S(.085, 18, true), fur, -.09, -.025, s * .1, 1.15, .95, .8);                    // paha belakang
  P(torso, S(.1, 20, true), fur, .1, .012, 0, 1, .9, 1); P(torso, S(.085, 18, true), furH, .17, .035, 0, 1, 1, .95); // bahu + leher (menyambung ke kepala)
  P(torso, S(.1, 20, true), fur, -.12, .0, 0, 1, .85, 1.05);                                                          // pantat bulat
  P(torso, S(.09, 18, true), fur, .13, -.01, 0, 1, .85, 1); P(torso, S(.06, 16), cream, .165, -.035, 0, .8, .95, 1); // dada
  for (let k = 0; k < 3; k++) P(torso, new THREE.ConeGeometry(.018, .05, 6), cream, .205, -.045 - k * .004, (k - 1) * .022).rotation.z = -PI / 2 + .35; // jumbai dada
  for (const s of [-1, 1]) {
    limb(cat, [.12, .085, s * .075], [.225, .04, s * .058], .034, .026, fur); limb(cat, [.215, .045, s * .058], [.255, .024, s * .058], .027, .024, wht); P(cat, S(.026), wht, .257, .023, s * .058, 1.35, .7, 1); for (const d of [-1, 0, 1]) P(cat, new THREE.BoxGeometry(.0012, .0012, .01), dark, .273, .03, s * .058 + d * .009);   // kaki depan + telapak + garis jari
    limb(cat, [-.1, .05, s * .165], [-.02, .03, s * .17], .03, .024, fur); limb(cat, [-.03, .03, s * .17], [.005, .022, s * .172], .025, .022, wht); P(cat, S(.024), wht, .01, .022, s * .172, 1.35, .7, 1);       // kaki belakang + telapak
  }

  // ---- kepala
  const head = new THREE.Group(); head.position.set(.2, .115, 0); cat.add(head);
  P(head, S(.085, 24, true), furH, 0, 0, 0, 1, .92, 1.08);
  for (const s of [-1, 1]) { P(head, S(.05, 14, true), furH, .022, -.032, s * .058, .72, .5, .72); const t = new THREE.Mesh(new THREE.ConeGeometry(.016, .04, 6), cream); t.position.set(.0, -.032, s * .098); t.rotation.set(s * 1.1, 0, 0); t.rotation.z = .5; head.add(t); } // pipi + jumbai
  P(head, S(.04, 16), wht, .075, -.03, 0, .9, .7, 1.25); P(head, S(.012, 12), pink, .112, -.012, 0, 1, .8, 1.3);     // moncong + hidung
  P(head, new THREE.BoxGeometry(.0012, .014, .0012), dark, .108, -.024, 0);                                          // philtrum
  for (const s of [-1, 1]) { P(head, new THREE.BoxGeometry(.001, .001, .018), dark, .104, -.035, s * .009).rotation.y = s * .6; for (let k = 0; k < 3; k++) P(head, S(.0016, 6), dark, .097 + k * .003, -.027 - k * .0025, s * (.02 + k * .007)); } // garis mulut + titik kumis
  const jaw = new THREE.Group(); jaw.position.set(.05, -.04, 0); head.add(jaw);                                      // rahang bawah (menguap)
  P(jaw, S(.028, 12), wht, .035, -.004, 0, 1.1, .45, .9); const mouth = P(jaw, S(.024, 10), dark, .035, .004, 0, .9, .3, .7); mouth.visible = false;
  const ears = [-1, 1].map(s => { const g = new THREE.Group(); g.position.set(-.005, .072, s * .052); head.add(g);
    P(g, new THREE.ConeGeometry(.04, .078, 14), furH, 0, .036, 0, .5, 1, 1); P(g, new THREE.ConeGeometry(.027, .06, 14), pink, .0075, .03, 0, .4, 1, 1); P(g, new THREE.ConeGeometry(.02, .036, 10), cream, .0095, .022, 0, .35, 1, 1); return { g, s }; });

  // ---- mata: bola almond + iris bertekstur + pupil celah + kilau + kelopak atas + garis bulu mata (saat tutup)
  const irisT = ct(512, 256, (g, w, h) => {
    const cx = w / 2, cy = h / 2; g.fillStyle = '#1c1208'; g.fillRect(0, 0, w, h);
    const r = g.createRadialGradient(cx, cy, 6, cx, cy, 88); r.addColorStop(0, '#f2ea7a'); r.addColorStop(.45, '#b6d84a'); r.addColorStop(.85, '#4f8f26'); r.addColorStop(1, '#1f4a12');
    g.fillStyle = r; g.beginPath(); g.arc(cx, cy, 88, 0, 7); g.fill();
    for (let i = 0; i < 80; i++) { const a = rnd() * 6.28; g.strokeStyle = rnd() > .5 ? 'rgba(255,255,170,.28)' : 'rgba(30,70,10,.3)'; g.lineWidth = 1.3; g.beginPath(); g.moveTo(cx + Math.cos(a) * 22, cy + Math.sin(a) * 22); g.lineTo(cx + Math.cos(a) * 82, cy + Math.sin(a) * 82); g.stroke(); }
    g.strokeStyle = '#142a0a'; g.lineWidth = 8; g.beginPath(); g.arc(cx, cy, 88, 0, 7); g.stroke();
  });
  const eyeM = new THREE.MeshPhysicalMaterial({ map: irisT, roughness: .12, clearcoat: 1, clearcoatRoughness: .05, emissive: '#3a5a14', emissiveMap: irisT, emissiveIntensity: .25 });
  const shine = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const eyes = [-1, 1].map(s => {
    const g = new THREE.Group(); g.position.set(.067, .02, s * .041); g.rotation.order = 'YXZ'; g.rotation.set(-s * .22, -s * .42, 0); head.add(g); // menghadap keluar-depan, sudut luar naik
    P(g, S(.019, 22), eyeM, 0, 0, 0, .8, .88, 1.15).rotation.y = 0;
    const pup = new THREE.Mesh(new THREE.CircleGeometry(1, 20), dark); pup.rotation.y = PI / 2; pup.position.x = .0157; pup.scale.set(.005, .0152, 1); g.add(pup);
    P(g, S(.0024, 8), shine, .0162, .0065, .0055); P(g, S(.0012, 6), shine, .0158, -.005, -.006);                          // kilau mata
    const lid = new THREE.Mesh(new THREE.SphereGeometry(.0205, 18, 10, 0, PI * 2, 0, PI / 2), lidM); lid.scale.set(.88, .95, 1.2); lid.receiveShadow = true; g.add(lid); // kelopak atas
    const lash = new THREE.Mesh(new THREE.TorusGeometry(.0155, .0016, 6, 14, PI), dark); lash.rotation.set(0, PI / 2, PI); lash.position.set(.0207, -.001, 0); lash.scale.set(1, 1, 1.2); g.add(lash); // ∪ saat mata tertutup
    return { lid, lash, pup };
  });
  for (const s of [-1, 1]) {
    for (let k = 0; k < 3; k++) { const g = new THREE.BoxGeometry(.0013, .0013, .085); g.translate(0, 0, s * .0425); const w = P(head, g, wht, .09, -.025 + k * .008, s * .03); w.rotation.y = s * (.2 + k * .2); w.rotation.z = (k - 1) * .1; } // kumis
    for (let k = 0; k < 2; k++) { const g = new THREE.BoxGeometry(.0012, .0012, .05); g.translate(0, 0, s * .025); const w = P(head, g, wht, .075, .047 - k * .006, s * .042); w.rotation.y = s * (.5 + k * .3); w.rotation.z = .35; } // kumis alis
  }

  // ---- ekor 10 ruas tumpang-tindih (tanpa sendi bola), tapering + cincin belang; pangkal dinaikkan & selalu melengkung ke ATAS
  //      sehingga tidak pernah menyentuh/menembus karpet (lantai karpet y=0 di ruang kucing; jari-jari ekor ≤ .028)
  const tail0 = new THREE.Group(); tail0.position.set(-.16, .075, .02); tail0.rotation.y = PI; cat.add(tail0);
  const NS = 10, SP = .05, segs = []; let par = tail0;
  for (let i = 0; i < NS; i++) {
    const seg = new THREE.Group(); if (i) seg.position.x = SP; par.add(seg);
    const r0 = .027 - i * .00115, r1 = .027 - (i + 1) * .00115, last = i >= NS - 2;
    const m = P(seg, new THREE.CylinderGeometry(r0, r1, SP * 1.28, 10, 1), last ? tailB : tailA); m.rotation.z = PI / 2; m.position.x = SP * .5; m.castShadow = false;
    if (i === 0) P(seg, S(r0, 10), tailA, 0, 0, 0, .9, 1, 1);                                     // pangkal membulat menyatu dengan pantat
    segs.push(seg); par = seg;
  }
  P(segs[NS - 1], S(.0165, 12), tailB, SP * 1.1, 0, 0, 1.15, 1, 1);                                 // ujung membulat

  // ---------- mesin status + animasi
  const clamp = (x, a, b) => Math.max(a, Math.min(b, x)), sm = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
  const v = new THREE.Vector3(), R = Math.random;
  let last = -1, alert = 0, target = 0, stirEnd = 0, nextStir = 18 + R() * 10, yawn = -1, blink = -1, nextBlink = 3, flick = -1, nextFlick = 5 + R() * 6, hy = .5, hp = -.18;
  const ear = [-1, -1], nextEar = [2 + R() * 3, 4 + R() * 4]; let forced = null;
  function update(t, cam) {
    const s = t / 1000, dt = last < 0 ? 0 : Math.min(s - last, .05); last = s;
    let near = false, ly = .5, lp = 0;
    if (cam) { v.copy(cam.position); cat.worldToLocal(v); const dx = v.x - .2, dz = v.z; near = Math.hypot(v.x, v.z) * 1.4 < 2.4; ly = clamp(Math.atan2(-dz, dx), -1.05, 1.05); lp = clamp(Math.atan2(v.y - .2, Math.hypot(dx, dz)), -.1, .55); }
    if (forced !== null) { target = forced; stirEnd = s + 99; near = forced > 0; }
    else if (near) { target = 1; stirEnd = s + 5; } else if (s > nextStir) { target = 1; stirEnd = s + 7; nextStir = s + 25 + R() * 20; }
    if (s > stirEnd && !near && forced === null) target = 0;
    const was = alert; alert += (target - alert) * (1 - Math.exp(-dt * 1.6));
    if (was < .15 && alert >= .15 && target === 1 && yawn < 0) yawn = 0;                           // menguap saat mulai bangun
    let jw = 0; if (yawn >= 0) { yawn += dt; const p = yawn / 2.6; if (p >= 1) yawn = -1; else jw = Math.sin(PI * p); }
    nextBlink -= dt; if (nextBlink < 0 && alert > .6 && blink < 0) { blink = 0; nextBlink = 2.5 + R() * 4; }
    let bl = 0; if (blink >= 0) { blink += dt; const p = blink / .16; if (p >= 1) blink = -1; else bl = Math.sin(PI * p); }
    for (let i = 0; i < 2; i++) { nextEar[i] -= dt; if (nextEar[i] < 0 && ear[i] < 0) { ear[i] = 0; nextEar[i] = (alert > .6 ? 2 : 4) + R() * 5; } if (ear[i] >= 0) { ear[i] += dt; if (ear[i] > .3) ear[i] = -1; } }
    nextFlick -= dt; if (nextFlick < 0 && flick < 0) { flick = 0; nextFlick = 5 + R() * 8; }
    let fl = 0; if (flick >= 0) { flick += dt; const p = flick / 1.1; if (p >= 1) flick = -1; else fl = Math.sin(PI * p); }
    const br = Math.sin(s * PI * 2 * (.38 + .3 * alert));                                          // napas
    body.scale.set(1.55 * (1 + br * .012), .68 * (1 + br * .04 * (1 - .4 * alert)), .9 * (1 + br * .015)); torso.rotation.z = .1 * alert;
    const k = 1 - Math.exp(-dt * 4); hy += ((.5 * (1 - alert) + ly * alert) - hy) * k; hp += ((-.18 * (1 - alert) + lp * alert * .8) - hp) * k; // kepala mengikuti kamera
    head.rotation.set(0, hy, hp - jw * .12); head.position.y = .115 + .075 * alert + br * .002;
    jaw.rotation.z = -jw * .65; mouth.visible = jw > .08;
    const open = sm(.3, .65, alert) * (1 - bl) * (1 - jw * .85);                                   // 1 = mata terbuka penuh
    eyes.forEach(e => { e.lid.rotation.z = 1.25 + (-1.5708 - 1.25) * (1 - open); e.lash.visible = open < .45; e.pup.scale.x = .0045 + .004 * alert; });
    ears.forEach(({ g, s: sd }, i) => { const tw = ear[i] >= 0 ? Math.sin(ear[i] / .3 * PI) * .55 : 0; g.rotation.x = -sd * (.3 - .15 * alert); g.rotation.z = -(tw + jw * .5 - alert * .12); });
    // ekor: yaw (kiri-kanan) + pitch SELALU ≥ 0 (ke atas) → tidak pernah turun ke karpet
    const curl = .3 * (1 - alert) + .08 * alert, amp = alert * .42;
    for (let i = 0; i < NS; i++) {
      const w = i / (NS - 1);
      segs[i].rotation.y = curl + Math.sin(s * 2.2 - i * .5) * amp * (.2 + w) + fl * .45 * Math.max(0, w - .35) * Math.sin(s * 14 + i);
      const lift = i === 0 ? .5 * alert + .1 * (1 - alert) : (.05 + .08 * alert) * (1 - .5 * w); // tidur: rebah rendah; bangun: busur lembut ke atas
      segs[i].rotation.z = Math.max(.02, lift + (i ? Math.sin(s * 1.7 - i * .45) * .05 * alert * (.4 + w) : 0));
    }
    cat.updateMatrixWorld(true); // scene statis → update manual
    // pengaman: pastikan setiap ruas ekor (termasuk jari-jarinya) berada di atas permukaan karpet (y lokal kucing = 0)
    for (let i = 0; i < NS; i++) {
      segs[i].getWorldPosition(v); cat.worldToLocal(v);
      const rr = .027 - i * .00115 + .005, need = rr - v.y;
      if (need > 0) { segs[i].rotation.z += Math.min(.6, need / (SP * 1.2)); cat.updateMatrixWorld(true); }
    }
  }
  return { update, group: cat, force(a) { forced = a; if (a !== null) alert = a; } };
}
