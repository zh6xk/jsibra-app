// Panel pengaturan grafis (⚙ Grafis). Pilihan disimpan di localStorage.
export const QUALITY = {
  rendah: { rays: 0,  scale: 1,    msaa: 0, ao: 0,  bloom: 0,  shadow: 1024, fx: 0,  fov: 62, adaptive: true },
  sedang: { rays: .6, scale: 1,    msaa: 0, ao: 0,  bloom: .6, shadow: 2048, fx: .6, fov: 62, adaptive: true },
  tinggi: { rays: 1,  scale: 1.25, msaa: 4, ao: 1,  bloom: 1,  shadow: 4096, fx: 1,  fov: 62, adaptive: true },
  ultra:  { rays: 1.3, scale: 2,   msaa: 8, ao: 1.3, bloom: 1.3, shadow: 4096, fx: 1.2, fov: 62, adaptive: false },
};
const KEY = 'room-gfx';
export function loadCfg(def, ignoreSaved) {
  let c = null;
  if (!ignoreSaved) try { c = JSON.parse(localStorage.getItem(KEY)); } catch (_) { }
  return { ...QUALITY[def], preset: def, expo: 1, fps: false, vol: .7, mute: false, ...c };
}

const FIELDS = [
  ['scale', 'Resolusi render (x)', .5, 2, .25, 1], ['msaa', 'Anti-aliasing MSAA (0/4/8)', 0, 8, 4, 1], ['ao', 'Ambient occlusion', 0, 2, .1],
  ['rays', 'Sinar cahaya volumetrik (god rays)', 0, 2, .1], ['bloom', 'Bloom / glow', 0, 2, .1], ['shadow', 'Kualitas bayangan', 512, 4096, 512, 1], ['fx', 'Vignette · grain · warna lensa', 0, 2, .1],
  ['expo', 'Eksposur', .6, 1.6, .05], ['fov', 'Sudut pandang (FOV)', 45, 90, 1], ['vol', 'Volume suara ambient', 0, 1, .05],
];
export function saveCfg(cfg) { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (_) { } }
export function createSettings(cfg, apply) {
  const root = document.createElement('div'); root.id = 'gfx';
  root.innerHTML = '<h3>⚙ Grafis & Suara</h3><div class="pre"></div><div class="fl"></div><label class="ck"><input type="checkbox" data-k="adaptive"> Resolusi adaptif (turun otomatis saat lag)</label><label class="ck"><input type="checkbox" data-k="fps"> Tampilkan FPS</label><small>Resolusi, MSAA & bayangan berlaku setelah slider dilepas. Perubahan tersimpan otomatis.</small>';
  document.body.append(root);
  const pre = root.querySelector('.pre'), fl = root.querySelector('.fl'), save = () => { try { localStorage.setItem(KEY, JSON.stringify(cfg)); } catch (_) { } };
  const inputs = {}, vals = {}, btns = {};
  for (const n of Object.keys(QUALITY)) {
    const b = document.createElement('button'); b.textContent = n[0].toUpperCase() + n.slice(1); btns[n] = b; pre.append(b);
    b.onclick = () => { Object.assign(cfg, QUALITY[n], { preset: n }); sync(); save(); apply(); };
  }
  for (const [k, label, min, max, step, heavy] of FIELDS) {
    const r = document.createElement('div'); r.className = 'f';
    r.innerHTML = `<span>${label}</span><b></b><input type="range" min="${min}" max="${max}" step="${step}">`;
    const i = r.querySelector('input'), v = r.querySelector('b'); inputs[k] = i; vals[k] = v; fl.append(r);
    i.addEventListener('input', () => { cfg[k] = +i.value; if (k !== 'vol') cfg.preset = 'kustom'; v.textContent = i.value; mark(); if (!heavy) { save(); apply(); } });
    if (heavy) i.addEventListener('change', () => { save(); apply(); });
  }
  root.querySelectorAll('.ck input').forEach(c => c.onchange = () => { cfg[c.dataset.k] = c.checked; save(); apply(); });
  function mark() { for (const n in btns) btns[n].classList.toggle('on', cfg.preset === n); }
  function sync() { for (const k in inputs) { inputs[k].value = cfg[k]; vals[k].textContent = cfg[k]; } root.querySelectorAll('.ck input').forEach(c => c.checked = !!cfg[c.dataset.k]); mark(); }
  sync();
  const gx = document.getElementById('gx');
  gx.onclick = () => { document.exitPointerLock?.(); root.classList.toggle('show'); };
  return { refresh: sync };
}
